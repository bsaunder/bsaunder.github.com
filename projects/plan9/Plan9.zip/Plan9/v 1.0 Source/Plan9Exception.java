/*
 * Created by Bryan Saunders
 * Created on Aug 10, 2004
 */

public class Plan9Exception extends RuntimeException{
	public Plan9Exception(String s){
		super(s);
	}
}
