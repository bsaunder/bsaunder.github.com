 function say($1){ 
     echo $s; 
} 

 function 
 say($1){ 
     echo $s; 
} 
 
function 
othersay($2){ 
     echo $s; 
     say($z); 
} 
 
say    ($a); 
say($b); say("c"); 
say_other("d "); 
other_say("e" . say('f')); 
 say($g); 
     say($h); 
sayother($i); 
othersay($j,"k",'l'); 
