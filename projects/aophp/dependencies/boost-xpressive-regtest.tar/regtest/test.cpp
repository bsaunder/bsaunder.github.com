#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>
#include <boost/xpressive/xpressive_dynamic.hpp>

using namespace boost::xpressive;
using namespace std;

int main()
{
    
    	// Open PHP Source Input File
	ifstream inFile;
	string phpIn("test.php");
	inFile.open(phpIn.c_str(),ios::in);
	if(!inFile){
		cerr << "ERR: Could Not Source Open File\n";
		return 1;
	}else{
		cout << "Opened Source File\n";
	}

	// Parse PHP Source File to String
	string tmpStr;
	string php = "";
	while(!inFile.eof()){
		getline(inFile,tmpStr);
		php += tmpStr + "\n";
	}
	inFile.close();
	
    	sregex ws = sregex::compile("[\\s]*"); // Remove Whitespace
    	string format(""); // Empty String Format
    	// Find Function Calls
    	sregex token = sregex::compile("(function[\\s]*[ ]*|[\\s][ ]*|[ ]*)([a-zA-Z0-9_]*)([\\s]*)\\(([a-zA-Z0-9_\"$', .()]*)\\)");
    	// Iterate Through PHP Cpde
    	sregex_iterator cur( php.begin(), php.end(), token );
    	sregex_iterator end;
    	// Target Function
    	string name = "say";
    	// Iterate
    	for( ; cur != end; ++cur )
    	{
    	    // Get Current Match
        	smatch const &what = *cur;
        	cout << "==>: (" << what.position() << "," << what.length() << ") N-" << what[2] << " | P-" <<  what[4] << " | F-" <<  what[1] << '|';
        	// Remove Whitespace
        	string result2 = regex_replace(what[1].str(),ws,format);
        	// Make sure Not Function Definition & Correct Call
        	if(result2.compare("function")!=0 && what[2].str().compare(name)==0){
        		// Matched - Remove/Replace
        		cout << " MATCH";
       		}
       		cout << '\n';
    	}

    	return 0;

}
