
#ifndef LINKED_LIST_PC
#define LINKED_LIST_PC
#include <iostream>
#include <string>
using namespace std;

struct pcdata{
	int id; // Required
	string name; // Required
	string definition;
};

struct pcnode{
	pcdata info;
	pcnode *next;
};

class LListPC{
	private:
		pcnode *front;
		pcnode *rear;
		int count;
	public:
		LListPC();
		LListPC(const LListPC &);
		LListPC & operator = (const LListPC &);
		void insert(pcdata);
		int findByName(string);
		pcdata getFirst();
		pcdata getLast();
		pcdata getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dump() const;
		int countpcnodes();
		void reset();
		~LListPC();
};

#endif

