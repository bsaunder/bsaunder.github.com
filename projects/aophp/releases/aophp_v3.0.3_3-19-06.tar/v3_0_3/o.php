<?
echo "//Comment";


function say($s){
	echo "Gonna $s";
	$p = 0;

	say($s);
}

function ao_fi_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y){
	return $x + $y;
}

function other_ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s){
	echo "Other Say";
}

function otherao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s){
	echo "Other Say";
}

function ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_sayother($s){
	echo "Other Say";
}

function ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say_other($s){
	echo "Other Say";
}



$x1 = 0;
$x2 = 4;
$y = $x1+$x2;
ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($y);







ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say("CCU");

$z = ao_fi_0c52bab0471ce3d2cc8ed420655ea50f_add(2,2);

 

function ao_bf_6786e1d58be7e6bdb07a53555b63d6c1_say($s) { 
echo "BEFORE I SAY: $s <br><br>"; 
} 

function ao_ar_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y) { 
if($x == 2){
			return add($x,$y);
		}else{
			return add(4,5);
		}
		return 6; 
} 



function ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s) { 
ao_bf_6786e1d58be7e6bdb07a53555b63d6c1_say($s);say($s); } 

function ao_fi_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y) { 
$temp = ao_ar_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y);return $temp; 
 } 



?>