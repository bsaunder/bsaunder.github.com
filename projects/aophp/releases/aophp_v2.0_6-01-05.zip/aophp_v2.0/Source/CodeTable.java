/*
(c) 2004-2005 John W. Stamey, Bryan T. Saunders, and Matthew Cameron.
 This program is licensed under the GNU General Public License.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

import java.util.*;

public class CodeTable {
	private LinkedList<CodeSymbol> table = new LinkedList<CodeSymbol>();
	
	public CodeTable(){}
	
	public void addCode(CodeSymbol newCode){
		table.add(newCode);
	}
	
	public boolean doesReturn(String name){
		CodeSymbol temp;
		for(int i = 0;i<table.size();i++){
			temp = table.get(i);
			if(temp.getJoinpoint().equalsIgnoreCase(name)){
				return temp.doesReturn();
			}
		}
		return false;
	}
	
	public boolean hasSig(String sig){
		CodeSymbol temp;
		for(int i = 0;i<table.size();i++){
			temp = table.get(i);
			if(temp.getSignature().equalsIgnoreCase(sig)){
				return true;
			}
		}
		return false;
	}
	
	public boolean hasSignature(String sig){
		CodeSymbol temp;
		for(int i = 0;i<table.size();i++){
			temp = table.get(i);
			if(temp.getSignature().equals(sig)){
				return true;
			}
		}
		return false;
	}
	
	public void updateSigReturn(String sig,boolean val){
		CodeSymbol temp;
		for(int i = 0;i<table.size();i++){
			temp = table.get(i);
			if(temp.getSignature().equals(sig)){
				temp.setReturn(val);
			}
		}
	}
	
	public void printTable(){
		System.out.println("Code Table:");
		int size = table.size();
		CodeSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			System.out.println("  - "+temp.getSignature()+" - "+temp.doesReturn());
		}
	}
	
	public String scanLine(String line){
		int size = table.size();
		CodeSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			if(!line.contains("function")){
				if(line.contains(temp.getName())){
					if(lineIsFor(line,temp.getSignature())){
						line = line.replace(temp.getName(),"aophp_"+temp.getNameNum()+temp.getName());
					}
				}
				/*if(line.contains(temp.getName())){
					line = line.replace(temp.getName(),"aophp_"+temp.getName());
				}*/
			}
		}
		return line;
	}
	
	private boolean lineIsFor(String curLine, String sig){
		// Drop Counted Comma Locations in Array
		//   to Later retrieve initial Parameters 
		//   being passed in should they be needed
		int x = new StringTokenizer(sig,",").countTokens();
		// Get Parameters on Line
		int start = curLine.indexOf("(");
		int end = curLine.lastIndexOf(")",curLine.indexOf(";",start))+1;
		String search = curLine.substring(start,end);
		//System.out.println(search);
		
		boolean inString = false;
		boolean inChar = false;
		boolean inComment = false;
		int level = 0;
		int count = 0;
		for(int i=0;i<search.length();i++){
			char z = search.charAt(i);
			if(z == '('){
				if(!inString && !inComment){
					level++;
				}
			}else if(z == ')'){
				if(!inString && !inComment){
					level--;
				}
				if(level == 0){
					break;
				}
			}else if(z == ','){
				if(!inString && !inComment && !inChar && level == 1){
					count++;
				}
			}else if(z == '\\'){
				i++;
			}else if(z == '"'){
				inString = !inString;
			}else if(z == '\''){
				inChar = !inChar;
			}else if(z == '/'){
				if(search.charAt(i+1)=='*'){
					if(!inString){
						inComment = true;
						i++;
					}
				}
			}else if(z == '*'){
				if(search.charAt(i+1)=='/'){
					if(!inString){
						inComment = false;
						i++;
					}
				}
			}
		}		
		return count+1==x;
	}
	
	// Function to Generate Aspect Functions
	// Will Return all the functions as a single String to be written to the file.
	public String genAspectFuncs(AdviceTable at){
		String functions = "";
		String curFunc = "";
		// Loop Through CodeTable getting Functions
		int size = table.size();
		boolean returns = false;
		CodeSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			// Does Return
			returns = temp.doesReturn();
			// Define Function
			curFunc += "function aophp_"+temp.getNameNum()+temp.getSignature()+" {\n";
			// Insert Before Advice
			if(at.hasAdvice(temp.getSignature(),"before")){
				curFunc += "\n//Before Advice\n";
				curFunc += at.getAdviceCode(temp.getSignature(),"before");
			}
			// Around Advice
			if(at.hasAdvice(temp.getSignature(),"around")){
				if(returns){
					// Around Advice, Returns
					//Call Function to Warp Advice (incase of Proceed or Return)
					curFunc += "\n// Around Advice\n";
					curFunc += aroundReturn(at.getAdviceCode(temp.getSignature(),"around"),temp.getName());
					//curFunc += at.getAdviceCode(temp.getSignature(),"around");
					curFunc += "\n";	
				}else{
					// Around Advice, No Return
					// Call Function to Warp Advice (incase of Proceed)
					curFunc += "\n// Around Advice\n";
					curFunc += aroundNoReturn(at.getAdviceCode(temp.getSignature(),"around"),temp.getName());
					//curFunc += at.getAdviceCode(temp.getSignature(),"around");
					curFunc += "\n";
				}
			}else{
				if(returns){
					// No Around Advice, Returns
					curFunc += "\n// No Around\n";
					curFunc += "$temp = "+temp.getSignature()+";";
				}else{
					// No Around Advice, No Return
					curFunc += "\n// No Around\n";
					curFunc += temp.getSignature()+";";
				}
			}
			// Insert After Advice
			if(at.hasAdvice(temp.getSignature(),"after")){
				curFunc += "\n//After Advice\n";
				curFunc += at.getAdviceCode(temp.getSignature(),"after");
			}
			// Return If Needed
			if(returns){
				curFunc += "return $temp;\n";
			}
			// Close Function
			curFunc += "\n}";
			functions += "\n\n"+curFunc;
			curFunc = "";
		}
		
		return functions;
	}
	
	public String buildAdvicePieces(AdviceTable at){
		String pieces = "";
		int size = table.size();
		boolean returns = false;
		CodeSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			returns = temp.doesReturn();
			// Build Before
			if(at.hasAdvice(temp.getSignature(),"before")){
				pieces += "function aophp_before_"+temp.getNameNum()+temp.getSignature()+"{\n";
				pieces += at.getAdviceCode(temp.getSignature(),"before");
				pieces += "}\n\n";
			}
			// Build Around
			if(at.hasAdvice(temp.getSignature(),"around")){
				pieces += "function aophp_around_"+temp.getNameNum()+temp.getSignature()+"{\n";
				if(returns){
					// Around Advice, Returns
					//Call Function to Warp Advice (incase of Proceed or Return)
					pieces += aroundReturn(at.getAdviceCode(temp.getSignature(),"around"),temp.getName());
					//curFunc += at.getAdviceCode(temp.getSignature(),"around");
					pieces += "return $temp;";
				}else{
					// Around Advice, No Return
					// Call Function to Warp Advice (incase of Proceed)
					pieces += aroundNoReturn(at.getAdviceCode(temp.getSignature(),"around"),temp.getName());
					//curFunc += at.getAdviceCode(temp.getSignature(),"around");
				}
				pieces += "}\n\n";
			}
			// Build After
			if(at.hasAdvice(temp.getSignature(),"after")){
				pieces += "function aophp_after_"+temp.getNameNum()+temp.getSignature()+"{\n";
				pieces += at.getAdviceCode(temp.getSignature(),"after");
				pieces += "}\n\n";
			}
		}
		return pieces;
	}
	
	public String buildAdviceFunctions(AdviceTable at){
		String funcs = "";
		int size = table.size();
		boolean returns = false;
		CodeSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			returns = temp.doesReturn();
			funcs += "function aophp_"+temp.getNameNum()+temp.getSignature()+"{\n";
			// Call Before
			if(at.hasAdvice(temp.getSignature(),"before")){
				funcs += "	aophp_before_"+temp.getNameNum()+temp.getSignature()+";\n";
			}
			// Call Around
			if(at.hasAdvice(temp.getSignature(),"around")){
				if(returns){
					funcs += "	$temp = aophp_around_"+temp.getNameNum()+temp.getSignature()+";\n";
				}else{
					funcs += "	aophp_around_"+temp.getNameNum()+temp.getSignature()+";\n";
				}
			}else{
				if(returns){
					funcs += "	$temp = "+temp.getSignature()+";\n";
				}else{
					funcs += temp.getSignature()+";\n";
				}
			}
			// Call After
			if(at.hasAdvice(temp.getSignature(),"after")){
				funcs += "	aophp_after_"+temp.getNameNum()+temp.getSignature()+";\n";
			}
			if(returns){
				funcs += "return $temp;";
			}
			funcs += "}\n\n";
		}
		return funcs;
	}
	
	// The word proceed in any Strings or Comments will be replaced
	// This could cause an Issues with Printing the correct Strings
	// Will need to Change this in a Later Version
	private String aroundNoReturn(String advice, String funcName){
		String temp = "";
		temp = advice.replace("proceed",funcName);
		return temp;
	}
	
	// The word proceed or return in any Strings or Comments will be replaced
	// This could cause an Issues with Printing the correct Strings
	// Will need to Change this in a Later Version
	private String aroundReturn(String advice, String funcName){
		String temp = "";
		//String blah = "$temp = "+funcName;
		temp = advice.replace("proceed","$temp = "+funcName);
		//temp = temp.replace('@','$');
		temp = temp.replace("return","$temp = ");
		return temp;
	}
}
