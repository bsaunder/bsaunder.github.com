/*
   (c) 2004-2005 John W. Stamey, Bryan T. Saunders, and Matthew Cameron.
    This program is licensed under the GNU General Public License.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

public class AdviceSymbol{
	private String advice; // Type of Advice
	private String jptype; // Type of Joinpoint
	private String joinpoint; // Full Joinpoint
	private String signature; // JP Signature
	private boolean isReturning; // Does Return
	private String code; // Advice Code
	
	public AdviceSymbol(String signature, String adviceType, String jpType, String code) {
		this.signature = signature;
		this.advice = adviceType;
		this.jptype = jpType;
		this.code = code;
		isReturning = (jpType.equals("execr"))?true:false;
		joinpoint = jpType+"("+signature+")";
	}
	public String getAdvice() {
		return advice;
	}
	public void setAdvice(String advice) {
		this.advice = advice;
	}
	public String getJptype() {
		return jptype;
	}
	public void setJptype(String type) {
		this.jptype = type;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public boolean isReturning() {
		return isReturning;
	}
	public void setReturning(boolean isReturning) {
		this.isReturning = isReturning;
	}
	public String getJoinpoint() {
		return joinpoint;
	}
	public void setJoinpoint(String joinpoint) {
		this.joinpoint = joinpoint;
	}
}
