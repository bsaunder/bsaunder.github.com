/*
   (c) 2004-2005 John W. Stamey, Bryan T. Saunders, and Matthew Cameron.
    This program is licensed under the GNU General Public License.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

import java.util.*;

public class AdviceTable {
	private LinkedList<AdviceSymbol> table = new LinkedList<AdviceSymbol>();
	
	public AdviceTable(){}
	
	public void addAdvice(AdviceSymbol newAdvice){
		table.add(newAdvice);
	}
	
	public String getAdviceCode(String sig,String type){
		String advice = "// No "+type+" Advice";
		int size = table.size();
		AdviceSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			if(temp.getSignature().equals(sig) && temp.getAdvice().equalsIgnoreCase(type)){
				advice = temp.getCode();
				break;
			}
		}
		return advice;
	}
	
	public CodeTable makeCodeTable(){
		CodeTable t = new CodeTable();
		boolean found = false;
		AdviceSymbol temp;
		for(int i = 0; i<table.size();i++){
			temp = table.get(i);
			if(!t.hasSignature(temp.getSignature())){
				t.addCode(new CodeSymbol(temp.getJoinpoint(),temp.getSignature(),temp.isReturning()));
			}
		}
		return t;
	}
	
	public boolean hasAdvice(String sig,String type){
		boolean found = false;
		int size = table.size();
		AdviceSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			if(temp.getSignature().equals(sig) && temp.getAdvice().equalsIgnoreCase(type)){
				found = true;
				break;
			}
		}
		return found;
	}
	
	public void printTable(){
		System.out.println("Advice Table:");
		int size = table.size();
		AdviceSymbol temp;
		for(int i = 0; i<size;i++){
			temp = table.get(i);
			System.out.println("  - "+temp.getAdvice()+" "+temp.getJptype()+"("+temp.getSignature()+") : "+temp.getCode());
		}
	}
}
