import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/*
(c) 2004-2005 John W. Stamey, Bryan T. Saunders, and Matthew Cameron.
 This program is licensed under the GNU General Public License.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

public class Main {

	public static void main(String[] args) {
		/*
		 * Determine Aspect File(s)
		 * Run through Aspect File(s) -> Generate Advice Symbol Table
		 *  - Only One Piece of Each type of Advice per Joinpoint
		 * Make List of Used Original Functions from Symbol Table
		 * Generate Aspect Functions
		 * Start New Temp File
		 *  - Insert Aspect Functions
		 *  - Process File
		 *    - Replace Function Calls w/ New Functions
		 * Close Out Temp File
		 */
		
		// Only Passing in Args 0 & 1
		// args[0] - Path of Original PHP File
		// args[1] - Name of Original PHP File
		// args[2] - Full Path to Generated PHP File
		//File phpInFile = new File(args[0]); // Original PHP File
		String phpDir = args[0];
		File phpOutFile = new File(args[2]); // Generated PHP File
		File phpInFile = new File(args[0]+args[1]);
		
		/*for(int i = 0;i<args.length;i++){
			System.out.println(args[i]+" - "+i);
		}*/
		
		try{
			// Determine Need for AOPHP
			AdviceTable aoTable = new AdviceTable();
			PointcutTable pcTable = new PointcutTable();
			String AspectFilePath = "";
			String lineIn = "";
			boolean aophpReq = false;
			Scanner phpIn = new Scanner(phpInFile);
			lineIn = phpIn.nextLine();
			phpIn.close();
			if(lineIn.contains("<?aophp")){
				System.out.println("Aspect Weaving Required..");
				aophpReq = true;
				
				// Get Aspect Files
				int startPos = lineIn.indexOf("filename=")+10;
				AspectFilePath = lineIn.substring(startPos,lineIn.indexOf("\"",startPos));
				System.out.println("Aspect File: "+AspectFilePath);
				String[] aspectFiles = AspectFilePath.split(",");
				// Get Debug Status (Implemented at a Later Date)
				
				// Get Advice From Aspect Files & Build Advice Table
				File temp;
				for(int i = 0; i < aspectFiles.length; i++){
					temp = new File(phpDir+aspectFiles[i]);
					Scanner aofileIn = new Scanner(temp);
					while(aofileIn.hasNext()){
						lineIn = aofileIn.nextLine();
						// If Pointcut, Add to Pointcut Table
						if(lineIn.contains("pointcut") && lineIn.contains("=")){
							// Get Pointcut Information
							// Syntax: pointcut name = JP | JP;
							String jpName = lineIn.substring(lineIn.indexOf("pointcut")+8,lineIn.indexOf("=")).trim();
							//System.out.println("JP Name: '"+jpName+"'");
							String jpSigs = lineIn.substring(lineIn.indexOf("=")+1,lineIn.indexOf(";")).trim();
							//System.out.println("JP Sigs: '"+jpSigs+"'");
							pcTable.addPC(new PointcutSymbol(jpName,jpSigs));
						}else if(startsAdvice(lineIn)){
							// If Advice, Add to Advice Table
							// Syntax: AdviceT(): JP(SIG) | JP(SIG) {...}
							String block = grabAdviceBlock(lineIn,aofileIn);
							//System.out.println(block);
							String adviceT = block.substring(0,block.indexOf("(")).trim();
							//System.out.println("AType: "+adviceT);
							String adviceJP = block.substring(block.indexOf(":")+1,block.indexOf("#")).trim();
							//System.out.println("JP: '"+adviceJP+"'");
							String adviceCode = block.substring(block.indexOf("#")+1,block.length());
							//System.out.println("Code: "+adviceCode);
							
							// Add Advice to Table
							// Determine if adviceJP is a Pointcut
							// if So, Replace with Pointcut Sig
							if(pcTable.contains(adviceJP)){
								adviceJP = pcTable.getSigs(adviceJP);
								//System.out.println("Was NPC, Now is: "+adviceJP);
							}
							
							// Breakout & Breakdown Indiviual JP's to Add to Advice Table
							if(adviceJP.contains("|")){
								// Multiple JP's
								System.out.println(adviceJP);
								String[] jpList = adviceJP.split("|");
								String jp = "";
								for(int k = 0; k<jpList.length;k++){
									if(jpList[k].equals("|")){
										jp = jp.trim();
										String jpType = jp.substring(0,jp.indexOf("("));
										//System.out.print(" - JPType: "+jpType);
										String jpSig = jp.substring(jp.indexOf("(")+1,jp.lastIndexOf(")"));
										//System.out.print(" - Sig: "+jpSig);
										aoTable.addAdvice(new AdviceSymbol(jpSig,adviceT,jpType,adviceCode));
										jp = "";
									}else{
										jp += jpList[k];
									}
								}
								String jpType = jp.substring(0,jp.indexOf("("));
								//System.out.print(" - JPType: "+jpType);
								String jpSig = jp.substring(jp.indexOf("(")+1,jp.lastIndexOf(")"));
								//System.out.print(" - Sig: "+jpSig);
								aoTable.addAdvice(new AdviceSymbol(jpSig,adviceT,jpType,adviceCode));
								
							}else{
								// Single JP
								String jpType = adviceJP.substring(0,adviceJP.indexOf("("));
								//System.out.print(" - JPType: "+jpType);
								String jpSig = adviceJP.substring(adviceJP.indexOf("(")+1,adviceJP.lastIndexOf(")"));
								//System.out.print(" - Sig: "+jpSig);
								aoTable.addAdvice(new AdviceSymbol(jpSig,adviceT,jpType,adviceCode));
							}
								
						}
						
					}
				}
				
				pcTable.printTable();
				aoTable.printTable();
				
				CodeTable cTable = aoTable.makeCodeTable();
				cTable.printTable();
				
				// Generate Aspect Functions
				System.out.println("Advice Functions:");
				System.out.println("----------");
				String aoFunctions = cTable.genAspectFuncs(aoTable);
				System.out.println(aoFunctions);
				System.out.println("----------");				
				
				// Make New Temp File
				// Write Advice Functions to File
				// Replace Function Calls with Aspect Function Calls
				// Close File
				
				// Write New PHP File
				System.out.println("Writting PHP File w/ Aspects..");
				PrintWriter phpOut = new PrintWriter(new FileWriter(phpOutFile));
				Scanner origphp = new Scanner(phpInFile);
				// Read First Line and Throw it out
				String tempLine = origphp.nextLine();
				// Write Correct First Line and AOPHP Functions
				phpOut.println("<?php // Generated by AOPHP");
				//phpOut.print("\n"+aoFunctions+"\n\n");
				phpOut.print(cTable.buildAdvicePieces(aoTable));
				phpOut.print(cTable.buildAdviceFunctions(aoTable));
				// Write the rest of the Original PHP
				while(origphp.hasNext()){
					tempLine = origphp.nextLine();
					// Scan line for Mention of Original Function Name
					//     and Replace with AOPHP Function Name
					//System.out.println("LINE: "+temp);
					phpOut.println(cTable.scanLine(tempLine));
				}
				origphp.close();
				phpOut.close();
			}else{
				// AOPHP Not Required
				// Write Out Original Code
				System.out.println("Writting Original PHP..");
				PrintWriter phpOut = new PrintWriter(new FileWriter(phpOutFile));
				BufferedReader origphp = new BufferedReader(new FileReader(phpInFile));
				while(origphp.ready()){
					lineIn = origphp.readLine();
					phpOut.println(lineIn);
				}
				origphp.close();
				phpOut.close();
			}
			System.out.println("Parsing Complete.");
			
		}catch(Exception e){
			System.err.println("AOPHP Error!");
			e.printStackTrace();
		}
	}
	
	public static boolean startsAdvice(String line){
		return((line.contains("before(")||line.contains("after(")||line.contains("around(")) && line.contains(":"));
	}
	
	public static String grabAdviceBlock(String curLine, Scanner in)throws IOException{		
		String code = "";
		String front = "";
		char curChar;
		int start = 0;
		int letCount = 0;
		int brackCount = 0;
		int i = 0;
		int sCount = 0; // Anything after a // will Break to next line
		boolean inComment = false;
		boolean inString = false;
		boolean comment = false;
		boolean foundFB = false;
		boolean gotFront = false;
		
		if(curLine.contains("{")){ // Function Starts on Current Line
			front = curLine.substring(0,curLine.indexOf("{"));
			gotFront = true;
			start = curLine.indexOf("{")+1;
			brackCount++;
			// Scan Through Current Line for the Opening Bracket
			//System.out.println("Current Line..");
			for(i=start;i<curLine.length();i++){
				curChar = curLine.charAt(i);
				if(curChar == '{'){
					if(!inString && !inComment){
						brackCount++;
					}
				}else if(curChar == '}'){
					if(!inString && !inComment){
						brackCount--;
						if(brackCount == 0){
							return front+"#"+code;
						}
					}
				// If an Escape Character, Ignore Next Character
				}else if(curChar == '\\'){
					i++;
				// Set if In a String or Not
				}else if(curChar == '"'){
					if(!inComment){
						inString = !inString;
					}
				}else if(curChar == '/'){
					if(!inString){
						if(inComment){
							if(i!=0 && curLine.charAt(i-1)=='*'){
								inComment = false;
							}
						}else{
							if(curLine.charAt(i+1)=='*'){
								inComment = true;
							}else if(curLine.charAt(i+1)=='/'){
								break;
							}
						}						
					}
				}
				code += curChar;
				if(brackCount == 0){
					return front+"#"+code;
				}
			}
		}
		foundFB = false;
		if(!gotFront){
			front += curLine;
		}
		while(in.hasNext()){
			curLine = in.nextLine();
			for(i=0;i<curLine.length();i++){
				curChar = curLine.charAt(i);
				if(curChar == '{'){
					if(brackCount == 0){
						foundFB = true;
						gotFront = true;
					}
					if(!inString && !inComment){
						brackCount++;
					}
				}else if(curChar == '}'){
					if(!inString && !inComment){
						brackCount--;
						if(brackCount == 0){
							return front+"#"+code;
						}
					}
				// If an Escape Character, Ignore Next Character
				}else if(curChar == '\\'){
					i++;
				// Set if In a String or Not
				}else if(curChar == '"'){
					if(!inComment){
						inString = !inString;
					}
				}else if(curChar == '/'){
					if(!inString){
						if(inComment){
							if(i!=0 && curLine.charAt(i-1)=='*'){
								inComment = false;
							}
						}else{
							if(curLine.charAt(i+1)=='*'){
								inComment = true;
							}else if(curLine.charAt(i+1)=='/'){
								break;
							}
						}						
					}
				}
				if(foundFB){
					foundFB = false;
				}else{
					if(gotFront){
						code += curChar;
					}else{
						front += curChar;
					}
					//code += curChar;
				}
				
				if(brackCount == 0){
					return front+"#"+code;
				}
			}
		}
		
		//System.out.println(code);
		return code;
	}

}
