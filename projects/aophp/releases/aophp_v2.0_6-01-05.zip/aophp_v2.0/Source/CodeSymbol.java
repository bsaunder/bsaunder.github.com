/*
(c) 2004-2005 John W. Stamey, Bryan T. Saunders, and Matthew Cameron.
 This program is licensed under the GNU General Public License.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

public class CodeSymbol{
	private String joinpoint; // Full JP
	private String signature; // JP Signature
	private String sigName; // Function or Variable Name
	private int nameNum; // Random Name Number
	private boolean type;
	
	public CodeSymbol(String joinpoint, String signature, boolean type) {
		this.joinpoint = joinpoint;
		this.signature = signature;
		this.type = type;
		if(joinpoint.contains("exec(")||joinpoint.contains("execr(")){
			// Joinpoint is for a Function
			sigName = signature.substring(0,signature.indexOf("(")).trim();
		}else if(joinpoint.contains("set(")||joinpoint.contains("get(")){
			// Joinpoint is for a Variable
		}
		this.nameNum = new Double(Math.random()*100).intValue();
	}
	public String getName() {
		return sigName;
	}
	public void setName(String name) {
		this.sigName = name;
	}
	public String getJoinpoint() {
		return joinpoint;
	}

	public void setJoinpoint(String name) {
		this.joinpoint = name;
	}
	
	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}
	
	public boolean doesReturn() {
		return type;
	}

	public void setReturn(boolean type) {
		this.type = type;
	}
	public int getNameNum() {
		return nameNum;
	}
}
