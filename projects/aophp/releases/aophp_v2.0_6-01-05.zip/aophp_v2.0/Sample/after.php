<?aophp filename="aotest.aophp,aotest2.aophp" debug="off"

function add($x,$y){
  return $x+$y;
}

function sub($x,$y){
  return $x-$y;
}

function div($a,$b){
  return $a/$b;
}

function say($text){
  echo "PHP Says: $text <br>";
}

say("Hello World");
echo "<br><br>";

$n1 = 5;
$n2 = 10;
echo "N1: $n1 | N2: $n2<br>";

$total = add($n1,$n2);
echo "Total of N1 & N2: $total <br><br><br>";

$diff = sub($n1,$n2);
echo "Difference of N1 & N2: $diff <br><br><br>";

$quotient = div($n1,0);
echo "Quotient of N1 & 0: $quotient <br>";


?>