/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Tokenizer Class
Implemented as a Dynamic Queue

*/

#include <iostream>
#include <string>
#include "StringTok.h"
using namespace std;

StringTok::StringTok(string in, string d){
	front = NULL;
	rear = NULL;
	orig = in;
	delim = d;
	
}

StringTok::StringTok(const StringTok & original){
	token *temp; // Used to Create the Nodes
	token *current; // The Node were Currently on
	token *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new token;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new token;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

StringTok & StringTok::operator = (const StringTok & original){
	token *temp; // Used to Create the Nodes
	token *current; // The Node were Currently on
	token *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new token;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new token;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

void StringTok::tokenize(){
	string in = orig;
	int curPos = -1;
	string tmp = "";
	/**** DEBUGGING **/ //cout << "STRTOK: " << in << endl;
	curPos = in.find(delim);
	/**** DEBUGGING **/ //cout << curPos << "\n";
	while(curPos > 0){
		tmp = in.substr(0,curPos);
		this->insertToken(tmp);
		in.erase(0,curPos+1);
		tmp = "";
		curPos = in.find(delim);
	}
	this->insertToken(in);
}

void StringTok::tokenizeIgnoreStrings(){
	StringFinder strFind(orig);
	string in = orig;

	int curPos = -1;
	string tmp = "";
	bool inString = false;
	/**** DEBUGGING **/ //cout << "STRTOK: " << in << endl;
	curPos = in.find(delim);
	if(curPos == -1){
		this->insertToken(in);
		return;
	}
	// Throw Away First Token, Garbage
	//in.erase(0,curPos);
	//curPos = in.find(delim);
	/**** DEBUGGING **/ //cout << curPos << "\n";
	while(curPos > 0){
		strFind.reset(in);
		strFind.findStrings();
		if(strFind.isInString(curPos)){
			/**** DEBUGGING **/ //cout << "INSTRING: " << in.substr(0,curPos+1) << endl;
			tmp += in.substr(0,curPos+1);
			in.erase(0,curPos+1);
			inString = true;
		}else{
			tmp += in.substr(0,curPos);
			this->insertToken(tmp);
			in.erase(0,curPos+1);
			tmp = "";
			inString = false;
		}	
		curPos = in.find(delim);
		/**** DEBUGGING **/ //cout << "TMP: " << curPos << " - "<< in << endl;
		/**** DEBUGGING **/ //strFind.printList();
	}
	/**** DEBUGGING **/ //cout << "AFTER: " << tmp << endl;
	if(inString){
		this->insertToken(tmp+in);
	}else{
		this->insertToken(in);
	}
}

void StringTok::insertToken(string item){
	token *temp = new token;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

string StringTok::getRemaining() const{
	token *temp = new token;
	temp = front;
	string line = "";
	while(temp != NULL){
		line += temp->info + delim;
		temp = temp->next;
	}
	return line;
}

void StringTok::dumpTokens() const{
	token *temp = new token;
	temp = front;
	while(temp != NULL){
		cout << "--> "<< temp->info << endl;
		temp = temp->next;
	}
}

int StringTok::countTokens() const{
	token *temp = new token;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	return x;
}

string StringTok::getNext(){
	string item;
	token *temp = front;
	item = front->info;
	front = front->next;
	delete temp;
	return item;
}

string StringTok::getOrig(){
	return orig;
}

bool StringTok::isEmpty() const{
	return (front == NULL);
}

bool StringTok::hasNext() const{
	return !isEmpty();
}

void StringTok::reset(string text,string d){
	string item;
	while(!isEmpty()){
		item = getNext();
	}
	orig = text;
	delim = d;
}

StringTok::~StringTok(){
	string item;
	while(!isEmpty()){
		item = getNext();
	}
}
