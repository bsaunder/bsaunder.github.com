/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Tokenizer Class
Implemented as a Dynamic Queue

*/

#ifndef STRINGTOK
#define STRINGTOK
#include <iostream>
#include <string>
#include "StringFinder.h"
using namespace std;

struct token{
	string info;
	token *next;
};

class StringTok{
	private:
		token *front;
		token *rear;
		string orig;
		string delim;
	public:
		StringTok(string,string);
		StringTok(const StringTok &);
		StringTok & operator = (const StringTok &);
		void tokenize();
		void tokenizeIgnoreStrings();
		void insertToken(string);
		string getNext();
		bool hasNext() const;
		bool isEmpty() const;
		string getRemaining() const;
		void dumpTokens() const;
		int countTokens() const;
		string getOrig();
		void reset(string,string);
		~StringTok();
};

#endif