/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Advice Parser Class
Designed to Parse a Particular Type of Advice informtion from an Aspect File

*/
#include <ctime>
#include "AdviceParser.h"
#include "StringTok.h"
#include "StringManip.h"

AdviceParser::AdviceParser(string newType){
	advType = newType;
	advCode1 = advType.substr(0,advType.length());
	advCode2 = advType.substr(1,advType.length());
	/*if(advType.compare("after")==0){
		advCode = advType.substr(0,advType.length());
	}else{
		advCode = advType.substr(1,advType.length());
	}*/
}

void AdviceParser::setType(string newType){
	advType = newType;
}

string AdviceParser::getType(){ 
	return advType; 
}

AdviceTable AdviceParser::parse(string code,PointcutTable pcTable){
	// Empty Table
	aTable.reset();

	/*** DEBUGGING **/ //cout << "PARSING -----> " << advType << endl;
	StringTok tok(code,advType);
	tok.tokenizeIgnoreStrings();
	/*** DEBUGGING **/ //cout << "Dumping Tokens" << endl; tok.dumpTokens();
	
	string curr = "";
	int tCount = tok.countTokens();
	advice adv;
	StringFinder sf;
	StringManip sm;
	for(int i=0;i<tCount;i++){
		curr = tok.getNext();
		/*** DEBUGGING **/ //cout << "CUR: " << curr << endl;
		sf.reset(curr);
		//cout << i << " - ";
		/*** DEBUGGING **/ //cout << "ADVCODE1: " << advCode1 << " - " << curr.substr(0,advCode1.length()) << endl;
		/*** DEBUGGING **/ //cout << "ADVCODE2: " << advCode2 << " - " << curr.substr(0,advCode2.length()) << endl;
		int chk1 = curr.substr(0,advCode1.length()).compare(advCode1);
		int chk2 = curr.substr(0,advCode2.length()).compare(advCode2);
		if(chk1 == 0 || chk2 == 0){
			// Token is Valid
			/*** DEBUGGING **/ //cout << "VAL: " << curr << endl;
			// Parse out Advice

			// ID = ((CurrTime) * (StrLength * 3)) / 4;
			adv.id = (time(0) * (curr.length()*3)) / 4;
			
			// Get Incoming Parameters (inparams)
			int p = curr.find("(");
			curr.erase(0,p);
			sf.reset(curr);
			sf.findStrings();
			p = curr.find(")");
			while(sf.isInString(p)){
				p = curr.find(")");
			}
			p++;
			adv.inparams = curr.substr(1,p-2);
			curr.erase(0,p);
			/*** DEBUGGING **/ //cout << "CUR 2: " << curr << endl;
			/*** DEBUGGING **/ //cout << "ADV: " << adv.inparams << endl;

			// Get Incoming Param. Count (inparamcount)
			StringTok tok(adv.inparams,",");
			tok.tokenizeIgnoreStrings();
			adv.inparamcount = tok.countTokens();
			/*** DEBUGGING **/ //tok.dumpTokens();
			/*** DEBUGGING **/ //cout << "ADV C: " << adv.inparamcount << endl;

			// Split Advice Definition from Code
			p = curr.find(":")+1;
			curr.erase(0,p);
			tok.reset(curr,"{");
			tok.tokenizeIgnoreStrings();
			string advSect = tok.getNext();
			string cdeSect = tok.getRemaining();
			/*** DEBUGGING **/ //cout << "ADV: " << advSect << endl << "CDE: " << cdeSect << endl;

			// Get Code (code)
			adv.code = sm.grabCode(cdeSect);
			/*** DEBUGGING **/ //cout << "CODE: " << adv.code << endl;

			// Pointcut Check/Insertion
			/*** DEBUGGING **/ //cout << "PC CHECK: " << advSect << "---END" << endl;
			string tmpAdvice = advSect;
			string tmp = "";
			string newAdvice = "";
			bool change = false;
			tok.reset(tmpAdvice,"|");
			tok.tokenizeIgnoreStrings();
			int cnt2 = tok.countTokens();
			for(int m=0;m<cnt2;m++){
				tmp = tok.getNext();
				tmp = sm.trimWhiteSpace(tmp);
				/*** DEBUGGING **/ //cout << tmp << endl;
				if(pcTable.isInTable(tmp)){
					// Pointcut Found
					change = true;
					pointcut x = pcTable.findByName(tmp);
					newAdvice += x.joinpoints;
					if(m != cnt2-1){
						newAdvice += " | ";
					}
				}else{
					newAdvice += tmp;
					if(m != cnt2-1){
						newAdvice += " | ";
					}
				}

			}
			if(change){
				advSect = newAdvice;
			}else{
				advSect = tmpAdvice;
			}
			
			
			// Break out Indiviual Advice Sections
			tok.reset(advSect,"|");
			tok.tokenizeIgnoreStrings();
			int cnt = tok.countTokens();
			/*** DEBUGGING **/ //cout << "TOK CNT: " << cnt << endl;
			/*** DEBUGGING **/ //cout << "Dumping Tokens: " << endl; tok.dumpTokens();
			for(int i=0;i<cnt;i++){
				string curSect = tok.getNext();
				/**** DEBUGGING **/ //cout << "TOK " << i << ": " << curSect << endl;

				// Get Joinpoint Type (jptype)
				/*** DEBUGGING **/ //cout << "CUR 3: " << curr << endl;
				p = curSect.find(":")+1;

				int p2 = curSect.find_first_of("(");
				adv.jptype = sm.trimWhiteSpace(curSect.substr(p,p2-p));
				curSect.erase(0,p2+1);
				/*** DEBUGGING **/ //cout << "CUR 4: " << curSect << endl;
				/*** DEBUGGING **/ //cout << "JPT: |" << adv.jptype << "|" << endl;

				// Check for Args
				// Get Signature (signature)
				// Get Advice Arguments (args)
				if(curSect.find("&")==string::npos){
					// No Args
					adv.args = "null";
					p = curSect.rfind(")");
					adv.signature = curSect.substr(0,p);
				}else{
					// Has Args
					p = curSect.find("&");
					adv.signature = curSect.substr(0,p-1);
					curSect.erase(0,p);
					adv.args = curSect;
				}

				// Get Signature Param. Count & Target (paramcount,target)
				p = adv.signature.find("(");
				adv.target = adv.signature.substr(0,p);
				/*** DEBUGGING **/ //cout << adv.target << endl;
				p2 = adv.signature.length() - p;
				string params = adv.signature.substr(p+1,p2-2);
				/*** DEBUGGING **/ //cout << "PARAMS: " << params << endl;
				StringTok pc(params,",");
				pc.tokenizeIgnoreStrings();
				adv.paramcount = pc.countTokens();
				/*** DEBUGGING **/ //cout << "PAR CNT: " << adv.paramcount << endl;

	
				cout << "Advice: " << advType << "|" << adv.jptype << " -> " << adv.signature << "|" << adv.args << endl;
				aTable.insertAdvice(adv);
				adv.args = "";
				adv.signature = "";
				adv.target = "";
				adv.jptype = "";
				adv.paramcount = 0;
			}
			

			

		}else{
			// Invalid Token, Move On
			/*** DEBUGGING **/ //cout << "INVALID" << endl;
		}
	}
	
	return aTable;
}
