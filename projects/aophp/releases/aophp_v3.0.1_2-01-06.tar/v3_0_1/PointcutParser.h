/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Pointcut Parser Class
Designed to Parse Named Pointcut informtion from an Aspect File

*/

#ifndef POINTCUTPARSER
#define POINTCUTPARSER
#include <iostream>
#include <string>
#include "PointcutTable.h"
using namespace std;

class PointcutParser{
	private:
		string code;

		PointcutTable aTable;
	public:
		PointcutParser();
		PointcutTable parse(string);
};

#endif