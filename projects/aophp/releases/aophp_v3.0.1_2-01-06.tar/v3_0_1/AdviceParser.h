/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Advice Parser Class
Designed to Parse a Particular Type of Advice informtion from an Aspect File

*/

#ifndef ADVICEPARSER
#define ADVICEPARSER
#include <iostream>
#include <string>
#include "AdviceTable.h"
#include "PointcutTable.h"
using namespace std;

class AdviceParser{
	private:
		string advType;
		string advCode1,advCode2;
		string code;

		AdviceTable aTable;

	public:
		AdviceParser(string);
		void setType(string);
		string getType();
		AdviceTable parse(string,PointcutTable);
};

#endif