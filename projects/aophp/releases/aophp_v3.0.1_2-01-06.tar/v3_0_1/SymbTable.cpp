/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Symbol Table Class
Implemented as a Dynamic List

*/

#include <iostream>
#include <string>
#include "SymbTable.h"
using namespace std;

SymbTable::SymbTable(){
	front = NULL;
	rear = NULL;
	count = 0;
}

SymbTable::SymbTable(const SymbTable & original){
	symbol *temp; // Used to Create the Nodes
	symbol *current; // The Node were Currently on
	symbol *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new symbol;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new symbol;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

SymbTable & SymbTable::operator = (const SymbTable & original){
	symbol *temp; // Used to Create the Nodes
	symbol *current; // The Node were Currently on
	symbol *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new symbol;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new symbol;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

SymbTable::~SymbTable(){
	reset();
}

void SymbTable::reset(){
	while(!isEmpty()){
		symbol *temp = front;
		front = front->next;
		delete temp;
	}
}

advice SymbTable::getFirst(){
	return front->info;
}

advice SymbTable::getLast(){
	return rear->info;
}

advice SymbTable::getByID(int x){
	symbol *temp = front;
	while(temp != NULL){
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void SymbTable::insertAdvice(advice item){
	symbol *temp = new symbol;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int SymbTable::countAdvice(){
	symbol *temp = new symbol;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int SymbTable::findBySig(string sig){
	symbol *temp = new symbol;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.signature.compare(sig) == 0){
			return x;
		}
		temp = temp->next;
	}
	count = x;
	return x;
}

bool SymbTable::isEmpty() const{
	return (front == NULL);
}

bool SymbTable::hasNext() const{
	return !isEmpty();
}

void SymbTable::dumpAdvice() const{
	symbol *temp = new symbol;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.signature << endl;
		temp = temp->next;
	}
}

