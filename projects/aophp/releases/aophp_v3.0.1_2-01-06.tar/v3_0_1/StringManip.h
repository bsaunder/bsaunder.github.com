/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Manipulation Class
Set of String Manipulation functions used in aoPHP

*/

#ifndef STRINGMANIP
#define STRINGMANIP
#include <iostream>
#include <string>
using namespace std;

class StringManip{
	private:
		// None
	public:
		string getFLetter(string);
		string getLLetter(string);
		string getRight(string,int);
		string getLeft(string,int);
		void wordSwap(string&,string&);
		string trimWhiteSpace(string);
		string stripComments(string);
		string grabCode(string);

};

#endif