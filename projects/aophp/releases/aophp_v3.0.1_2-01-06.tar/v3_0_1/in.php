<?php
// dumb comment
/* hello world */
echo "Hello World";
//aophpinclude("file1.aophp,file2.aophp");
aophpinclude("file1.aophp,file2.aophp,file3.aophp");
echo "aoPHP v3 beta";
/*echo "aoPHP v3 beta";

*/
?>