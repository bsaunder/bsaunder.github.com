/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Manipulation Class
Class of String Manipulation functions used in aoPHP

*/
					
#include <iostream>
#include <string>
#include "StringManip.h"
#include "StringFinder.h"
using namespace std;

string StringManip::getFLetter(string text)
{
	string letter;
	letter = text.substr(0,1);
	return letter;
}

string StringManip::getLLetter(string text)
{
	string letter;
	letter = text.substr(text.length()-1,1);
	return letter;
}

string StringManip::getRight(string text, int x)
{
	string letter;
	letter = text.substr(text.length()-x,x);
	return letter;
}

string StringManip::getLeft(string text, int x)
{
	string letter;
	letter = text.substr(0,x);
	return letter;
}

// Remove All Whitespace From a String
string StringManip::trimWhiteSpace(string text){
	string trimmed = "";
	char c;
	for(int i=0;i<text.length();i++){
		c = text.at(i);
		if(c != ' ')
			trimmed += c;
	}
	return trimmed;
}

// Remove all of the Comments from the Given PHP Code String
//
// *NOTE*: Could Be Done with Regular Expressions as Well.
//		Regular Expressions would Probably be Quicker/More Precise
//
string StringManip::stripComments(string input){
	string output = "";
	int status = 0;
	// Strip All Comments
	// 0 - Not In Comment
	// 1 - Full Line Comment
	// 2 - Block Type Comment
	char t;
	for(int i=0;i<input.length();i++){
		t = input.at(i);
		if(status == 0){
			if(t == '/'){
				if(input.at(i+1) == '/'){
					status = 1;
				}else if(input.at(i+1) == '*'){
					status = 2;
				}else{
					output += t;
				}
			}else{
				output += t;
			}
		}else if(status == 1){
			if(t == '\n'){
				status = 0;
			}
		}else if(status == 2){
			if(t == '*' && input.at(i+1) == '/'){
				status = 0;
				i++;
			}
		}
	}
	return output;
}

void StringManip::wordSwap(string & word1, string & word2)
{
	string holder;
	word1 = holder;
	word1 = word2;
	word2 = holder;
}

string StringManip::grabCode(string code){
	string c = "";
	char x;
	int level = 1;
	StringFinder sf(code);
	sf.findStrings();
	for(int i=0;i<code.length();i++){
		x = code.at(i);
		if(x == '{'){
			if(!sf.isInString(x)){
				level++;
			}
		}else if(x == '}'){
			if(!sf.isInString(x)){
				level--;
			}
		}
		if(level == 0){
			break;
		}else{
			c += x;
		}		
	}
	return c;
}
				   