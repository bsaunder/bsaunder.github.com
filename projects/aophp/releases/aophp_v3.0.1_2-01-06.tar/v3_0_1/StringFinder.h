/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Finder Class
Finds Strings within code, Based on " " - Ignores Escaped Quotes (\")

*/

#ifndef STRINGFINDER
#define STRINGFINDER
#include <iostream>
#include <string>
using namespace std;

class strPair{
	friend ostream& operator << (ostream& os, const strPair& s){
			return os << s.start << "," << s.end;
	}
	public:
		strPair(){start = end = 0;}
		strPair(int x,int y){start = y; end = y;}
		int start;
		int end;
		const bool operator == (const strPair & r){ return (start == r.start && end == r.end); }
		const bool operator <= (const strPair & r){ return (end <= r.start); }
		const bool operator >= (const strPair & r){ return (end >= r.start); }
		void reset(){start = end = 0;}
};

struct node{
	strPair info;
	node *next;
};

class StringFinder{
	private:
		node *head;
		string code;
	public:
		StringFinder(string);
		StringFinder();
		StringFinder(const StringFinder &);
		// Overloaded Assignment
		~StringFinder();
		void findStrings();
		bool isInString(int);
		void makeEmpty();
		void insertItem(strPair);
		void removeItem(strPair);
		bool isItemInList(strPair);
		void printList();
		bool isEmpty();
		void reset(string);
};

#endif

