/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Main Weaver for aoPHP v3.0


To Do:
--------------
DONE) Open PHP Source File -> Parse to String
SKIP) Parse Include -> Check Parsing Status & Depth
DONE) Find aoPHP Include Tag -> Parse File Names
DONE) Open aoPHP Aspect Files -> Parse to String(s)
DONE) Parse Aspects
DONE) Parse Advice -> Advice Table w/ Symbols
) Generate Advice Functions
) Find Pointcuts -> Replace w/ Symbols
) Insert Advice Functions
) Weave Advice -> Replace Symbols w/ Function Calls
) Generate New Source File

Bug List:
--------------
1) **Feature: Does Not Parse Named Pointcuts
2) PARSE ERROR: If Advice Definition contains a String with Name of Advice, Invalid Parse Occurs
	ie: around($a,$b): execr(file1-c($x,$y))&arg1("around")&arg2(6)
	Note: Pipe "|" Not Allowed Either (just in def)
	FIXED: Invalid Tokenization by StringTok Class
3) PARSE ERROR: Adding Advice Multiple Times to Final Tables
	FIXED: Table Not Reset After Each Parse
4) PARSE ERROR: Not Properly Parsing More than 2 Files
	FIXED: Added Multiple Checks to Validate Advice Tokens in Parse

*/

#include <iostream>
#include <string>
#include <fstream>
#include "StringTok.h"
#include "AdviceTable.h"
#include "AdviceParser.h"
#include "PointcutTable.h"
#include "PointcutParser.h"
#include "StringManip.h"

using namespace std;

const int MAX_CHARS_LINE = 500;
const int ARG_CNT = 4;

const int COMPLETED = 0;
const int DECLINED = 1;
const int SRC_FILE_ERROR = 2;
const int INV_ASPECT_FILE = 3;
const int INV_ASPECT_ARGS = 4;
const int ASPECT_FILE_ERROR = 5;
const int WRONG_ARG_CNT = 99;

int main(int argc, char* argv[]){

	// Command Line Arguments
	// Only 1-4 Passed at Command Line
	// 0 - Full Path to Executable
	// 1 - PHP In File
	// 2 - PHP Out File
	// 3 - Include Status -> 0 On, 1 Off
	// 4 - Include Level -> 0 is Infinite

	// Check for Arguments
	/*
	// Argument Debug Loop
	cout << argc << endl;
	for(int i=0;i<argc;i++){
		cout << argv[i] << endl;
	}*/

	StringManip sm;

	if(argc != ARG_CNT+1){
		cerr << "ERR: Wrong Argument Count\n";
		return WRONG_ARG_CNT;
	}

	// Open PHP Source Input File
	ifstream inFile;
	inFile.open(argv[1],ios::in);
	if(!inFile){
		cerr << "ERR: Could Not Source Open File\n";
		return SRC_FILE_ERROR;
	}else{
		cout << "Opened Source File\n";
	}

	// Parse PHP Source File to String
	string phpSource = "";
	string tmp;
	while(!inFile.eof()){
		getline(inFile,tmp);
		phpSource += tmp + "\n";
	}
	inFile.close();
	phpSource = sm.stripComments(phpSource);
	/**** DEBUGGING **/ cout << endl << phpSource << endl;
	cout << "PHP Source Parsed\n";


	// Parse Includes (include, include_once, require, require_once)
	//*****************************
	//**** NOT YET IMPLEMENTED ****
	//*****************************
	// Syntax: include 'file.txt' || include "file.txt" || include('file.txt') || include("file.txt");
	//
	// All 4 commands are value returning
	// Included or Required scripts may return a value, ie. be used as a function
	/*
		$foo = include('incfile.php');
		echo $foo;
	*/
	//
	// include_once & require_once do not include if File is already included
	//		still return true(1)
	//
	// False(0) values are only returned if the File is Not Found
	//	
	// Code in Included File will be "Dropped In"
	//		replacing the orignal Include Statement
	//
	// Need to Watch for Special Cases Such As:
	/*
		if(include("file.txt")){ .. }
	*/
	// Simply "Dropping In" the code of the include
	//		here could cause compilation errors


	// Find aoPHP Include Tag
	int aopTagStart1 = 0;
	int aopTagStart2 = 0;
	int aopTagEnd = 0;
	int aopFileCount = 0;
	string *aopFileList;
	string *aopFileCode;
	aopTagStart1 = phpSource.find("aophpinclude(");
	aopTagStart2 = phpSource.find("(",aopTagStart1);
	aopTagEnd = phpSource.find(";",aopTagStart2);
	/**** DEBUGGING **/ //cout << aopTagStart1 << " - " << aopTagStart2 << " - " << aopTagEnd << endl;
	if(aopTagStart1 < 0){
		cerr << "ERR: aoPHP Include Not Found\n";
		return DECLINED;
	}else{
		int aopFileLength = aopTagEnd - (aopTagStart2+1);
		string aopFiles = phpSource.substr(aopTagStart2+2,aopFileLength-3);
		StringTok tok(aopFiles,",");
		tok.tokenize();
		/**** DEBUGGING **/ //cout << "-------------\n";
		/**** DEBUGGING **/ //tok.dumpTokens();
		/**** DEBUGGING **/ //cout << "-------------\n";
		aopFileCount = tok.countTokens();
		/**** DEBUGGING **/ //cout << "TOKCNT: " << aopFileCount << endl;
		aopFileList = new string[aopFileCount];
		if(aopFileCount == 0){
			cerr << "ERR: No Arguments Found in aophpinclude\n";
			return INV_ASPECT_ARGS;
		}
		for(int i=0;i<aopFileCount;i++){
			tmp = tok.getNext();
			int k = tmp.find(".aophp");
			if(k < 0){
				cout << "ERR: Invalid Aspect File Found\n";
				return INV_ASPECT_FILE;
			}else{
				aopFileList[i] = tmp;
			}
		}
		cout << "Using " << aopFileCount << " Aspect Files: " << aopFiles << endl;
	}
	int aopTagSize = aopTagEnd - aopTagStart1+1;
	phpSource.erase(aopTagStart1,aopTagSize);

	// Open aoPHP Aspect Files -> Parse to String(s)
	// String Array aopFileCode[] Contains Source Code For All Needed Aspect Files
	// Integer aopFileCount is the Number of Aspect Source Code Files
	aopFileCode = new string[aopFileCount];
	for(int i=0;i<aopFileCount;i++){
		tmp = aopFileList[i];
		ifstream aspectFile;
		aspectFile.open(tmp.c_str(),ios::in);
		if(!aspectFile){
			cerr << "ERR: Could Not Open Aspect File\n";
			return ASPECT_FILE_ERROR;
		}else{
			cout << "Opened Aspect File: " << tmp << "\n";
		}
		string tmpSource = "";
		tmp = "";
		while(!aspectFile.eof()){
			getline(aspectFile,tmp);
			tmpSource += tmp + "\n";
		}
		aopFileCode[i] = sm.stripComments(tmpSource);
		aspectFile.close();
	}
	cout << endl;
	
	cout << "Parsing Advice..." << endl;
	// Parse Advice out of Aspects -> Store in 3 Symbol Tables
	AdviceTable aop_Before; // Table to Store Before Advice
	AdviceTable aop_After; // Table to Store After Advice
	AdviceTable aop_Around; // Table to Store Around Advice
	PointcutTable pcTable;

	AdviceParser bef_parser("before");
	AdviceParser aro_parser("around");
	AdviceParser aft_parser("after");
	PointcutParser pcParser;

	// Need to Write/Define PointcutParse to Parse out Named Pointcuts
	//		Should Generate a PointcutTable

	for(int k=0;k<aopFileCount;k++){
		tmp = aopFileCode[k];
		/**** DEBUGGING **/ //cout << "File "<< k << ": " << tmp << endl;

		pcTable = pcParser.parse(tmp);
		if(pcTable.countPointcuts() > 0){
			pcTable.dumpPointcuts();
		}

		aop_Before.addToSelf(bef_parser.parse(tmp,pcTable));
		aop_Around.addToSelf(aro_parser.parse(tmp,pcTable));
		aop_After.addToSelf(aft_parser.parse(tmp,pcTable));
	}

	cout << endl;
	cout << "Dumping Before Advice" << endl; aop_Before.dumpAdvice(); cout << endl;
	cout << "Dumping Around Advice" << endl; aop_Around.dumpAdvice(); cout << endl;
	cout << "Dumping After Advice" << endl; aop_After.dumpAdvice(); cout << endl;
	
	cout << "-------------" << endl << "aoPHP Complete" << endl;
	return COMPLETED;
}
