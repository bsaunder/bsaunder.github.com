/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Advice Table Class
Implemented as a Dynamic List, Store Parsed Advice
 
*/

#ifndef ADVICE_TABLE
#define ADVICE_TABLE
#include <iostream>
#include <string>
using namespace std;

struct advice{
	int id;
	string inparams;
	int inparamcount;
	string jptype;
	string signature;
	string target;
	int paramcount;
	string code;
	string args;
};

struct symbol{
	advice info;
	symbol *next;
};

class AdviceTable{
	private:
		symbol *front;
		symbol *rear;
		int count;
	public:
		AdviceTable();
		AdviceTable(const AdviceTable &);
		AdviceTable & operator = (const AdviceTable &);
		void addToSelf(AdviceTable);
		void insertAdvice(advice);
		int findBySig(string);
		advice getFirst();
		advice getLast();
		advice getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dumpAdvice() const;
		int* dumpIDs();
		int countAdvice();
		void reset();
		~AdviceTable();
};

#endif