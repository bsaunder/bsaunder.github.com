/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Pointcut Table Class
Implemented as a Dynamic List, Store Named Pointcut Info

*/

#include <iostream>
#include <string>
#include "PointcutTable.h"
using namespace std;

PointcutTable::PointcutTable(){
	front = NULL;
	rear = NULL;
	count = 0;
}

PointcutTable::PointcutTable(const PointcutTable & original){
	pc_symbol *temp; // Used to Create the Nodes
	pc_symbol *current; // The Node were Currently on
	pc_symbol *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new pc_symbol;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new pc_symbol;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

PointcutTable & PointcutTable::operator = (const PointcutTable & original){
	pc_symbol *temp; // Used to Create the Nodes
	pc_symbol *current; // The Node were Currently on
	pc_symbol *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new pc_symbol;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new pc_symbol;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

PointcutTable::~PointcutTable(){
	reset();
}

void PointcutTable::reset(){
	while(!isEmpty()){
		pc_symbol *temp = front;
		front = front->next;
		delete temp;
	}
}

pointcut PointcutTable::getFirst(){
	return front->info;
}

pointcut PointcutTable::getLast(){
	return rear->info;
}

pointcut PointcutTable::getByID(int x){
	pc_symbol *temp = front;
	while(temp != NULL){
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

bool PointcutTable::isInTable(string pc){
	pc_symbol *temp = new pc_symbol;
	temp = front;
	while(temp != NULL){
		if(temp->info.name.compare(pc) == 0){
			return true;
		}
		temp = temp->next;
	}
	return false;
}

void PointcutTable::insertPointcut(pointcut item){
	pc_symbol *temp = new pc_symbol;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int PointcutTable::countPointcuts(){
	pc_symbol *temp = new pc_symbol;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

pointcut PointcutTable::findByName(string sig){
	pc_symbol *temp = new pc_symbol;
	temp = front;
	while(temp != NULL){
		if(temp->info.name.compare(sig) == 0){
			return temp->info;
		}
		temp = temp->next;
	}
	pointcut x;
	x.name = "null";
	return x;
}

bool PointcutTable::isEmpty() const{
	return (front == NULL);
}

bool PointcutTable::hasNext() const{
	return !isEmpty();
}

void PointcutTable::dumpPointcuts() const{
	pc_symbol *temp = new pc_symbol;
	temp = front;
	while(temp != NULL){
		cout << "Pointcut: " << temp->info.name << "|" << temp->info.joinpoints << endl;
		temp = temp->next;
	}
}

int* PointcutTable::dumpIDs(){
	pc_symbol *temp = new pc_symbol;
	temp = front;
	int n = countPointcuts();
	int *x = new int[n];
	int i = 0;
	while(temp != NULL){
		x[i++] = temp->info.id;
		temp = temp->next;
	}
	return x;
}

void PointcutTable::addToSelf(PointcutTable inc){
	int *y = inc.dumpIDs();
	for(int i=0;i<inc.countPointcuts();i++){
		/*** DEBUGGING **/ //cout << i << " - " << y[i] << endl;
		this->insertPointcut(inc.getByID(y[i]));
	}
}