/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Pointcut Table Class
Implemented as a Dynamic List, Store Named Pointcut Info
 
*/

#ifndef POINTCUT_TABLE
#define POINTCUT_TABLE
#include <iostream>
#include <string>
using namespace std;

struct pointcut{
	int id;
	string name;
	string joinpoints;
};

struct pc_symbol{
	pointcut info;
	pc_symbol *next;
};

class PointcutTable{
	private:
		pc_symbol *front;
		pc_symbol *rear;
		int count;
	public:
		PointcutTable();
		PointcutTable(const PointcutTable &);
		PointcutTable & operator = (const PointcutTable &);
		void addToSelf(PointcutTable);
		void insertPointcut(pointcut);
		pointcut findByName(string);
		pointcut getFirst();
		pointcut getLast();
		pointcut getByID(int);
		bool isInTable(string);
		bool hasNext() const;
		bool isEmpty() const;
		void dumpPointcuts() const;
		int* dumpIDs();
		int countPointcuts();
		void reset();
		~PointcutTable();
};

#endif