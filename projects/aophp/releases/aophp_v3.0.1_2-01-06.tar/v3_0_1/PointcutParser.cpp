/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Pointcut Parser Class
Designed to Parse Named Pointcut informtion from an Aspect File

*/
#include "PointcutParser.h"
#include "StringTok.h"
#include "StringManip.h"

PointcutParser::PointcutParser(){
}

PointcutTable PointcutParser::parse(string code){
	// Empty Table
	aTable.reset();
	StringManip sm;

	string valCode1 = "ointcut";
	string valCode2 = "pointcu";

	string orig = code;
	string tmp = "",tmp2 = "";
	int p,p1;

	StringTok tok1(code,"pointcut");
	tok1.tokenizeIgnoreStrings();
	int cnt = tok1.countTokens();

	pointcut pc;

	for(int i=0;i<cnt;i++){
		StringTok tok2(tok1.getNext(),";");
		tok2.tokenizeIgnoreStrings();
		tmp = tok2.getNext();
		/*** DEBUGGING **/ //cout << tmp << endl;
		p = tmp.find_first_of(" ");
		tmp2 = tmp.substr(0,p);
		if(tmp2.compare(valCode1) == 0 || tmp2.compare(valCode2) == 0){
			// Valid Pointcut Def
			p1 = tmp.find_first_of("=");
			/*** DEBUGGING **/ //cout << p << "-" << p1 << endl;
			pc.name = sm.trimWhiteSpace(tmp.substr(p,p1-p));
			tmp.erase(0,p1+1);
			p1 = tmp.find_first_not_of(" ");
			tmp.erase(0,p1);
			pc.joinpoints = tmp;
			/*** DEBUGGING **/ //cout << "|" << pc.name << "|" << pc.joinpoints << "|" << endl;
			aTable.insertPointcut(pc);
			pc.joinpoints = "";
			pc.name = "";
		}
	}
	
	
	return aTable;
}
