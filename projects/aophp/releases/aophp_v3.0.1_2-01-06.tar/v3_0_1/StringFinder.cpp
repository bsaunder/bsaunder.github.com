/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Finder Class
Finds Strings within code, Based on " " - Ignores Escaped Quotes (\")

*/

#include <iostream>
#include "StringFinder.h"
using namespace std;

StringFinder::StringFinder(string in){
	head = NULL;
	code = in;
	//cout << "List Created" << endl;
}

StringFinder::StringFinder(){
	head = NULL;
	code = "";
	//cout << "List Created" << endl;
}

void StringFinder::reset(string newCode){
	code = newCode;
	makeEmpty();
}

void StringFinder::findStrings(){
	string in = code;
	int codeLength = code.length();
	bool inString = false;
	int start = 0;
	int end = 0;
	char t;
	strPair p;
	for(int i=0;i<codeLength;i++){
		t = in.at(i);
		if(t == '"'){
			if(inString){
				inString = false;
				end = i;
				p.start = start;
				p.end = end;
				insertItem(p);
				p.reset();
			}else{
				inString = true;
				start = i;
			}
		}else if(t == '\\'){
			i++;
		}
	}
}

bool StringFinder::isInString(int pos){
	node *current = new node;
	current = head;
	strPair c;
	while(current != NULL){
		c = current->info;
		if(c.start <= pos && pos <= c.end){
			return true;
		}
		current = current->next;
	}
	return false;
}


StringFinder::StringFinder(const StringFinder & original){
	if(original.head == NULL){ // Copying Empty List
		head = NULL;
	} else {
		node *current = new node;
		node *temp = new node;
		node *last = new node;
		current = original.head;
		head = new node;
		head->info = current->info;
		head->next = NULL;
		last = head;
		current = current->next;
		while(current != NULL){
			temp->info = current->info;
			temp->next = NULL;

			last->next = temp;
			last = temp;

			current = current->next;
		}// End While
	}// End If
}


StringFinder::~StringFinder(){
	//cout << endl << "Destroying List" << endl;
	makeEmpty();
}


void StringFinder::makeEmpty(){
	node *temp = new node;
	strPair item;
	temp = head;
	while(temp != NULL){
		item = temp->info;
		temp = temp->next;
		removeItem(item);
	}
	head = NULL;
}


bool StringFinder::isItemInList(strPair item){
	node *temp = new node;
	temp = head;
	while(temp != NULL){
		if(temp->info == item){
			return true;
		} else {
			temp = temp->next;
		}// End If
	}// End While
	return false;
}


void StringFinder::removeItem(strPair item){
	if(isEmpty()){
		cout << "Can Not Delete from Empty List" << endl;
	} else {
		if(isItemInList(item)){ // Check if Item is Actually in List
			node *temp = new node;
			if(head->info == item){ // Item to Delete is Head
				//cout << "Deleting Head" << endl;
				temp = head;
				head = head->next;
				delete temp;
			} else { // Item in List
				bool found = false;
				node *a = new node; // Search Node A
				node *b = new node; // Search Node B
				a = head; // Set Start for A
				// Setting a Start point for B causes Errors in Some Situtations
				while(!found && a != NULL){ // While Insert Location not Found
					if(a->info == item){
						found = true;
					} else {
						b = a;
						a = a->next;
					}// End If
				}// End While
				// A and B Now at Proper Locations
				//cout << "Deleting Other" << endl;
				//cout << b->info << " - " << a->info << endl;
				temp = a;
				b->next = a->next;
				//cout << "New B: " << b->info << endl;
				delete temp;
			}// End If
		} else {
			cout << "Item To Delete Not Found in List!" << endl;
		}// End If
	}// End If
}


void StringFinder::insertItem(strPair item){
	bool found = false;
	// 1) Create Node
	node *temp = new node;
	// 2) Feed Node
	temp->info = item;
	temp->next = NULL;
	// 3) Insert Node
	if(isEmpty()){ // If Inserting in Empty List
		// 4) Link Node
		head = temp;
	} else { // Inserting in List
		if(item <= head->info){ // Inserting in Front
			// 4) Link Node
			temp->next = head;
			head = temp;
		} else { // Inserting in Middle or End
			// 4) Link Node
			node *a = new node; // Search Node A
			node *b = new node; // Search Node B
			a = head; // Set Start for A
			// Setting a Start point for B caused Errors in Some Situtations
			while(!found && a != NULL){ // While Insert Location not Found
				if(a->info >= item){
					found = true;
				} else {
					b = a;
					a = a->next;
				}// End If
			}// End While
			// A and B Now at Proper Locations
			temp->next = a;
			b->next = temp;
		}// End If
	}// End If
}


void StringFinder::printList(){
	node *current = new node;
	current = head;
	int diff = 0;
	strPair c;
	while(current != NULL){
		c = current->info;
		diff = c.end - c.start;
		cout << code.substr(c.start,diff+1) << endl;
		current = current->next;
	}
}


bool StringFinder::isEmpty(){
	return (head == NULL);
}
