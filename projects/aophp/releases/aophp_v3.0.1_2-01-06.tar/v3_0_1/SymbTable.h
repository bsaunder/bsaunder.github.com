/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Symbol Table Class
Implemented as a Dynamic List

*/

#ifndef SYMB_TABLE
#define SYMB_TABLE
#include <iostream>
#include <string>
using namespace std;

struct advice{
	int id;
	string signature;
	string code;
	int paramcount;
	string inparams;
	int inparamcount;
};

struct symbol{
	advice info;
	symbol *next;
};

class SymbTable{
	private:
		symbol *front;
		symbol *rear;
		int count;
	public:
		SymbTable();
		SymbTable(const SymbTable &);
		SymbTable & operator = (const SymbTable &);
		void insertAdvice(advice);
		int findBySig(string);
		advice getFirst();
		advice getLast();
		advice getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dumpAdvice() const;
		int countAdvice();
		void reset();
		~SymbTable();
};

#endif

