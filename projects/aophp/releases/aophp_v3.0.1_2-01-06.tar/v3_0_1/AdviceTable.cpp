/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

Advice Table Class
Implemented as a Dynamic List, Store Parsed Advice

*/

#include <iostream>
#include <string>
#include "AdviceTable.h"
using namespace std;

AdviceTable::AdviceTable(){
	front = NULL;
	rear = NULL;
	count = 0;
}

AdviceTable::AdviceTable(const AdviceTable & original){
	symbol *temp; // Used to Create the Nodes
	symbol *current; // The Node were Currently on
	symbol *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new symbol;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new symbol;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

AdviceTable & AdviceTable::operator = (const AdviceTable & original){
	symbol *temp; // Used to Create the Nodes
	symbol *current; // The Node were Currently on
	symbol *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new symbol;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new symbol;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

AdviceTable::~AdviceTable(){
	reset();
}

void AdviceTable::reset(){
	while(!isEmpty()){
		symbol *temp = front;
		front = front->next;
		delete temp;
	}
}

advice AdviceTable::getFirst(){
	return front->info;
}

advice AdviceTable::getLast(){
	return rear->info;
}

advice AdviceTable::getByID(int x){
	symbol *temp = front;
	while(temp != NULL){
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void AdviceTable::insertAdvice(advice item){
	symbol *temp = new symbol;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int AdviceTable::countAdvice(){
	symbol *temp = new symbol;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int AdviceTable::findBySig(string sig){
	symbol *temp = new symbol;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.signature.compare(sig) == 0){
			return x;
		}
		temp = temp->next;
	}
	count = x;
	return x;
}

bool AdviceTable::isEmpty() const{
	return (front == NULL);
}

bool AdviceTable::hasNext() const{
	return !isEmpty();
}

void AdviceTable::dumpAdvice() const{
	symbol *temp = new symbol;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.signature << endl;
		temp = temp->next;
	}
}

int* AdviceTable::dumpIDs(){
	symbol *temp = new symbol;
	temp = front;
	int n = countAdvice();
	int *x = new int[n];
	int i = 0;
	while(temp != NULL){
		x[i++] = temp->info.id;
		temp = temp->next;
	}
	return x;
}

void AdviceTable::addToSelf(AdviceTable inc){
	int *y = inc.dumpIDs();
	for(int i=0;i<inc.countAdvice();i++){
		/*** DEBUGGING **/ //cout << i << " - " << y[i] << endl;
		this->insertAdvice(inc.getByID(y[i]));
	}
}