/***

Aspect-Oriented PHP v4(aophpv4) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

Command Line Flags
    -s [0|1] = Include Status 0-Off 1-On
    -l [0-5] = Include Level
    -d = Enable aophpDoc
    -h "#XXXXXX" = aophpDoc HTML Color
    -p "#XXXXXX" = aophpDoc AOPHP Color
    -m "/Path/To/File/" = Meta Data Logging
    -x = Debug Mode on
    -t = Test Mode on

To Do List
    - Finish Strip Literals
    - Finish Strip Functions
    - Pre Process PHP
    - Parse aophp
    - Post Process aophp
    - Weave Code
    - Post Process PHP
    - Write Out File

***/

#include <iostream>
#include <exception>
#include <string>
#include <stdlib.h>
#include <fstream>
#include <stdexcept>
#include "StringTokenizer.h"
#include <boost/xpressive/xpressive_dynamic.hpp>

using namespace std;
using namespace boost::xpressive;

/*** Setup Variables ***/
const int MAX_CHARS_LINE = 500;
const int ARG_CNT = 2;

/*** Status Codes ***/
const int COMPLETED = 0;
const int DECLINED = 1;
const int SRC_FILE_ERROR = 2;
const int INV_ASPECT_FILE = 3;
const int INV_ASPECT_ARGS = 4;
const int ASPECT_FILE_ERROR = 5;
const int INVALID_PC_DEC = 6;
const int INVALID_PARAM = 7;
const int CMD_ARG_ERROR = 8;

/*** Arg Variables ***/
string DOC_HTML = "000000";
string DOC_PHP = "ff0000";
string META_LOG = "";
int INC_STATUS = 0; // Off by Default
int INC_DEPTH = 1; // 1 Level by Default
bool printDoc = false;
bool debug = false;
bool testMode = false;

/*** Global Data ***/
string phpIn;
string phpOut;
string phpFileName;
string phpFileDir;
string phpSource = "";
string aophpSource = "";

/*** Recursive Descent Parser Variables ***/
int loc = 0;

/*** Aspect Structure - Composed of Advice and Pointcuts ***/
struct Aspect{
  string name;
  string code;
};

/*** RDP Function Prototypes ***/
void error(string);
string lookToken();
string lookToken(int);
string lookTokenTo(string);
string nextToken();
void checkToken(string); // Expected String
void checkToken(int,string); // Regex Check Num, Rule Name
void checkToken(string[],int); // Possible Expecteds, Array Size
void parse(); // Start Parsing
void parseAspect();
void parseAspect_plus();
void parsePointcut();
void parsePointcut_star();
void parseAdvice();
void parseAdvice_star();
void parseJoinpoint();
void parseFJoinpoint();
void parseVJoinpoint();
void parseJoinpointlist_star();
void parseJoinpointlist();
void parseArgs();
void parseFJPType();
void parseVJPType();
void parseSignature();
void parseVarList_star();
void parseParamlist();
void parseArgVal();
void parseArgs_star();
void parseID();
void parseVar();
void parseVarList();
void parseDelim();
void parseEndDelim();
void parseNonDelim();
void parseAdviceType();
void parseCodeBlock();
bool re_1_ID(string); // Regex Check Function - Check Num 1 - Rule T
bool re_2_ArgVal(string);
bool re_3_NonDelim(string);
bool re_4_Digit(string);

/*** Processing and Weaving Functions ***/
void writeOutFile(string oFile, string content);
void trim(string& str);
bool open_parse_PHP();
bool parse_args(int argc, char* argv[]);
void stripComments(string&);
void stripLiterals(string&); // Not Complete
void stripFunctions(string&); // Not Complete
void pre_process_aspects(string&);
void pre_process_php(string&);
string find_aspect_files(string&);
bool parse_aspects(string); // Not Complete
int countChar(string,string);
void printArgs();


/*** Main Function ***/
int main(int argc, char* argv[]){

    // Parse Command Line Arguments
    if(!parse_args(argc,argv)) return CMD_ARG_ERROR;

    if(testMode){
        parse_aspects(phpIn);
        pre_process_aspects(aophpSource);
        parse();
        return 0;
    }

    // Print Command Arguments
    printArgs();

	// Open and Parse PHP File
	if(!open_parse_PHP()){
		cout << "Error Reading Input Source File." << endl;
		// Write out original file
		return SRC_FILE_ERROR;
	}

	// PreProcess PHP Source - Strip Comments, Literals, & Functions
    pre_process_php(phpSource);

	// Find Aspect Files, then Parse to get input
	parse_aspects(find_aspect_files(phpSource));

    // PreProcess aophp Source - Strip Comments, New Lines,  & Literals
	pre_process_aspects(aophpSource);

    cout << "Parsing: " << aophpSource << "\n";
    parse();
    cout << "String was Good.\n";
    return COMPLETED;
}

/*** Open and Parse PHP File ***/
bool open_parse_PHP(){
	int s = phpIn.find_last_of('/')+1;
	int l = phpIn.find_first_of('.') - s;
	phpFileName = phpIn.substr(s,l);
	phpFileDir = phpIn.substr(0,s);
	/**** DEBUGGING **/ if(debug) cout << "Paths: " << phpFileName << " - " << phpFileDir << endl;
	// Open PHP Source Input File
	ifstream inFile;
	inFile.open(phpIn.c_str(),ios::in);
	if(!inFile){
		cerr << "ERR: Could Not Source Open File\n";
		return false;
	}else{
		cout << "Opened Source File\n";
	}

	// Parse PHP Source File to String
	string tmpStr;
	string src;
	while(!inFile.eof()){
		getline(inFile,tmpStr);
		src += tmpStr + "\n";
	}
	inFile.close();
	/**** DEBUGGING **/ if(debug) cout << endl << src << endl;
	cout << "PHP Source Parsed\n";
	trim(src);
	phpSource = src;
	return true;
}

/*** Parse Aspect Files ***/
bool parse_aspects(string list){
    StringTokenizer strtok = StringTokenizer(list,",");
    while(strtok.hasMoreTokens()){
        string curfile = strtok.nextToken();
        ifstream inFile;
        int k = curfile.find(".aophp");
        if(k < 0){
            continue;
        }
        string tempstring = phpFileDir+curfile;
        inFile.open(tempstring.c_str(),ios::in);
        if(!inFile){
            return false;
        }else{
            string tmpStr = "";
            while(!inFile.eof()){
                getline(inFile,tmpStr);
                aophpSource += tmpStr;
            }
            inFile.close();
        }
    }
    /**** DEBUGGING ***/ if(debug) cout << "-->|" << aophpSource << "|<--" << endl;
    return true;
}

/*** Find List of Aspect Files ***/
string find_aspect_files(string& phpcode){
	sregex ws = sregex::compile("[\\s]*"); // Remove Whitespace
    string format(""); // Empty String Format
    sregex token = sregex::compile("(aophp_init\\(\")([A-Za-z0-9.,_-]*)(\"\\);)");
    sregex_iterator cur( phpcode.begin(), phpcode.end(), token );
    sregex_iterator end;
    string files; // aophp File List
	string m;
	int fCnt = 0;
	bool matched = false;
    for( ; cur != end; ++cur ){
        // Get Current Match
    	smatch const &what = *cur;
    	// Remove Whitespace
    	files = regex_replace(what[2].str(),ws,format);
		m = what[0].str();
		if(files.compare("")!=0){
			matched = true;
		}
    	break;
   	}
   	sregex match = sregex::compile(m);
   	phpcode = regex_replace(phpcode,match,format);
   	return files;
}

/*** Preprocess Aspect Source ***/
void pre_process_aspects(string& code){
    stripComments(code);
    trim(code);
}

/*** Preprocess PHP Source ***/
void pre_process_php(string& code){
    stripComments(code);
    stripLiterals(code);
    stripFunctions(code);
}

/*** Strip Comments from given String ***/
void stripComments(string& code){
	string input = code;
	string output = "";
	int status = 0;
	bool inString = false;
	// Strip All Comments
	// 0 - Not In Comment
	// 1 - Full Line Comment
	// 2 - Block Type Comment
	char t;
	for(int i=0;i<input.length();i++){
		t = input.at(i);
		if(t == '"'){
			inString = !inString;
		}
		if(inString && status == 0){
			output += t;
		}else{
			if(status == 0){
				if(t == '/'){
					if(input.at(i+1) == '/'){
						status = 1;
					}else if(input.at(i+1) == '*'){
						status = 2;
					}else{
						output += t;
					}
				}else{
					output += t;
				}
			}else if(status == 1){
				if(t == '\n'){
					status = 0;
				}
			}else if(status == 2){
				if(t == '*' && input.at(i+1) == '/'){
					status = 0;
					i++;
				}
			}
		}
	}
	code = output;
}

/*** Strip Literals from given String ***/
void stripLiterals(string& code){

}

/*** Strip Functions from given String ***/
void stripFunctions(string& code){

}

/*** Write Data File ***/
void writeOutFile(string oFile, string content){
  ofstream outFile;
  outFile.open(oFile.c_str(),ios::out);
  outFile << content;
  outFile.close();
}

/*** Trim String Whitespace ***/
void trim(string& str){
	string::size_type pos1 = str.find_first_not_of(" \t\r\n");
	string::size_type pos2 = str.find_last_not_of(" \t\r\n");
	str = str.substr(pos1 == string::npos ? 0 : pos1,
		pos2 == string::npos ? str.length() - 1 : pos2 - pos1 + 1);
}

/*** Count Character Appearance in String ***/
int countChar(string s, string ch){
    int c = 0;
    int l = s.length();
    for(int i=0;i<l;i++){
        string t = s.substr(i,1);
        if(t.compare(ch)==0) c++;
    }
    return c;
}

/*** Parse Command Line Arguments ***/
bool parse_args(int argc, char* argv[]){
	// Parse Aguments

	// Cmd Line Flags
	// -s [0|1] = Include Status 0-Off 1-On
	// -l [0-5] = Include Level
	// -d = Enable aophpDoc
	// -h "#XXXXXX" = aophpDoc HTML Color
	// -p "#XXXXXX" = aophpDoc AOPHP Color
	// -m "/Path/To/File/" = Meta Data Logging
	// -x = Debug Mode On
	// -t XX = Run in Test Mode, XX Num of Test Cases
	string argtemp = "";
	try{
		for(int i=0;i<argc;i++){
			argtemp = argv[i];
			if(argtemp.compare("-s")==0){
				i++;
				argtemp = argv[i];
				INC_STATUS = atoi(argv[i]);
			}else if(argtemp.compare("-t")==0){
				testMode = true;
			}else if(argtemp.compare("-l")==0){
				i++;
				argtemp = argv[i];
				INC_DEPTH = atoi(argv[i]);
			}else if(argtemp.compare("-h")==0){
				i++;
				string htmldebugtemp(argv[i]);
				DOC_HTML = htmldebugtemp;
			}else if(argtemp.compare("-p")==0){
				i++;
				string phpdebugtemp(argv[i]);
				DOC_PHP = phpdebugtemp;
			}else if(argtemp.compare("-d")==0){
				printDoc = true;
			}else if(argtemp.compare("-x")==0){
				debug = true;
			}else if(argtemp.compare("-m")==0){
				i++;
				string metafiletemp(argv[i]);
				META_LOG = metafiletemp;
			}else{
				if(i==1){
					phpIn = argtemp;
				}else if(i==2){
					phpOut = argtemp;
				}
			}
		}
	}catch(std::logic_error&){
		cerr << "Invalid Parameters. Failing" << endl;
		return false;
	}
	return true;
}

void printArgs(){
    cout << "Arguments: " << endl;
    cout << "In File: " << phpIn << endl;
	cout << "Out File: " << phpOut << endl;
	cout << "Inc. Status: " << INC_STATUS << endl;
	cout << "Inc. Depth: " << INC_DEPTH << endl;
	cout << "Doc. HTML Color: " << DOC_HTML << endl;
	cout << "Doc. PHP Color: " << DOC_PHP << endl;
	cout << "Print Doc: " << printDoc << endl;
	cout << "Meta Log File: " << META_LOG << endl;
}

/*** Recursive Descent Parser Functions ***/
void checkToken(string expected){
    int l = expected.length();
    for(int i=0;i<l;i++){
      string s = nextToken();
      if(s.compare(expected.substr(i,1))!=0)
        //throw parseException("PE: Parse Error on Token \""+s+"\", Expecting \""+expected+"\" - Bailing Out");
        error("Parse Error on Token \""+s+"\", Expecting \""+expected+"\" - Bailing Out");
    }
    return;
}
void checkToken(string ch[],int size){
    for(int i=0;i<size;i++){
      int l = ch[i].length();
      if(lookToken(l).compare(ch[i])==0) { checkToken(ch[i]); return; }
    }
    error("Parse Error on String, No Matching Rule Found - Bailing Out");
}
void checkToken(int regex,string rule){
  string s = "";
  if(regex == 1){
    s = nextToken();
    while(re_1_ID(s)){
      s += nextToken();
    }
    //cout << "ID: " << s << endl;
    loc--;
    return;
  }else if(regex == 2){
    s = nextToken();
    while(re_2_ArgVal(s)){
      s += nextToken();
    }
    loc--;
    return;
  }else if(regex == 3){
    s = nextToken();
    while(re_3_NonDelim(s)){
      s += nextToken();
    }
    loc--;
    return;
  }else if(regex == 4){
    s = nextToken();
    while(re_4_Digit(s)){
      s += nextToken();
    }
    loc--;
    return;
  }
  else error("Parse Error on Token \""+s+"\" Regex Match, Does not Match Rule "+rule+" - Bailing Out");
}
string lookTokenTo(string s){
  string t = aophpSource.substr(loc,1);
  int l = loc;
  if(t.compare(" ")!=0&&t.compare("\t")!=0){
      int x = aophpSource.find_first_of(s,loc);
      return aophpSource.substr(loc,x);
  }
  else{
    while(t.compare(" ")==0||t.compare("\t")==0){
      t = aophpSource.substr(l,1);
      l++;
    }
    int x = aophpSource.find_first_of(s,l-1);
    return aophpSource.substr(l-1,x-l+1);
  }
}
string lookToken(){
  string t = aophpSource.substr(loc,1);
  int l = loc;
  if(t.compare(" ")!=0&&t.compare("\t")!=0) return t;
  else{
    while(t.compare(" ")==0||t.compare("\t")==0){
      t = aophpSource.substr(l,1);
      l++;
    }
    return t;
  }
}
string lookToken(int num){
  string t = aophpSource.substr(loc,1);
  int l = loc;
  if(t.compare(" ")!=0&&t.compare("\t")!=0){
      return aophpSource.substr(loc,num);
  }
  else{
    while(t.compare(" ")==0||t.compare("\t")==0){
      t = aophpSource.substr(l,1);
      l++;
    }
    return aophpSource.substr(l-1,num);
  }
}
string nextToken(){
    string t = aophpSource.substr(loc,1);
    loc++;
    while(t.compare(" ")==0||t.compare("\t")==0){
      t = aophpSource.substr(loc,1);
      loc++;
    }
    return t;
}

void parse(){ // START -> <ASPECT>+
  int l = aophpSource.length();
  parseAspect_plus();
  if(loc != l) error("Invalid String, Length Error");
}
void parseAspect_plus(){
  parseAspect();
  string s = lookToken(6);
  while(s.compare("aspect")==0){
    parseAspect();
    s = lookToken(6);
  }
}
void parseAspect(){ // ASPECT -> "aspect" <ID> '{' <POINTCUT>* <ADVICE>* '}'
    checkToken("aspect");
    parseID();
    checkToken("{");
    parsePointcut_star();
    parseAdvice_star();
    checkToken("}");
}
void parsePointcut_star(){
    //cout << "Parsing Pointcut Star" << endl;
    string s = lookToken(8);
    while(s.compare("pointcut")==0){
        parsePointcut();
        s = lookToken(8);
    }
}
void parsePointcut(){ // POINTCUT -> "pointcut" <ID> '=' <JOINPOINT> <JOINPOINTLIST>* ';'
    checkToken("pointcut");
    parseID();
    checkToken("=");
    parseJoinpoint();
    parseJoinpointlist_star();
    checkToken(";");
}
void parseJoinpoint(){ // JOINPOINT -> <FJOINPOINT> | <VJOINPOINT> | ID
    string s = lookTokenTo(" (");
    if(s.compare("exec")==0 || s.compare("execr")==0)
        parseFJoinpoint();
    else if(s.compare("set")==0 || s.compare("get")==0)
        parseVJoinpoint();
    else parseID();
}
void parseFJoinpoint(){ // FJOINPOINT -> <FJPTYPE>'('<SIGNATURE><PARAMLIST>')'<ARGS>*
    parseFJPType();
    checkToken("(");
    parseSignature();
    parseParamlist();
    checkToken(")");
    parseArgs_star();
}
void parseVJoinpoint(){ // VJOINPOINT -> <FJPTYPE>'('<SIGNATURE>')'<ARGS>*
    parseVJPType();
    checkToken("(");
    parseSignature();
    checkToken(")");
    parseArgs_star();
}
void parseJoinpointlist(){ // JOINPOINTLIST -> '|' <JOINPOINT>
    checkToken("|");
    parseJoinpoint();
}
void parseJoinpointlist_star(){
    string s = lookToken();
    while(s.compare("|")==0){
        parseJoinpointlist();
        s = lookToken();
    }
}
void parseArgs(){ // ARGS -> "&&" <ID> '('<ARGVAL>')'
    checkToken("&&");
    parseID();
    checkToken("(");
    parseArgVal();
    checkToken(")");
}
void parseArgs_star(){
    string s = lookToken(2);
    while(s.compare("&&")==0){
        parseArgs();
        s = lookToken(2);
    }
}
void parseArgVal(){ // ARGVAL -> ('"'(.)*'"')|(<DIGIT>*)
    //checkToken(2,"ArgVal");
    string s = lookToken();
    if(s.compare("\"")==0){
        checkToken("\"");
        checkToken(2,"ArgVal");
        checkToken("\"");
    }else{
        checkToken(4,"Digit");
    }
}
void parseAdvice(){ // ADVICE -> "advice" <ADVICETYPE> <PARAMLIST> ':' <JOINPOINT> <JOINPOINTLIST>* <CODEBLOCK>
    checkToken("advice");
    parseAdviceType();
    parseParamlist();
    checkToken(":");
    parseJoinpoint();
    parseJoinpointlist_star();
    parseCodeBlock();
}
void parseAdvice_star(){
    string s = lookToken(6);
    while(s.compare("advice")==0){
        parseAdvice();
        s = lookToken(6);
    }
}
void parseCodeBlock(){ // CODEBLOCK -> <DELIM> <NONDELIM>* <ENDDELIM>
    parseDelim();
    parseNonDelim();
    parseEndDelim();
}

void parseID(){ // ID -> <LETTER><ALPHA>*
    checkToken(1,"ID");
}
void parseVar(){ // VAR -> '$'<ID>
    checkToken("$");
    parseID();
}
void parseVarList(){ // VAR_LIST -> ','<VAR>
    checkToken(",");
    parseVar();
}
void parseVarlist_star(){
    string s = lookToken();
    while(s.compare(",")==0){
        parseVarList();
        s = lookToken();
    }
}
void parseVars(){ // VARS -> '$'<ID><VARLIST>*
    checkToken("$");
    parseID();
    parseVarlist_star();
}
void parseSignature(){ // SIGNATURE -> <ID>'.'<ID>[<PARAMLIST>]
    //cout << "Parsing Sig" << endl;
    parseID();
    checkToken(".");
    parseID();
    string t = lookToken();
    //cout << "SIG: " << t << endl;
}
void parseParamlist(){ // PARAMLIST -> '('[<VARS>]')'
    //cout << "Parsing Paramlist" << endl;
    checkToken("(");
    if(lookToken().compare("$")==0)
        parseVars();
    checkToken(")");
}
void parseFJPType(){ // FJPTYPE -> "exec" | "execr"
    string s1 = lookToken(4);
    string s2 = lookToken(5);
    //cout << "FJPTYPE: |" << s1 << "|" << s2 << "|" << endl;
    if(s2.compare("execr")==0)
        checkToken("execr");
    else if(s1.compare("exec")==0)
        checkToken("exec");
    else error("Parse Error on FJPType, Invalid Type - Bailing Out.");
}
void parseVJPType(){ // VJPTYPE -> "set" | "get"
    string s = lookToken(3);
    if(s.compare("set")==0)
        checkToken("set");
    else if(s.compare("get")==0)
        checkToken("get");
    else error("Parse Error on VJPType, Invalid Type - Bailing Out.");
}
void parseAdviceType(){
    string s = lookTokenTo(" (");
    if(s.compare("before")==0)
        checkToken("before");
    else if(s.compare("after")==0)
        checkToken("after");
    else
        checkToken("around");
}
void parseDelim(){ // DELIM -> "{%"
    checkToken("{%");
}
void parseEndDelim(){ // ENDDELIM -> "%}"
    checkToken("%}");
}
void parseNonDelim(){ // NONDELIM -> ([^%]|[%][^}])*
    checkToken(3,"NonDelim");
}

bool re_1_ID(string token){
  sregex str = sregex::compile("[A-Za-z][A-Za-z0-9]*");
  return regex_match(token,str);
}
bool re_2_ArgVal(string token){
  sregex str = sregex::compile("[^\"\\r\\n]*");
  return regex_match(token,str);
}
bool re_4_Digit(string token){
  sregex str = sregex::compile("[0-9]*");
  return regex_match(token,str);
}
bool re_3_NonDelim(string token){
  sregex str = sregex::compile("([^%]|[%][^}])*");
  return regex_match(token,str);
}

void error(string err){
    cout << err << endl;
    exit(5);
}

