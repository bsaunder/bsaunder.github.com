/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/

#ifndef LINKED_LIST_AS
#define LINKED_LIST_AS
#include <iostream>
#include <string>
using namespace std;

struct asdata{
	int id; // Required
	string name; // Required
	string code;
};

struct asnode{
	asdata info;
	asnode *next;
};

class LListAS{
	private:
		asnode *front;
		asnode *rear;
		int count;
	public:
		LListAS();
		LListAS(const LListAS &);
		LListAS & operator = (const LListAS &);
		void insert(asdata);
		int findByName(string);
		asdata getFirst();
		asdata getLast();
		asdata getByID(int);
		void updateByID(int,asdata);
		bool hasNext() const;
		bool isEmpty() const;
		void dump() const;
		int countasnodes();
		void reset();
		~LListAS();
};

#endif

