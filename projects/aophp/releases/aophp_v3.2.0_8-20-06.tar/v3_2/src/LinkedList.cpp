/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
#include <iostream>
#include <string>
#include "LinkedList.h"
using namespace std;

LList::LList(){
	front = NULL;
	rear = NULL;
	count = 0;
}

LList::LList(const LList & original){
	node *temp; // Used to Create the Nodes
	node *current; // The Node were Currently on
	node *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new node;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new node;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

LList & LList::operator = (const LList & original){
	node *temp; // Used to Create the Nodes
	node *current; // The Node were Currently on
	node *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new node;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new node;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

LList::~LList(){
	reset();
}

void LList::reset(){
	while(!isEmpty()){
		node *temp = front;
		front = front->next;
		delete temp;
	}
}

data LList::getFirst(){
	return front->info;
}

data LList::getLast(){
	return rear->info;
}

data LList::getByID(int x){
	node *temp = front;
	while(temp != NULL){
		cout << temp->info.name << endl;
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void LList::insert(data item){
	node *temp = new node;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int LList::countNodes(){
	node *temp = new node;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int LList::findByName(string name){
	node *temp = new node;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(name) == 0){
			return temp->info.id;
		}
		temp = temp->next;
	}
	count = x;
	return x;
}

bool LList::isEmpty() const{
	return (front == NULL);
}

bool LList::hasNext() const{
	return !isEmpty();
}

void LList::dump() const{
	node *temp = new node;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.name << endl;
		temp = temp->next;
	}
}

