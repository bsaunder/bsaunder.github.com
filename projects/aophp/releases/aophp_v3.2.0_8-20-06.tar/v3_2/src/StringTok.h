/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
/*

Developed & Released under the
	aoPHP GNU Public License
Coded by Bryan Saunders

String Tokenizer Class
Implemented as a Dynamic Queue

*/

#ifndef STRINGTOK
#define STRINGTOK
#include <iostream>
#include <string>
#include "aoString.h"
using namespace std;

struct token{
	aoString info;
	token *next;
};

class StringTok{
	private:
		token *front;
		token *rear;
		aoString orig;
		string delim;
	public:
		StringTok(aoString,string);
		StringTok(string,string);
		StringTok(const StringTok &);
		StringTok & operator = (const StringTok &);
		void tokenize();
		void insertToken(aoString);
		aoString getNext();
		bool hasNext() const;
		bool isEmpty() const;
		aoString getRemaining() const;
		void dumpTokens() const;
		int countTokens() const;
		aoString getOrig();
		void reset(aoString,string);
		void reset(string,string);
		~StringTok();
};

#endif

