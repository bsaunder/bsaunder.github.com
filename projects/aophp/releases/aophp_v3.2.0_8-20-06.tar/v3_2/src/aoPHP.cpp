/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/

/* To Do List
 - OO Support
 - Set/Get Joinpoints
*/

#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>
#include "StringTok.h"
#include "LinkedList_PC.h"
#include "LinkedList_AD.h"
#include "LinkedList_AS.h"
#include "LinkedList_ST.h"
#include "LinkedList_FC.h"
#include "md5.h"
#include <boost/xpressive/xpressive_dynamic.hpp>

using namespace boost::xpressive;
using namespace std;

// Aspect Structure - Composed of Advice and Pointcuts
struct Aspect{
  aoString name;
  aoString code;
};

// Prototypes
void writeOutFile(string oFile, string content);
void trim(string& str);
void recParse(string S, string A, LListST& S);
bool open_parse_PHP();
bool parse_args(int argc, char* argv[]);
int parse_aspects();
void split_aspects();
void parse_pointcuts();
void parse_advice();
void parse_more_advice();
int process_jpType(string s);
int process_advType(string s);
string process_Args(string s);
void gen_helpers();
void gen_functions();
void weave_code();
void gen_list();
string get_correct_params(addata &x);
void make_html();
void preprocess();
void strip_literals();
void strip_functions();
void postprocess();
void insert_literals();
void insert_functions();


/*** Setup Variables ***/
const int MAX_CHARS_LINE = 500;
const int ARG_CNT = 2;

/*** Status Codes ***/
const int COMPLETED = 0;
const int DECLINED = 1;
const int SRC_FILE_ERROR = 2;
const int INV_ASPECT_FILE = 3;
const int INV_ASPECT_ARGS = 4;
const int ASPECT_FILE_ERROR = 5;
const int INVALID_PC_DEC = 6;
const int INVALID_PARAM = 7;
const int WRONG_ARG_CNT = 99;

/*** Arg Variables ***/
string DOC_HTML = "000000";
string DOC_PHP = "ff0000";
string META_LOG = "";
int INC_STATUS = 0; // Off by Default
int INC_DEPTH = 1; // 1 Level by Default
bool printDoc = false;
bool debug = false;

/*** Prog Variables ***/
bool done = false;
bool isError = false;
string error_log;

/*** Global Data ***/
LListPC pclist;
LListST finalList;
LListAS aspects;
LListST namedpclist;
LListPC advList;
LListAD adviceTable;
string phpIn;
string phpOut;
string phpFileName;
string phpFileDir;
aoString phpSource;
aoString aopSource;
aoString weavedSource;
aoString helperFuncs;
aoString adviceFuncs;
aoString htmlSource;
LListST funcList;
LListFC pp_funcTable;
LListFC pp_literalTable;

int main(int argc, char* argv[]){

	// Command Line Arguments
	// Only 1-4 Passed at Command Line
	// 0 - Relative Path to Executable from Working Directory
	// 1 - PHP In File
	// 2 - PHP Out File

	// Check for Arguments
	if(argc <= ARG_CNT){
		cerr << "ERR: Wrong Argument Count\n";
		return WRONG_ARG_CNT;
	}

	// Parse Arguments
	if(!parse_args(argc,argv)){
		return INVALID_PARAM;
	}

	// Open and Parse PHP File
	if(!open_parse_PHP()){
		isError = true;
		error_log += "Error Reading Source PHP. No Weaving Done. <br>";
		done = true;
	}
	
	// Pre-proccess PHP - Phase 1 (Strip Comments)
	cout << "Stripping Comments...\n";
	phpSource.stripComments();
	
	if(!done){
		// Parse Aspect Files
		int x = parse_aspects();
		if(x==2){
			cout << "No Weave Needed. No Aspect Files." << endl;
			//writeOutFile(phpOut,error_log + phpSource.toString());
			done = true;
		}else if(x==3){
			cout << "No Weave Needed. Invalid Init Call." << endl;
			//writeOutFile(phpOut,error_log + phpSource.toString());
			done = true;
		}
	}
	
	// Pre-Process PHP - Phase 2 (Remove Functions and Literals to Tables)
	preprocess();
	weavedSource = phpSource;

	if(!done){
		// Split Aspects
		split_aspects();

		// Get Named Pointcuts
		parse_pointcuts();

		// Parse Advice & Store
		parse_advice();
		parse_more_advice();

		/**** DEBUGGING **/ if(debug){
			cout << "----- TOTAL ADVICE DUMP -----\n";
			adviceTable.spill();
			cout << "---------------------\n";
		/**** DEBUGGING **/ }

		// Generate Function List
		gen_list();

		// Generate Helper Functions
		gen_helpers();

		// Generate AOP Functions
		gen_functions();

		// Build Code
		weave_code();
		
		//Post-Process
		postprocess();

		if(printDoc){
			// Make HTML File
			make_html();
		}
	}

	// Process Error Log
	if(isError){
		error_log = "<font color=#"+DOC_PHP+"> <b>aophp Generated Errors:</b> <br>" + error_log + "</font>";
		weavedSource.setString(error_log + weavedSource.toString());
		htmlSource.setString(error_log + htmlSource.toString());
	}

	// Write File
	writeOutFile(phpOut,weavedSource.toString());
	if(printDoc){
		// Make HTML File
		writeOutFile(phpOut+".html","<pre><font color=#"+DOC_HTML+">"+htmlSource.toString()+"</font></pre>");
	}

	cout << "Weave Done" << endl;
	return COMPLETED;
}

void postprocess(){
	cout << "Post Processing...\n";
	// Insert Functions
	cout << "Rebuilding Functions...\n";
	insert_functions();
	// Insert Literals
	cout << "Rebuilding Literals...\n";
	insert_literals();
}

void insert_functions(){
	for(int k=0;k<pp_funcTable.countfcnodes();k++){
		string func = pp_funcTable.getByID(k+1).str;
		string hash = "!!FH:"+pp_funcTable.getByID(k+1).hash+"!!";
		string input = weavedSource.toString();
		sregex target = sregex::compile(hash);
		string replace(func);
		string output = regex_replace(input,target,replace);
		weavedSource.setString(output);
	}
}

void insert_literals(){
	for(int k=0;k<pp_literalTable.countfcnodes();k++){
		string func = pp_literalTable.getByID(k+1).str;
		string hash = "!!LH:"+pp_literalTable.getByID(k+1).hash+"!!";
		string input = weavedSource.toString();
		sregex target = sregex::compile(hash);
		string replace(func);
		string output = regex_replace(input,target,replace);
		weavedSource.setString(output);
	}
}

void preprocess(){
	cout << "Preprocessing Source...\n";
	// Strip Literals
	cout << "Stripping Literals...\n";
	strip_literals();
	// Strip Functions
	cout << "Stripping Functions...\n";
	strip_functions();
	cout << "Preprocess Done.\n";
	
	pp_funcTable.dump();
	pp_literalTable.dump();
}

void strip_functions(){
	string phpcode = phpSource.toString();
	sregex token = sregex::compile("(function[\\s]*[ ]*)([a-zA-Z0-9_]*)([\\s]*)\\(([a-zA-Z0-9_\"$', .()]*)\\)");
	// Iterate Through PHP Cpde
	sregex_iterator cur( phpcode.begin(), phpcode.end(), token );
	sregex_iterator end;
	// Iterate
	for( ; cur != end; ++cur )
	{
		// Get Current Match
    		smatch const &what = *cur;
    		fcdata t;
    		int x = phpSource.findCodeStart(what.position(0));
		int y = phpSource.findCodeEnd(x);
		string fTotal = phpSource.subStrSect(what.position(0),y).toString();
		t.hash = MD5String(fTotal.c_str());
		t.str = fTotal;
		pp_funcTable.insert(t);
		cout << "Found: " << what[0] << endl;
    		/**** DEBUGGING **/ if(debug) cout << "    -> " << fTotal << endl;
    	}
    	
    	/**** DEBUGGING **/ if(debug) cout << phpSource.toString() << endl << endl << endl;
    	
    	for(int k=0;k<pp_funcTable.countfcnodes();k++){
		string func = pp_funcTable.getByID(k+1).str;
		string hash = pp_funcTable.getByID(k+1).hash;
		phpSource.replaceString(func,"!!FH:"+hash+"!!");
	}
	
	/**** DEBUGGING **/ if(debug) cout << phpSource.toString() << endl << endl << endl;
    	
}

void strip_literals(){

	string phpcode = phpSource.toString();
	sregex token = sregex::compile("\"[^\"\\\\]*(?:\\\\.[^\"\\\\]*)*\"|'[^'\\\\]*(?:\\\\.[^'\\\\]*)*'");
	// Iterate Through PHP Cpde
	sregex_iterator cur( phpcode.begin(), phpcode.end(), token );
	sregex_iterator end;
	// Iterate
	for( ; cur != end; ++cur )
	{
		// Get Current Match
    		smatch const &what = *cur;
    		fcdata t;
    		int l = what.position(0)+what.length(0);
		string fTotal = phpSource.subStrSect(what.position(0),l-1).toString();
		t.hash = MD5String(fTotal.c_str());
		t.str = fTotal;
		pp_literalTable.insert(t);
		cout << "Found: " << what[0] << endl;
    		/**** DEBUGGING **/ if(debug) cout << "    -> " << fTotal << endl;
    	}
    	
    	/**** DEBUGGING **/ if(debug) cout << phpSource.toString() << endl << endl << endl;
    	
    	for(int k=0;k<pp_literalTable.countfcnodes();k++){
		string func = pp_literalTable.getByID(k+1).str;
		string hash = pp_literalTable.getByID(k+1).hash;
		/**** DEBUGGING **/ if(debug) cout << "Replacing: " << func << endl;
		phpSource.replaceString(func,"!!LH:"+hash+"!!");
	}
	
	/**** DEBUGGING **/ if(debug) cout << phpSource.toString() << endl << endl << endl;

}

void make_html(){
	string code = weavedSource.toString();
	sregex lb = sregex::compile("<");
	sregex rb = sregex::compile(">");
	sregex start = sregex::compile("/\\*@0P\\*/"); // Start Code
	sregex end = sregex::compile("/\\*3@0P\\*/"); // End Code
	string open("<font color=#"+DOC_PHP+">"); // Open Tag
	string close("</font>"); // Close Tag
	string lb2("&lt;");
	string rb2("&gt;");
	code = regex_replace(code,lb,lb2);
	code = regex_replace(code,rb,rb2);
	string result = regex_replace(code,start,open); // Process Start
	string result2 = regex_replace(result,end,close); // Process End
	htmlSource.setString(result2);
}

// Weave Code
void weave_code(){
	string phpcode = phpSource.toString();
	for(int i=0;i<funcList.countstnodes();i++){
	
		string jpName = funcList.getByID(i+1).str;
		/**** DEBUGGING **/ if(debug) cout << "|" << jpName << "|" << endl;
		int x = adviceTable.findByName(jpName,phpFileName);
		addata dat = adviceTable.getByID(x);
		string func = "ao_fi_"+dat.hash+"_"+jpName; // Replace Function
		
		sregex ws = sregex::compile("[\\s]*"); // Remove Whitespace
		string format(""); // Empty String Format
		// Find Function Calls
		sregex token = sregex::compile("(function[\\s]*[ ]*|[\\s][ ]*|[ ]*)([a-zA-Z0-9_]*)([\\s]*)\\(([a-zA-Z0-9_\"$', .()]*)\\)");
		// Iterate Through PHP Cpde
		sregex_iterator cur( phpcode.begin(), phpcode.end(), token );
		sregex_iterator end;
		// Iterate
		LListST matches;
		for( ; cur != end; ++cur )
		{
		    // Get Current Match
    			smatch const &what = *cur;
    			/**** DEBUGGING **/ if(debug) cout << "==>: (" << what.position(2) << "," << what.length(2) << ") N-" << what[2] << " | P-" <<  what[4] << " | F-" <<  what[1] << '|' << endl;
    			// Remove Whitespace
    			string result2 = regex_replace(what[1].str(),ws,format);
    			// Make sure Not Function Definition & Correct Call
    			if(result2.compare("function")!=0 && what[2].str().compare(jpName)==0){
    				// Matched - Remove/Replace
    				/**** DEBUGGING **/ if(debug) cout << " MATCH - " << what[0] << '\n';
    				stdata tmp;
				tmp.str = what[0];
				matches.insert(tmp);
   			}
		}
		/**** DEBUGGING **/ if(debug) cout << "==DUMP==\n"; matches.dump(); cout << "========\n";
		for(int k=0;k<matches.countstnodes();k++){
			string o = matches.getByID(k+1).str;
			trim(o);
			/**** DEBUGGING **/ if(debug) cout << "before t | o = " << o << "\n";
			aoString t(o);
			t.replace(jpName,func);
			/**** DEBUGGING **/ if(debug) cout << "after t replace \n";
			aoString c(phpcode);
			c.replace(o,"/*@0P*/"+t.toString()+"/*3@0P*/");
			/**** DEBUGGING **/ if(debug) cout << "after c replace \n";
			phpcode = c.toString();
		}
		matches.reset();
	}
	phpSource.setString(phpcode);
	string w = "<? /*@0P*/ /* AOPHP GENERATED CODE */ \n" + helperFuncs.toString() + "\n\n" + adviceFuncs.toString() + "\n\n /*3@0P*/?> \n\n" + phpSource.toString();
	weavedSource.setString(w);
}

// Generate Advice functions
void gen_functions(){
	int cnt = 0;
	cout << "Generating Final Advice..." << endl;
	string advFunctions = "";
	for(int i=0;i<funcList.countstnodes();i++){
		string jpName = funcList.getByID(i+1).str;
		bool r = adviceTable.returns(jpName,phpFileName);
		int x = adviceTable.findByName(jpName,phpFileName);
		addata dat = adviceTable.getByID(x);
		cout << "Building Advice For: " << jpName << "(" << dat.jpFuncParams << ")" << endl;
		// Start Function
		string curr = "";
		curr += "function ao_fi_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+") { \n";
		
		// Check for Before
		if(adviceTable.hasAdviceForType(1,jpName,phpFileName)){
			curr += "ao_bf_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+");";
		}
		
		// Check for Around
		if(adviceTable.hasAdviceForType(2,jpName,phpFileName)){
			if(r){
				curr += "$temp = ao_ar_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+");";
			}else{
				curr += "ao_ar_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+");";
			}
		}else{
			if(r){
				curr += "$temp = "+jpName+"("+get_correct_params(dat)+");";
			}else{
				curr += jpName+"("+get_correct_params(dat)+");";
			}
		}
		
		// Check for After
		if(adviceTable.hasAdviceForType(3,jpName,phpFileName)){
			curr += "ao_af_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+");";
		}
		
		// Finish Function
		if(r){
			// Returns
			curr += "return $temp; \n";
		}
		curr += " } \n\n";
		advFunctions += curr;
		cnt++;
	}
	adviceFuncs.setString(advFunctions);
	cout << cnt << " Advice Functions Defined" << endl;
}

void gen_helpers(){
	int cnt = 0;
	cout << "Generating Advice Pieces..." << endl;
	string advPieces = "";
	for(int i=0;i<funcList.countstnodes();i++){
		string jpName = funcList.getByID(i+1).str;

		// Check for Before
		if(adviceTable.hasAdviceForType(1,jpName,phpFileName)){
			addata dat = adviceTable.getDataForType(1,jpName,phpFileName);
			/**** DEBUGGING **/ if(debug) cout << jpName << " Has Before: " << dat.hash << endl;
			string curr = "function ao_bf_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+") { \n"+dat.code+" \n} \n\n";
			/**** DEBUGGING **/ if(debug) cout << "Function: " << curr << endl;
			advPieces += curr;
			cnt++;
		}

		// Check for Around
		if(adviceTable.hasAdviceForType(2,jpName,phpFileName)){
			addata dat = adviceTable.getDataForType(2,jpName,phpFileName);
			/**** DEBUGGING **/ if(debug) cout << jpName << " Has Around: " << dat.hash << endl;
			aoString ac(dat.code);
			if(adviceTable.returns(jpName,phpFileName)){
				// Around w/ Return
				/**** DEBUGGING **/ if(debug) cout << "Around w/ Return " << jpName << endl;
				ac.replace("proceed","return "+jpName);

				// Check for Return
				int p = ac.findString(0,"return");
				if(p<0){
					// No Return Found Error
					isError = true;
					error_log += "ERR: Advice Does Not Return ( "+dat.jpFunc+"("+dat.jpFuncParams+") ) in Aspect:"+dat.aspect+"<br>";
				}
			}else{
				// Around w/out Return
				/**** DEBUGGING **/ if(debug) cout << "Around w/out Return " << jpName << endl;
				ac.replace("proceed",jpName);
				int y = ac.findString(0,jpName);
				while(y != -1){
					int p = ac.findString(y,";");
					ac.insert(p+1,"return;");
					y = ac.findString(p,jpName);
				}
			}
			string curr = "function ao_ar_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+") { \n"+ac.toString()+" \n} \n\n";
			/**** DEBUGGING **/ if(debug) cout << "Function: " << curr << endl;
			advPieces += curr;
			cnt++;
		}

		// Check for After
		if(adviceTable.hasAdviceForType(3,jpName,phpFileName)){
			addata dat = adviceTable.getDataForType(3,jpName,phpFileName);
			/**** DEBUGGING **/ if(debug) cout << jpName << " Has After: " << dat.hash << endl;
			string curr = "function ao_af_"+dat.hash+"_"+jpName+"("+get_correct_params(dat)+") { \n"+dat.code+" \n} \n\n";
			/**** DEBUGGING **/ if(debug) cout << "Function: " << curr << endl;
			advPieces += curr;
			cnt++;
		}
	}
	helperFuncs.setString(advPieces);
	cout << cnt << " Advice Pieces Defined" << endl;
}

string get_correct_params(addata &x){
	aoString p(x.advParams);
	LListST params = p.explode(',');
	string t = "";
	if(x.jpFuncParamCnt >= x.advParamCnt){
		return x.advParams;
	}else if(x.jpFuncParamCnt < x.advParamCnt){
		for(int i=0;i<x.jpFuncParamCnt;i++){
			t += params.getByID(i+1).str;
			if(i!=x.jpFuncParamCnt-1){
				t+= ",";
			}
		}
	}
	return t;
}

void gen_list(){
	addata x;
	for(int i=0;i<adviceTable.countadnodes();i++){
		x = adviceTable.getByID(i+1);
		/**** DEBUGGING **/ if(debug) cout << "Testing... " << x.name << "(" << x.jpFunc << "," << x.jpFile << "," << phpIn << ")" << endl;
		if(funcList.findByName(x.name)==0 && phpFileName.compare(x.jpFile)==0){
			stdata tmp;
			tmp.str = x.name;
			funcList.insert(tmp);
		}
	}
	cout << "Target Functions: " << endl;
	funcList.dump();
}

void parse_more_advice(){
	for(int i=0;i<advList.countpcnodes();i++){
		string advDef = advList.getByID(i+1).name;
		string advCode = advList.getByID(i+1).definition;
		string advAspect = advList.getByID(i+1).aspect;
		trim(advCode);
		trim(advDef);
		trim(advAspect);

		string format(""); // Empty String Format
		sregex token = sregex::compile("(advice[\\s]*)(before|after|around|)\\(([a-zA-Z0-9_,$]*)\\)[\\s]*(:)");
		// Iterate Through Code
		sregex_iterator cur( advDef.begin(), advDef.end(), token );
		sregex_iterator end;
		// Iterate
		string advType = "";
		string advParams = "";
		string name = "";
		for( ; cur != end; ++cur ){
			// Get Current Match
    			smatch const &what = *cur;
    			// Process
			advType = what[2];
			advParams = what[3];
			int sc = what.position(4);
			aoString t(advDef);
			name = t.subStrSect(sc+1,t.findString(sc,"{")-1).toString();
    			trim(advType);
			trim(advParams);
			trim(name);
   		}
		/**** DEBUGGING **/ if(debug) cout << i << " - TYPE: " << advType << " - PARAMS: " << advParams << " - NAME: " << name << endl;
		
		// Get Each Pointcut & Parse Advice
		LListST f;
		recParse(name,advAspect,f);
		/**** DEBUGGING **/
		//cout << "----- ADVICE DUMP -----\n";
		//f.dump();
		//cout << "---------------------\n";
		/**** DEBUGGING **/ 
		for(int k=0;k<f.countstnodes();k++){
			// Parse Joinpoints
			string jp = f.getByID(k+1).str;
			cout << "Processing: " << jp << endl;
			trim(jp);

			string format(""); // Empty String Format
			/**** DEBUGGING **/ if(debug) cout << "Compiling JP Regular Expression...";
			sregex token = sregex::compile("(execr|exec|get|set)\\s*\\(\\s*(([a-zA-Z_][a-zA-Z0-9_.]*)\\s*\\(([a-zA-Z0-9_,$]*)\\)|[a-zA-Z_][a-zA-Z0-9_.]*)\\)");
			/**** DEBUGGING **/ if(debug) cout << "JP Regular Expression Compiled.";
			// Iterate Through Code
			sregex_iterator cur( jp.begin(), jp.end(), token );
			sregex_iterator end;
			// Iterate
			string jpType = "";
			string jpSig = "";
			string jpFunc = "";
			string jpFuncParams = "";
			int argStart = 0;
			for( ; cur != end; ++cur ){
				// Get Current Match
    				smatch const &what = *cur;
    				// Grab
				jpType = what[1]; // Type
				jpSig = what[2]; // Entire Sig, Hash This
				jpFunc = what[3]; // Just Funcion Sig
				jpFuncParams = what[4]; // Just Params
				argStart = what.length(0); // Non Processed Args
    				trim(jpType);
				trim(jpSig);
				trim(jpFunc);
				trim(jpFuncParams);
				/**** DEBUGGING **/ if(debug) cout << "Matched: " << jpSig << endl;
   			}
			// Process
			int len = jp.size() - argStart;
			string jpArgs = jp.substr(argStart,len);

			aoString ts;
			ts.setString(jpFunc);
			LListST z = ts.explode('.');
			ts.setString(jpSig);
			bool isVar = false;
			bool isObj = false;
			int jpFuncParamCnt = 0;
			string jpFile = "";
			string jpObj = "";

			if(ts.countOccurence('(')==0){
				isVar = true;
			}else{
				ts.setString(jpFuncParams);
				jpFuncParamCnt = ts.countOccurence(',')+1;
			}

			if(z.countstnodes()==2){
				jpFile = z.getByID(1).str;
				jpFunc = z.getByID(2).str;
			}else if(z.countstnodes()==3){
				isObj = true;
				jpFile = z.getByID(1).str;
				jpObj = z.getByID(2).str;
				jpFunc = z.getByID(3).str;
			}else{
				isError = true;
				error_log += "ERR: Invalid Joinpoint ("+jpSig+") in Aspect:"+advAspect+"<br>";
				continue;
			}
						
			addata t;
			t.name = jpFunc; // Required
			t.hash = MD5String(jpSig.c_str());
			// Advice Type: (1-before,2-around,3-after)
			t.advType = process_advType(advType);
			t.advParams = advParams;
			ts.setString(advParams);
			t.advParamCnt = ts.countOccurence(',')+1;
			// Joinpoint Type: (1-exec,2-execr,3-get,4-set)
			t.jpType = process_jpType(jpType);
			t.jpFile = jpFile;
			t.jpObj = jpObj;
			t.jpFunc = jpFunc;
			t.isObj = isObj;
			t.isVar = isVar;
			t.jpFuncParams = jpFuncParams;
			t.jpFuncParamCnt = jpFuncParamCnt;
			t.jpArgs = process_Args(jpArgs); //CSV Pairs - (Name,"Value String")
			t.code = advCode;
			t.aspect = advAspect;
			adviceTable.insert(t);
		}
	}
}

string process_Args(string s){
	string t = "";
	trim(s);
	/**** DEBUGGING **/ if(debug) cout << "Parsing Args: " << s << endl;
	aoString args(s);
	LListST l = args.explode('&','&');
	for(int i=1;i<l.countstnodes();i++){
		string temp = l.getByID(i+1).str;
		trim(temp);
		/**** DEBUGGING **/ if(debug) cout << "List Item:'" << temp << "'\n";
		aoString temp2(temp);
		int fp = temp2.findString(0,"(");
		int sp = temp2.findString(fp,")");
		string name = temp2.subStrSect(0,fp-1).toString();
		string value = temp2.subStrSect(fp+1,sp-1).toString();
		if(i==l.countstnodes()-1){
			t += "(" + name + "," + value + ")";
		}else{
			t += "(" + name + "," + value + ")#*";
		}
	}
	return t;
}

int process_jpType(string s){
	if(s.compare("exec")==0) return 1;
	if(s.compare("execr")==0) return 2;
	if(s.compare("get")==0) return 3;
	if(s.compare("set")==0) return 4;
}

int process_advType(string s){
	if(s.compare("before")==0) return 1;
	if(s.compare("around")==0) return 2;
	if(s.compare("after")==0) return 3;
}

void parse_advice(){
	for(int i=0;i<aspects.countasnodes();i++){
		asdata temp = aspects.getByID(i+1);
		string aopcode = temp.code;
		aoString t(aopcode);
		string format(""); // Empty String Format
		sregex token = sregex::compile("(advice[\\s]*)(before|after|around|)\\(([a-zA-Z0-9_,$]*)\\)[\\s]*(:)");
		// Iterate Through Code
		sregex_iterator cur( aopcode.begin(), aopcode.end(), token );
		sregex_iterator end;
		// Iterate
		for( ; cur != end; ++cur ){
			// Get Current Match
    			smatch const &what = *cur;
    			// Process
    			int b = t.findString(what.position(4),"{");
			string left = t.subStrSect(what.position(0),b).toString();
			string right = t.grabCode(b).toString();
    			trim(right);
			trim(left);
			pcdata tempPC;
			tempPC.definition = right; // Right Side (Code)
			tempPC.name = left; // Left Side
			tempPC.aspect = temp.name;
			advList.insert(tempPC);
			/**** DEBUGGING **/ if(debug) cout << "LEFT: " << left << ":END:" << endl << "RIGHT: " << right << ":END:" << endl;
   		}

		/**** DEBUGGING **/
		//cout << "----- ADVICE DUMP -----\n";
		//advList.dump();
		//cout << "---------------------\n";
		//cout << temp.code << endl;
		/**** DEBUGGING **/ 
	}
}

void parse_pointcuts(){
	for(int i=0;i<aspects.countasnodes();i++){
		asdata temp = aspects.getByID(i+1);
		string aopcode = temp.code;
		string format(""); // Empty String Format
		sregex token = sregex::compile("(pointcut\\s*)([a-zA-Z_][a-zA-Z0-9_]*)(\\s*=\\s*)([-\\]\\\\_+=()~!@#$%^&*`\"':[{}|/?,.<>\\w\\s]*);");
		// Iterate Through Code
		sregex_iterator cur( aopcode.begin(), aopcode.end(), token );
		sregex_iterator end;
		// Iterate
		for( ; cur != end; ++cur ){
			// Get Current Match
    			smatch const &what = *cur;
    			// Process
			string pc_name = what[2];
			string pc_def = what[4];
    			trim(pc_name);
			trim(pc_def);
			pcdata tempPC;
			tempPC.definition = pc_def;
			tempPC.name = pc_name;
			tempPC.aspect = temp.name;
			pclist.insert(tempPC);

   		}

		aopcode = regex_replace(aopcode,token,format);
		temp.code = aopcode;
		aspects.updateByID(temp.id,temp);

		/**** DEBUGGING **/
		//cout << "----- POINTCUT DUMP -----\n";
		//pclist.dump();
		//cout << "---------------------\n";
		//cout << temp.code << endl;
		/**** DEBUGGING **/ 
	}
}

void split_aspects(){
	asdata tempAsp;

	// Find Indivual Aspects & Store / Get Aspect Count
	int s = 0;
	int e = 0;
	int cd_s = 0; // Code Start
	int cd_e = 0; // Code End
	s = aopSource.indexOf("aspect",0);
	aoString curAspectCode;
	int aspCnt = 0;
	while(s != -1){
		cd_s = aopSource.findCodeStart(s+6);
		aoString aspName = aopSource.subStrSect(s+6,cd_s-1);
		aspName.trimWhiteSpace();
		/**** DEBUGGING **/ if(debug) cout << "Aspect Name: " << aspName << "\n";
		cd_e = aopSource.findCodeEnd(cd_s);
		s = aopSource.indexOf("aspect",cd_e);
		curAspectCode = aopSource.subStrSect(cd_s+1,cd_e-1);
		/**** DEBUGGING **/ if(debug) cout << curAspectCode << "\n" << cd_s << " - " << cd_e << "\n";
		aspCnt++;
		tempAsp.id = aspCnt;
		tempAsp.name = aspName.toString();
		tempAsp.code = curAspectCode.toString();
		aspects.insert(tempAsp);
	}
	cout << aspects.countasnodes() << " Asepcts Found" << endl;

	/**** DEBUGGING **/
	//cout << "----- LIST DUMP -----\n";
	//aspects.dump();
	//cout << "---------------------\n";
	/**** DEBUGGING **/ 
}

// Parse Aspects
int parse_aspects(){
	string phpcode = phpSource.toString();
	// Get File List
	sregex ws = sregex::compile("[\\s]*"); // Remove Whitespace
    string format(""); // Empty String Format
    // Find aophp_init Call
    sregex token = sregex::compile("(aophp_init\\(\")([A-Za-z0-9.,_-]*)(\"\\);)");
    // Iterate Through PHP Cpde
    sregex_iterator cur( phpcode.begin(), phpcode.end(), token );
    sregex_iterator end;
    // Iterate
    string files;
	string m;
	int fCnt = 0;
	bool matched = false;
    for( ; cur != end; ++cur ){
        // Get Current Match
    	smatch const &what = *cur;
    	// Remove Whitespace
    	files = regex_replace(what[2].str(),ws,format);
		m = what[0].str();
		if(files.compare("")!=0){
			matched = true;
		}
    	break;
   	}

	// Replace Call
	phpSource.setString(phpcode);
	phpSource.replace(m,"");

	if(matched){
		aoString f(files);
		fCnt = f.countOccurence(',')+1;
		/**** DEBUGGING **/ if(debug) cout << "File List(" << fCnt << "): " << f << endl;

		// Put Files into String Array
		string *inFileArray;
		inFileArray = new string[fCnt];
		StringTok t(f,",");
		t.tokenize();
		aoString tmpAostr;
		for(int i=0; i<fCnt; i++){
			tmpAostr = t.getNext();
			inFileArray[i] = tmpAostr.toString();
		}

		// Open and Read Files
		for(int i=0; i<fCnt; i++){
			ifstream inFile;
			int k = inFileArray[i].find(".aophp");
			if(k < 0){
				isError = true;
				string t = "ERR: Invalid Aspect File Type Found: " + inFileArray[i];
				error_log += t+"<br>";
				cout << t << "\n";
				continue;
			}
			string tempstring = phpFileDir+inFileArray[i];
			inFile.open(tempstring.c_str(),ios::in);
			if(!inFile){
				isError = true;
				string t = "ERR: Could Not Open Aspect File: " + inFileArray[i];
				error_log += t+"<br>";
				cout << t << "\n";
				continue;
			}else{
				cout << "Opened Aspect File: " << inFileArray[i] << "\n";
				string tmpStr = "";
				while(!inFile.eof()){
					getline(inFile,tmpStr);
					aopSource += tmpStr + "\n";
				}
				inFile.close();
			}
		}
	}else{
		isError = true;
		error_log += "Invalid aophp_init Call in Source File.<br>";
		return 3;
	}
	/**** DEBUGGING **/ if(debug) cout << "AOSRC: " << aopSource.toString() << endl << "PHPCode: " << phpSource.toString() << endl << "FILES: " << files << endl;
	aopSource.stripComments();
	if(fCnt == 0){
		return 2;
	}
	return 1;
}

bool parse_args(int argc, char* argv[]){
	// Parse Aguments

	// Cmd Line Flags
	// -s [0|1] = Include Status 0-Off 1-On
	// -l [0-5] = Include Level
	// -d = Enable aophpDoc
	// -h "#XXXXXX" = aophpDoc HTML Color
	// -p "#XXXXXX" = aophpDoc AOPHP Color
	// -m "/Path/To/File/" = Meta Data Logging
	// -x = Debug Mode On
	string argtemp = "";
	cout << "Arg. Count: " << argc << endl << "Arguments: " << endl;
	try{
		for(int i=0;i<argc;i++){
			argtemp = argv[i];
			if(argtemp.compare("-s")==0){
				i++;
				argtemp = argv[i];
				INC_STATUS = atoi(argv[i]);
			}else if(argtemp.compare("-l")==0){
				i++;
				argtemp = argv[i];
				INC_DEPTH = atoi(argv[i]);
			}else if(argtemp.compare("-h")==0){
				i++;
				string htmldebugtemp(argv[i]);
				DOC_HTML = htmldebugtemp;
			}else if(argtemp.compare("-p")==0){
				i++;
				string phpdebugtemp(argv[i]);
				DOC_PHP = phpdebugtemp;
			}else if(argtemp.compare("-d")==0){
				printDoc = true;
			}else if(argtemp.compare("-x")==0){
				debug = true;
			}else if(argtemp.compare("-m")==0){
				i++;
				string metafiletemp(argv[i]);
				META_LOG = metafiletemp;
			}else{
				if(i==1){
					phpIn = argtemp;
				}else if(i==2){
					phpOut = argtemp;
				}
			}
		}
	}catch(std::logic_error&){
		cerr << "Invalid Parameters. Failing" << endl;
		return false;
	}
	cout << "In File: " << phpIn << endl;
	cout << "Out File: " << phpOut << endl;
	cout << "Inc. Status: " << INC_STATUS << endl;
	cout << "Inc. Depth: " << INC_DEPTH << endl;
	cout << "Doc. HTML Color: " << DOC_HTML << endl;
	cout << "Doc. PHP Color: " << DOC_PHP << endl;
	cout << "Print Doc: " << printDoc << endl;
	cout << "Meta Log File: " << META_LOG << endl;
	return true;
}

// Open and Parse PHP File
bool open_parse_PHP(){
	int s = phpIn.find_last_of('/')+1;
	int l = phpIn.find_first_of('.') - s;
	phpFileName = phpIn.substr(s,l);
	phpFileDir = phpIn.substr(0,s);
	cout << "Paths: " << phpFileName << " - " << phpFileDir << endl;
	// Open PHP Source Input File
	ifstream inFile;
	inFile.open(phpIn.c_str(),ios::in);
	if(!inFile){
		cerr << "ERR: Could Not Source Open File\n";
		return false;
	}else{
		cout << "Opened Source File\n";
	}

	// Parse PHP Source File to String
	string tmpStr;
	while(!inFile.eof()){
		getline(inFile,tmpStr);
		phpSource += tmpStr + "\n";
	}
	inFile.close();
	/**** DEBUGGING **/ if(debug) cout << endl << phpSource << endl;
	cout << "PHP Source Parsed\n";
	return true;
}

// File Writer
void writeOutFile(string oFile, string content){
  ofstream outFile;
  outFile.open(oFile.c_str(),ios::out);
  outFile << content;
  outFile.close();
}

// String Trimmer
void trim(string& str){
	string::size_type pos1 = str.find_first_not_of(" \t\r\n");
	string::size_type pos2 = str.find_last_not_of(" \t\r\n");
	str = str.substr(pos1 == string::npos ? 0 : pos1, 
		pos2 == string::npos ? str.length() - 1 : pos2 - pos1 + 1);
}

// String Parser
void recParse(string S, string A, LListST& L){
	/**** DEBUGGING **/ if(debug) cout << "Parsing: " << S << endl;
	aoString T;
	T.setString(S);
	LListST Z = T.explode('|','|');
	for(int i=0;i<Z.countstnodes();i++){
		string y = Z.getByID(i+1).str;
		/**** DEBUGGING **/ if(debug) cout << "   - Y: " << y << endl;
		trim(y); 
		sregex m = sregex::compile("\\s*([a-zA-Z_][a-zA-Z0-9_]*)\\s*");
		if(regex_match(y,m)){
			// Named PC
			int o = pclist.findByName(y);
			if(o >= 1){
				y = pclist.getByID(o).definition;
				recParse(y,A,L);
			}
		}else{
			// Non Named, Add
			stdata q;
			q.str = y;
			L.insert(q);
		}
	}
}
