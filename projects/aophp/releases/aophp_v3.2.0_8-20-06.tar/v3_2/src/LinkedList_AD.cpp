/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
#include <iostream>
#include <string>
#include "LinkedList_AD.h"
using namespace std;

LListAD::LListAD(){
	front = NULL;
	rear = NULL;
	count = 0;
}

LListAD::LListAD(const LListAD & original){
	adnode *temp; // Used to Create the adnodes
	adnode *current; // The adnode were Currently on
	adnode *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new adnode;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new adnode;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

LListAD & LListAD::operator = (const LListAD & original){
	adnode *temp; // Used to Create the adnodes
	adnode *current; // The adnode were Currently on
	adnode *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new adnode;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new adnode;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

LListAD::~LListAD(){
	reset();
}

void LListAD::reset(){
	while(!isEmpty()){
		adnode *temp = front;
		front = front->next;
		delete temp;
	}
	count = 0;
}

addata LListAD::getFirst(){
	return front->info;
}

addata LListAD::getLast(){
	return rear->info;
}

addata LListAD::getByID(int x){
	adnode *temp = front;
	while(temp != NULL){
	  //cout << temp->info.name << endl;
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void LListAD::insert(addata item){
	adnode *temp = new adnode;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int LListAD::countadnodes(){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int LListAD::findByName(string name, string file){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(name) == 0 && temp->info.jpFile.compare(file) == 0){
			return temp->info.id;
		}
		temp = temp->next;
	}
	count = x;
	return 0;
}

bool LListAD::isEmpty() const{
	return (front == NULL);
}

bool LListAD::hasNext() const{
	return !isEmpty();
}

void LListAD::dump() const{
	adnode *temp = new adnode;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.name << " - " << temp->info.advType << endl;
		temp = temp->next;
	}
}

void LListAD::spill() const{
	adnode *temp = new adnode;
	temp = front;
	while(temp != NULL){
		cout << "******************************\n";
		cout << "id: " << temp->info.id << "\n"; // Required
		cout << "name: " << temp->info.name << "\n"; // Required
		cout << "hash: " << temp->info.hash << "\n";
		cout << "advType: " << temp->info.advType << "\n"; // (1-before,2-around,3-after)
		cout << "advParams: " << temp->info.advParams << "\n";
		cout << "advParamCnt: " << temp->info.advParamCnt << "\n";
		cout << "jpType: " << temp->info.jpType << "\n"; // (1-exec,2-execr,3-get,4-set)
		cout << "jpFile: " << temp->info.jpFile << "\n";
		cout << "jpObj: " << temp->info.jpObj << "\n";
		cout << "isObj: " << temp->info.isObj << "\n";
		cout << "isVar: " << temp->info.isVar << "\n";
		cout << "jpFunc: " << temp->info.jpFunc << "\n";
		cout << "jpFuncParams: " << temp->info.jpFuncParams << "\n";
		cout << "jpFuncParamCnt: " << temp->info.jpFuncParamCnt << "\n";
		cout << "jpArgs: " << temp->info.jpArgs << "\n"; //CSV Pairs - (Name,"Value String")
		cout << "aspect: " << temp->info.aspect << "\n";
		cout << "code: " << temp->info.code << "\n";
		
		temp = temp->next;
	}
}

bool LListAD::returns(string sig, string name){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(sig) == 0 && temp->info.jpFile.compare(name) == 0){
			if(temp->info.jpType == 2 || temp->info.jpType == 3){
				return true;
			}
		}
		temp = temp->next;
	}
	return false;
}

bool LListAD::hasAdviceForType(int t, string sig, string name){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(sig) == 0 && temp->info.jpFile.compare(name) == 0){
			if(temp->info.advType == t){
				return true;
			}
		}
		temp = temp->next;
	}
	return false;
}

string LListAD::getCodeForType(int t, string sig, string name){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(sig) == 0 && temp->info.jpFile.compare(name) == 0){
			if(temp->info.advType == t){
				return temp->info.code;
			}
		}
		temp = temp->next;
	}
	return "";
}

addata LListAD::getDataForType(int t, string sig, string name){
	addata n;
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(sig) == 0 && temp->info.jpFile.compare(name) == 0){
			if(temp->info.advType == t){
				return temp->info;
			}
		}
		temp = temp->next;
	}
	return n;
}

