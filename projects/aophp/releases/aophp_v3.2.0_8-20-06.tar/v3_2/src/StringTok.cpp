/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
/*

Developed & Released under the
	aoPHP GNU Public License
Coded by Bryan Saunders

String Tokenizer Class
Implemented as a Dynamic Queue

*/

#include <iostream>
#include <string>
#include "StringTok.h"
using namespace std;

StringTok::StringTok(aoString in, string d){
	front = NULL;
	rear = NULL;
	orig = in;
	delim = d;
}

StringTok::StringTok(string in, string d){
	front = NULL;
	rear = NULL;
	orig = in;
	delim = d;
}

StringTok::StringTok(const StringTok & original){
	token *temp; // Used to Create the Nodes
	token *current; // The Node were Currently on
	token *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new token;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new token;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

StringTok & StringTok::operator = (const StringTok & original){
	token *temp; // Used to Create the Nodes
	token *current; // The Node were Currently on
	token *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new token;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new token;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

void StringTok::tokenize(){
	string in = orig.toString();
	int curPos = -1;
	string tmp = "";
	/**** DEBUGGING **/ //cout << "STRTOK: " << in << endl;
	curPos = in.find(delim);
	/**** DEBUGGING **/ //cout << curPos << "\n";
	while(curPos > 0){
		tmp = in.substr(0,curPos);
		this->insertToken(tmp);
		in.erase(0,curPos+1);
		tmp = "";
		curPos = in.find(delim);
	}
	this->insertToken(in);
}

void StringTok::insertToken(aoString item){
	token *temp = new token;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

aoString StringTok::getRemaining() const{
	token *temp = new token;
	temp = front;
	aoString line;
	while(temp != NULL){
		line += temp->info;
		temp = temp->next;
		if(temp != NULL){
			line += delim;
		}
	}
	//aoString r;
	//r.setString(line);
	return line;
}

void StringTok::dumpTokens() const{
	token *temp = new token;
	temp = front;
	while(temp != NULL){
		cout << "--> "<< temp->info << endl;
		temp = temp->next;
	}
}

int StringTok::countTokens() const{
	token *temp = new token;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	return x;
}

aoString StringTok::getNext(){
	aoString item;
	token *temp = front;
	item = front->info;
	front = front->next;
	delete temp;
	return item;
}

aoString StringTok::getOrig(){
	return orig;
}

bool StringTok::isEmpty() const{
	return (front == NULL);
}

bool StringTok::hasNext() const{
	return !isEmpty();
}

void StringTok::reset(aoString text,string d){
	aoString item;
	while(!isEmpty()){
		item = getNext();
	}
	orig = text;
	delim = d;
}

void StringTok::reset(string text,string d){
	aoString item;
	while(!isEmpty()){
		item = getNext();
	}
	orig = text;
	delim = d;
}

StringTok::~StringTok(){
	aoString item;
	while(!isEmpty()){
		item = getNext();
	}
}
