/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
#include <iostream>
#include <string>
#include "LinkedList_FC.h"
using namespace std;

LListFC::LListFC(){
	front = NULL;
	rear = NULL;
	count = 0;
}

LListFC::LListFC(const LListFC & original){
	fcnode *temp; // Used to Create the fcnodes
	fcnode *current; // The fcnode were Currently on
	fcnode *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new fcnode;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new fcnode;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

LListFC & LListFC::operator = (const LListFC & original){
	fcnode *temp; // Used to Create the fcnodes
	fcnode *current; // The fcnode were Currently on
	fcnode *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new fcnode;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new fcnode;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

LListFC::~LListFC(){
	reset();
}

void LListFC::reset(){
	while(!isEmpty()){
		fcnode *temp = front;
		front = front->next;
		delete temp;
	}
	count = 0;
}

fcdata LListFC::getFirst(){
  fcdata temp = front->info;  
  front = front->next;
  return temp;
}

fcdata LListFC::getLast(){
	return rear->info;
}

fcdata LListFC::getByID(int x){
	fcnode *temp = front;
	while(temp != NULL){
	  //cout << temp->info.name << endl;
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void LListFC::insert(fcdata item){
	fcnode *temp = new fcnode;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int LListFC::countfcnodes(){
	fcnode *temp = new fcnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int LListFC::findByName(string name){
	fcnode *temp = new fcnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.str.compare(name) == 0){
			return temp->info.id;
		}
		temp = temp->next;
	}
	count = x;
	return 0;
}

bool LListFC::isEmpty() const{
	return (front == NULL);
}

bool LListFC::hasNext() const{
	return !isEmpty();
}

void LListFC::dump() const{
	fcnode *temp = new fcnode;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.str << endl;
		temp = temp->next;
	}
}

