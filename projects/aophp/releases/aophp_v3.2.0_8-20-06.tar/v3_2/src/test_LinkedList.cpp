/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
#include <iostream>
#include <string>
#include "LinkedList.h"
using namespace std;

int main(){

	LList l;

	data a,b,c,d,e;
	a.id = 1;
	a.name = "A";
	b.id = 3;
	b.name = "B";
	c.id = 5;
	c.name = "C";
	d.id = 7;
	d.name = "D";
	e.id = 9;
	e.name = "E";

	l.insert(a);
	l.insert(c);
	cout << "Dumping A/C" << endl;

	cout << "ID of C: " << l.findByName("C") << endl;

	l.insert(b);
	l.dump();
	cout << "Count: " << l.countNodes() << endl;

	cout << l.getFirst().name << endl;
	cout << l.getLast().name << endl;
	cout << "------" << endl;
	string h = l.getByID(3).name;
	cout << "------" << endl << h << endl;

	cout << l.hasNext() << endl;

	l.reset();
	cout << "--" << endl;
	l.dump();
	cout << "--" << endl;
	l.insert(d);
	l.insert(e);
	l.dump();



	return 0;
}

