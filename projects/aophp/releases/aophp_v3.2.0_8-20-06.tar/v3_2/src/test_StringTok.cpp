/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/

#include <iostream>
#include <string>
#include "StringTok.h"
using namespace std;

int main(){
	aoString s1,s2,s3;
	s1 = "A,B,C,D";
	s3 = "1!2!3!4!5";
	StringTok st1(s1,",");
	st1.tokenize();
	cout << "Count: " << st1.countTokens() << endl;
	int c = st1.countTokens();
	for(int i=0;i<c-2;i++){
		s2 = st1.getNext();
		cout << s2 << endl;
	}
	cout << st1.getRemaining() << endl;

	st1.reset(s3,"!");
	st1.tokenize();
	cout << "Count: " << st1.countTokens() << endl;
	c = st1.countTokens();
	for(int k=0;k<c-2;k++){
		s2 = st1.getNext();
		cout << s2 << endl;
	}
	cout << st1.getRemaining() << endl;

	return 0;
}

