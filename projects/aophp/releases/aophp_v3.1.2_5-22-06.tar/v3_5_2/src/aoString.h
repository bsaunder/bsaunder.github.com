/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp v3.1, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/

#include <string>
#include <iostream>
#include "LinkedList_ST.h"
using namespace std;
using std::ostream;
using std::istream;

class aoString{
	friend ostream& operator << (ostream& os, const aoString& s){
			return os << s.code;
	}
	
	private:
		string code;

	public:
		const bool operator == (const aoString & r){ return (code == r.code); }
		const aoString &operator = (const aoString & r){ code = r.code; return *this; }
		const aoString &operator = (const string & r){ code = r; return *this; }
		const aoString &operator += (const aoString & r){ code += r.code; return *this; }
		const aoString &operator += (const string & r){ code += r; return *this; }

		aoString();
		aoString(string);

		void setString(string);
		string toString();

		int countOccurence(char);
		int countOccurence(int,string);
		int findString(int,string);
		int findStringInject(int,string);
		int length();
		aoString subStrLeng(int,int);
		aoString subStrSect(int,int); // Parameters are Inclusive
		int indexOf(string,int);
		int indexOf(char,int);
		int rindexOf(string,int);
		int rindexOf(char,int);
		void replace(string,string);
		void inject(string,string);
		void insert(int,string);
		void remove(int,int); // Parameters are Inclusive

		void trimWhiteSpace();
		void trim();
		int findCodeStart(int);
		int findCodeEnd(int);
		void stripComments();
		aoString grabCode(int);
		LListST explode(char);
		LListST explode(char,char);
};
