<?php

require_once("../Source/AOPHP.php");

//echo "In: $inputFilePath - InDir: $inputFileDirectory - Out: $outputFilePath";

$inputFileDirectory = "";
$inputFilePath = "after.php";
$outputFilePath = "after_processing.php";

$weaver = new AOPHPWeaver();

//pass the arguments to the AOPPHPWeaver and perform class weaving if necessary
$weaver->invoke($inputFileDirectory, $inputFilePath, $outputFilePath);


include($outputFilePath);

?>
