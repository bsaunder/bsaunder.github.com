AOPHP v2.1 PHP port

Author: Mike Reinstein <covert_access@yahoo.com>
Date: 03-08-2005


Usage:
In the /Sample directory there is a file called test.php that shows how to invoke it.
I don't use any of the stuff in /Program so you can hopefully integrate this code into the rnecessary files in /Program 


Encountered a potential problem:
I think I may have found a bug in the code. If you look in Source/AOPHP.php you'll see 2 blocks of code, one is active (lines 266-275) , one is commented out (lines 280-307). The active code is my attempt at fixing the logic from the commented out code.

Look at these lines (280-283):
-----------------------------------------------------------------
$jpList = explode("|", $adviceJP);
echo "\nadviceJP '$adviceJP', size:". count($jpList) ." \n";
$jp = "";
for($k = 0; $k < count($jpList);$k++){
	if($jpList[$k] == "|"){
-----------------------------------------------------------------
In the above code the $adviceJP is split by the '|' character into tokens and each token is put into the $jpList array. But then there's an if statement inside the for loop that looks at each token and checks for a '|' character. I don't think this case can ever happen.
