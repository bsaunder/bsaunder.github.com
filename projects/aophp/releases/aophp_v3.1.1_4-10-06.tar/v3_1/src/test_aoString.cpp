/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp v3.1, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/


#include <iostream>
#include <string>
#include "aoString.h"
using namespace std;

int main(){
	aoString s1,s4,s5;
	aoString s2("<? function add($x,$y){ if($x==2){return 2;}else{return $x+$y;} return -1;} echo \"Hello \\\" World\"; //Cheese \n /**** echo \"Hello World\"; ***/ ?>");
	aoString s3("    apple orange apple orange apple  ");
	s1.setString("<? echo \"If Statement\"; if(2 == 2){ echo \"2 is 2\"; }?>");
	s4 = "<? echo \"If Statement\"; if(2 == 2){ echo \"2 is 2\"; }?>";
	aoString s9("<? if(x<5){ echo \"else\"; }else{ echo \"echo\"; } ?>");
	cout << s1 << endl;
	cout << s2 << endl;
	cout << s4 << endl;
	s5 = "<?";
	s5 += " exit(0);";
	s5 += " ?>";
	s5 += s4;
	cout << s5 << endl;

	if(s1 == s4){
		cout << "Equal" << endl;
	}

	cout << "Semicolons: " << s1.countOccurence(';') << endl;
	cout << "Sub 0 -> 4: " << s1.subStrLeng(0,4) << "|\n";
	cout << "Sub 4 - 6: " << s1.subStrSect(4,6) << "|\n";
	cout << "1st echo: " << s1.indexOf("echo",0) << endl;
	cout << "1st ?: " << s1.indexOf('?',0) << endl;
	cout << "R 1st echo: " << s1.rindexOf("echo",s1.length()) << endl;
	cout << "R 1st ?: " << s1.rindexOf('?',s1.length()) << endl;

	s3.replace("apple","orange");
	cout << s3 << endl;

	s2.insert(3,"echo \"Bob\"; ");
	cout << s2 << endl;

	cout << "Before: '"<< s3 << "'" << endl;
	s3.trimWhiteSpace();
	cout << "After: '"<< s3 << "'" << endl;

	cout << "Before: '"<< s2 << "'" << endl;
	s2.stripComments();
	cout << "After: '"<< s2 << "'" << endl;
	int x = s2.findCodeStart(0);

	cout << "At 0: " << x << " - " << s2.toString().at(x) << endl;
	cout << "At 38: " << s2.findCodeStart(38) << endl;
	int y = s2.findCodeEnd(x);
	cout << "End: " << y << endl;
	cout << s2.grabCode(x) << endl;
	cout << s9 << " || else @ " << s9.findString(0,"else") << endl;
	aoString s10("Hello\n\n");
	s10.trimWhiteSpace();
	cout << s10 << endl;
	int cnt = s9.countOccurence(0,"echo");
	cout << cnt << endl;
	return 0;
}
