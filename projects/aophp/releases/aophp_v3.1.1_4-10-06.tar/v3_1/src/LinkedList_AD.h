/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp v3.1, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/

#ifndef LINKED_LIST_AD
#define LINKED_LIST_AD
#include <iostream>
#include <string>
using namespace std;

struct addata{
	int id; // Required
	string name; // Required
	int advType; // (1-before,2-around,3-after)
	string advParams;
	int advParamCnt;
	int jpType; // (1-exec,2-execr,3-get,4-set)
	string jpSig;
	string jpSigParams;
	int jpSigParamCnt;
	string jpArgs; //CSV Pairs - (Name,"Value String")
	string code;
};

struct adnode{
	addata info;
	adnode *next;
};

class LListAD{
	private:
		adnode *front;
		adnode *rear;
		int count;
	public:
		LListAD();
		LListAD(const LListAD &);
		LListAD & operator = (const LListAD &);
		void insert(addata);
		int findByName(string);
		addata getFirst();
		addata getLast();
		addata getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		bool returns(string);
		bool hasAdviceForType(int,string);
		string getCodeForType(int,string);
		void dump() const;
		int countadnodes();
		void reset();
		~LListAD();
};

#endif

