/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp v3.1, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/
#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>
#include "StringTok.h"
#include "LinkedList_PC.h"
#include "LinkedList_AD.h"
#include "LinkedList_AS.h"
#include "LinkedList_ST.h"
#include "md5.h"
#include <boost/xpressive/xpressive_dynamic.hpp>

using namespace boost::xpressive;
using namespace std;

/*** Setup Variables ***/
const int MAX_CHARS_LINE = 500;
const int ARG_CNT = 2;

/*** Status Codes ***/
const int COMPLETED = 0;
const int DECLINED = 1;
const int SRC_FILE_ERROR = 2;
const int INV_ASPECT_FILE = 3;
const int INV_ASPECT_ARGS = 4;
const int ASPECT_FILE_ERROR = 5;
const int WRONG_ARG_CNT = 99;
const int INVALID_PC_DEC = 6;

LListPC pclist;
LListST finalList;

// Aspect Structure - Composed of Advice and Pointcuts
struct Aspect{
  aoString name;
  aoString code;
};

// File Writer
void writeOutFile(string oFile, string content){
  ofstream outFile;
  outFile.open(oFile.c_str(),ios::out);
  outFile << content;
  outFile.close();
}

// String Trimmer
void trim(string& str)
{
	string::size_type pos1 = str.find_first_not_of(" \t\r\n");
	string::size_type pos2 = str.find_last_not_of(" \t\r\n");
	str = str.substr(pos1 == string::npos ? 0 : pos1, 
		pos2 == string::npos ? str.length() - 1 : pos2 - pos1 + 1);
}

// String Parser
void recParse(string S){
	aoString T;
	T.setString(S);
	LListST Z = T.explode('|','|');
	for(int i=0;i<Z.countstnodes();i++){
		string y = Z.getByID(i+1).str;
		trim(y); 
		int o = pclist.findByName(y);		if(o >= 1){
			y = pclist.getByID(o).definition;
			recParse(y);
		}else{
			stdata q;
			q.str = y;
			finalList.insert(q);
		}
	}
}
int main(int argc, char* argv[]){

	int INC_STATUS = 0; // Off by Default
	int INC_DEPTH = 1; // 1 Level by Default

	string phpIn,phpOut;
	aoString phpSource;

	// Command Line Arguments
	// Only 1-4 Passed at Command Line
	// 0 - Relative Path to Executable from Working Directory
	// 1 - PHP In File
	// 2 - PHP Out File
	// 3 - Include Status -> 0 On, 1 Off
	// 4 - Include Level -> 0 is Infinite

	// Check for Arguments
	if(argc <= ARG_CNT){
		cerr << "ERR: Wrong Argument Count\n";
		return WRONG_ARG_CNT;
	}

	// Parse Aguments
	string argtemp = "";
	cout << "Arg. Count: " << argc << endl << "Arguments: " << endl;
	for(int i=0;i<argc;i++){
		argtemp = argv[i];
		if(argtemp.compare("-s")==0){
			i++;
			//argtemp = argv[i];
			INC_STATUS = atoi(argv[i]);
		}else if(argtemp.compare("-d")==0){
			i++;
			//argtemp = argv[i];
			INC_DEPTH = atoi(argv[i]);
		}else{
			if(i==1){
				phpIn = argtemp;
			}else if(i==2){
				phpOut = argtemp;
			}
		}
	}
	cout << "In File: " << phpIn << endl;
	cout << "Out File: " << phpOut << endl;
	cout << "Inc. Status: " << INC_STATUS << endl;
	cout << "Inc. Depth: " << INC_DEPTH << endl;

	// Open PHP Source Input File
	ifstream inFile;
	inFile.open(phpIn.c_str(),ios::in);
	if(!inFile){
		cerr << "ERR: Could Not Source Open File\n";
		return SRC_FILE_ERROR;
	}else{
		cout << "Opened Source File\n";
	}

	// Parse PHP Source File to String
	string tmpStr;
	while(!inFile.eof()){
		getline(inFile,tmpStr);
		phpSource += tmpStr + "\n";
	}
	inFile.close();
	phpSource.stripComments();
	/**** DEBUGGING **/ //cout << endl << phpSource << endl;
	cout << "PHP Source Parsed\n";

	// Find aoPHP Files
	string *aopFileList;
	int aopFileCount = 0;
	int s = phpSource.indexOf("aophp_init",0);
	if(s == -1){
		// aoPHP Init Not Found. Write File & End
		cout << "No Weave Needed" << endl;
		writeOutFile(phpOut,phpSource.toString());
		return COMPLETED;
	}
	int s2 = phpSource.indexOf('(',s);
	int e = phpSource.indexOf(')',s2);
	aoString f = phpSource.subStrSect(s2+2,e-2);
	int fCnt = f.countOccurence(',')+1;
	/**** DEBUGGING **/ //cout << "File List(" << fCnt << "): " << f << endl;

	// Put Files into String Array
	string *inFileArray;
	inFileArray = new string[fCnt];
	StringTok t(f,",");
	t.tokenize();
	aoString tmpAostr;
	for(int i=0; i<fCnt; i++){
		tmpAostr = t.getNext();
		inFileArray[i] = tmpAostr.toString();
	}

	// Open and Read Files
	aoString aopSource;
	for(int i=0; i<fCnt; i++){
		ifstream inFile;
		int k = inFileArray[i].find(".aophp");
		if(k < 0){
			cout << "ERR: Invalid Aspect File Type Found: " << inFileArray[i] << "\n";
			continue;
		}
		inFile.open(inFileArray[i].c_str(),ios::in);
		if(!inFile){
			cerr << "ERR: Could Not Open Aspect File: " << inFileArray[i] << "\n";
			continue;
		}else{
			cout << "Opened Aspect File: " << inFileArray[i] << "\n";
			tmpStr = "";
			while(!inFile.eof()){
				getline(inFile,tmpStr);
				aopSource += tmpStr + "\n";
			}
			inFile.close();
		}
	}
	/**** DEBUGGING **/ //cout << endl << aopSource << endl;

	// Erase aoPHP Init Call from PHP Source
	e = phpSource.indexOf(';',e);
	phpSource.remove(s,e);
	/**** DEBUGGING **/ //cout << endl << phpSource << endl;
	
	// Create Aspect Linked List
	LListAS aspects; 
	asdata tempAsp;

	// Find Indivual Aspects & Store / Get Aspect Count
	s = 0;
	e = 0;
	int cd_s = 0; // Code Start
	int cd_e = 0; // Code End
	s = aopSource.indexOf("aspect",0);
	aoString curAspectCode;
	int aspCnt = 0;
	while(s != -1){
	  cd_s = aopSource.findCodeStart(s+6);
	  aoString aspName = aopSource.subStrSect(s+6,cd_s-1);
	  aspName.trimWhiteSpace();
	  /**** DEBUGGING **/ //cout << "Aspect Name: " << aspName << "\n";
	  cd_e = aopSource.findCodeEnd(cd_s);
	  s = aopSource.indexOf("aspect",cd_e);
	  curAspectCode = aopSource.subStrSect(cd_s,cd_e-1);
	  /**** DEBUGGING **/ //cout << curAspectCode << "\n" << cd_s << " - " << cd_e << "\n";
	  aspCnt++;
	  tempAsp.id = aspCnt;
	  tempAsp.name = aspName.toString();
	  tempAsp.code = curAspectCode.toString();
	  aspects.insert(tempAsp);
        }
	cout << aspects.countasnodes() << " Asepcts Found" << endl;
	
	/**** DEBUGGING **/
	//cout << "----- LIST DUMP -----\n";
	//aspects.dump();
	//cout << "---------------------\n";
	/**** DEBUGGING **/       

	// Breakdown Aspects
	int l = 0;
	s = 0;
	e = 0;
	cd_s = 0;
	cd_e = 0;
	aoString pcs, adv;
	aoString pcs_f, adv_f;
	int pcsCnt_f, advCnt_f;
	for(int i=0;i<aspects.countasnodes();i++){
	  tempAsp = aspects.getByID(i+1);
	  /**** DEBUGGING **/ //cout << tempAsp.name << "\n";
	  curAspectCode.setString(tempAsp.code);
	  // Get Pointcut Block
	  s = curAspectCode.findString(0,"vars:")+5;
	  e = curAspectCode.findString(s+1,"data:")-1;
	  pcs = curAspectCode.subStrSect(s,e);
	  //pcs.trimWhiteSpace();
	  /**** DEBUGGING **/ //cout << "PCS: " << pcs << endl;
	  l = curAspectCode.length();
	  s = e+5;
	  e = l;
	  //adv.trimWhiteSpace();
	  adv = curAspectCode.subStrSect(s+1,e);
	  /**** DEBUGGING **/ //cout << "ADV: " << adv << endl;

	  // Count Number of Pointcuts and Advice
	  int pcsCnt = pcs.countOccurence(0,";");
	  int advCnt = adv.countOccurence(0,"advice");
	  /**** DEBUGGING **/ //cout << "#PCS: " << pcsCnt << " | #ADV: " << advCnt << endl;

	  pcsCnt_f += pcsCnt;
	  advCnt_f += advCnt;
	  pcs_f += pcs;
	  adv_f += adv;

	}

	cout << pcsCnt_f << " Pointcuts Found" << endl;
	cout << advCnt_f << " Advice Found" << endl;

	/**** DEBUGGING **/ //cout << "ADV: " << adv_f << endl;
	/**** DEBUGGING **/ //cout << "PCS: " << pcs_f << endl;
	/**** DEBUGGING **/ //cout << "#PCS: " << pcsCnt_f << " | #ADV: " << advCnt_f << endl;

	// Parse Pointuts to LinkedList
	//LListPC pclist;
	LListST stlist;
	pcs_f.trim();
	adv_f.trim();
	stlist = pcs_f.explode(';');
	/**** DEBUGGING **/ //cout << "PCS Dump:\n"; stlist.dump();
	pcdata tempPC;
	for(int i=0;i<stlist.countstnodes();i++){
		string x = stlist.getByID(i+1).str;
		aoString y(x);
		y.trim();
		LListST temp = y.explode('=');
		/**** DEBUGGING **/ //cout << "TEMP Dump:\n"; temp.dump();
		string pc_name = temp.getByID(1).str;
		string pc_def = temp.getByID(2).str;
		int s = pc_name.rfind(" ",pc_name.length());
		if(s == string::npos){
			cerr << "ERR: Invalid Poincut Decleration - " << pc_name << "\n";
			return INVALID_PC_DEC;
		}
		pc_name = pc_name.substr(s);
		trim(pc_name);
		trim(pc_def);
		tempPC.definition = pc_def;
		tempPC.name = pc_name;
		pclist.insert(tempPC);
		/**** DEBUGGING **/ //cout << "Pointcut:" << pc_name << " *|* " << pc_def << endl;
		/**** DEBUGGING **/ //y.setString(pc_def); LListST z = y.explode('|','|'); z.dump();
	}

	// adv_f - Final Advice
	// advCnt_f - Final Advice Count
	// pclist - LinkedList of Parsed Pointcuts

	// Parse Out Advice
	int q = 0;
	s = e = 0;
	LListPC advList;
	LListAD adviceTable;
	pcdata tempAdv;
	for(int i=0;i<advCnt_f;i++){
		s = adv_f.findCodeStart(q);
		e = adv_f.findCodeEnd(s);
		string bef_code = adv_f.subStrSect(q,s-1).toString();
		string code = adv_f.grabCode(s).toString();
		q = e+1;
		trim(bef_code);
		trim(code);
		tempAdv.name = bef_code;
		tempAdv.definition = code;
		advList.insert(tempAdv);
		/**** DEBUGGING **/ //cout << bef_code << " *|* " << code << "<==" << endl;
	}
	/**** DEBUGGING **/ //advList.dump();

	for(int i=0;i<advList.countpcnodes();i++){
		aoString cur;
		cur.setString(advList.getByID(i+1).name);
		string advCode = advList.getByID(i+1).definition;
		trim(advCode);
		
		LListST z = cur.explode(':');
		string leftSide = z.getByID(1).str;
		trim(leftSide);
		s = leftSide.find_first_of(" ");
		e = leftSide.find_first_of("(");
		q = leftSide.find_first_of(")");
		//q = leftSide.length();
		string advType = leftSide.substr(s,e-s);
		trim(advType);
		string advParams = leftSide.substr(e+1,q-e-1);
		int advParamCnt = 0;
		if(q == e+1){
			advParamCnt = 0;
		}else{
			aoString y(advParams);
			advParamCnt = y.countOccurence(',')+1;
		}
		/**** DEBUGGING **/ //cout << advType << "|" << advParams << "|" << advParamCnt << endl;
		// Recursivley parse the Pointcuts to remove any named pointcuts and get each indivual PC
		string p = z.getByID(2).str;
		recParse(p);
		for(int j=0;j<finalList.countstnodes();j++){
			p = finalList.getByID(j+1).str;
			/**** DEBUGGING **/ //cout << advType << "|" << advParams << "|" << advParamCnt << "|" << p << endl;
			// Parse Each PC to get Data for advice Table
			aoString y(p);
			z = y.explode('&','&');
			leftSide = z.getByID(1).str;
			trim(leftSide);			e = leftSide.find_first_of("(");
			q = leftSide.find_last_of(")");
			int e2 = leftSide.find_first_of("(",e+1);
			int q2 = leftSide.find_last_of(")",q);
			/**** DEBUGGING **/ //cout << "====" << q2 << "|" << e2 << "====" << endl;
			string jpType = leftSide.substr(0,e);
			trim(jpType);
			string jpSig = leftSide.substr(e+1,q-e-1);
			string jpName = jpSig.substr(0,jpSig.find_first_of("("));
			string jpSigParams = leftSide.substr(e2+1,q2-e2-2);
			int jpSigParamCnt = 0;
			if(q2 == e2+2){
				jpSigParamCnt = 0;
			}else{
				aoString y(jpSigParams);
				jpSigParamCnt = y.countOccurence(',')+1;
			}
			/**** DEBUGGING **/ //cout << endl << jpName << " = " << z.countstnodes() << endl;
			string jpArgs;
			if(z.countstnodes() > 1){
				jpArgs = "";
				/*************************************
				** ARGUMENT PARSING
				*************************************/
				for(int i2 = 2; i2<=z.countstnodes();i2++){
					// For Now, No Arguments Supported. Parse to Format (name,value)(name,value) etc...
					string curArg = z.getByID(i2).str;
					e = curArg.find_first_of("(");
					q = curArg.find_last_of(")");
					string argName = curArg.substr(0,e);
					trim(argName);
					string argValue = curArg.substr(e+1,q-e-1);
					jpArgs += "(" + argName + "," + argValue + ")";
				}
			}else{
				jpArgs = "";
			}
			/**** DEBUGGING **/ //cout << advType << "|" << advParams << "|" << advParamCnt << "|" << jpType << "|" << jpSig << "|" << jpSigParams << "|" << jpSigParamCnt << "|" << jpArgs << "|" << advCode << endl;
			addata temp;
			temp.name = jpName; // Required
			// (1-before,2-around,3-after)
			if(advType.compare("before")==0){
				temp.advType = 1;
			}else if(advType.compare("around")==0){
				temp.advType = 2;
			}else if(advType.compare("after")==0){
				temp.advType = 3;
			}
			temp.advParams = advParams;
			temp.advParamCnt = advParamCnt;
			// (1-exec,2-execr,3-get,4-set)
			if(jpType.compare("exec")==0){
				temp.jpType = 1;
			}else if(jpType.compare("execr")==0){
				temp.jpType = 2;
			}else if(jpType.compare("get")==0){
				temp.jpType = 3;
			}else if(jpType.compare("set")==0){
				temp.jpType = 4;
			}
			temp.jpSig = jpSig;
			temp.jpSigParams = jpSigParams;
			temp.jpSigParamCnt = jpSigParamCnt;
			temp.jpArgs = jpArgs; //CSV Pairs - (Name,"Value String")
			temp.code = advCode;
			adviceTable.insert(temp);
			
		}
		finalList.reset();

	}
	
	// Build Unique List of Functions that have Advice
	LListST funcList;
	for(int i=0;i<adviceTable.countadnodes();i++){
		addata x = adviceTable.getByID(i+1);
		if(funcList.findByName(x.name)==0){
			stdata tmp;
			tmp.str = x.jpSig;
			funcList.insert(tmp);
		}
	}
	cout << "Target Functions: " << endl;
	funcList.dump();

	// Build Advice Pieces
	// Advice pieces get the form of:
	//	function ao_[TYPE_CODE]_[MD5(SIG)]_[FUNC_SIG] { [ADV_CODE] }
	cout << "Generating Advice Pieces..." << endl;
	string advPieces = "";
	for(int i=0;i<funcList.countstnodes();i++){
		string x = funcList.getByID(i+1).str;
		string jpName = x.substr(0,x.find_first_of("("));
		/**** DEBUGGING **/ //cout << "Checking: " << x << endl;
		string hash = MD5String(x.c_str());
		// Check for Before
		if(adviceTable.hasAdviceForType(1,jpName)){
			/**** DEBUGGING **/ //cout << x << " Has Before: " << hash << endl;
			string advCode = adviceTable.getCodeForType(1,jpName);
			string curr = "function ao_bf_"+hash+"_"+x+" { \n"+advCode+" \n} \n\n";
			/**** DEBUGGING **/ //cout << "Function: " << curr << endl;
			advPieces += curr;
		}
		// Check for Around
		if(adviceTable.hasAdviceForType(2,jpName)){
			/**** DEBUGGING **/ //cout << x << " Has Around: " << hash << endl;
			string advCode = adviceTable.getCodeForType(2,jpName);
			aoString ac(advCode);
			if(adviceTable.returns(jpName)){
				// Around w/ Return
				ac.replace("proceed","return "+jpName);
			}else{
				// Around w/out Return
				ac.replace("proceed",jpName);
				int y = ac.findString(0,jpName);
				while(y != -1){
					int p = ac.findString(y,";");
					ac.insert(p+1,"return;");
					y = ac.findString(p,jpName);
				}
			}
			string curr = "function ao_ar_"+hash+"_"+x+" { \n"+ac.toString()+" \n} \n\n";
			/**** DEBUGGING **/ //cout << "Function: " << curr << endl;
			advPieces += curr;
		}
		// Check for After
		if(adviceTable.hasAdviceForType(3,jpName)){
			/**** DEBUGGING **/ //cout << x << " Has After: " << hash << endl;
			string advCode = adviceTable.getCodeForType(3,jpName);
			string curr = "function ao_af_"+hash+"_"+x+" { \n"+advCode+" \n} \n\n";
			/**** DEBUGGING **/ //cout << "Function: " << curr << endl;
			advPieces += curr;
		}
	}
	/**** DEBUGGING **/ //cout << "PIECES: " << advPieces << endl << "================\n";
	
	// Build Final Advice Functions
	//	function ao_[TYPE_CODE]_[MD5(SIG)]_[FUNC_SIG] { [ADV_CODE] }
	// Final Advice Functions get the Form
	//	function ao_fi_[MD5(SIG)]_[FUNC_SIG] { [ADV_CODE] }
	// NOTE: Does not support multiple pieces of same advice type for a single function, ie: cant have 2 before adviced for the same function. Maybe support this in a future version, need to nail proper ordering first (could specifiy with an arg?)
	cout << "Generating Final Advice..." << endl;
	string advFunctions = "";
	for(int i=0;i<funcList.countstnodes();i++){
		string x = funcList.getByID(i+1).str;
		string jpName = x.substr(0,x.find_first_of("("));
		bool r = adviceTable.returns(jpName);
		/**** DEBUGGING **/ //cout << "Checking: " << x << endl;
		string hash = MD5String(x.c_str());
		// Start Function
		string curr = "";
		curr += "function ao_fi_"+hash+"_"+x+" { \n";
		// Check for Before
		if(adviceTable.hasAdviceForType(1,jpName)){
			curr += "ao_bf_"+hash+"_"+x+";";
		}
		// Check for Around
		if(adviceTable.hasAdviceForType(2,jpName)){
			string jpName = x.substr(0,x.find_first_of("("));
			if(r){
				curr += "$temp = ao_ar_"+hash+"_"+x+";";
			}else{
				curr += "ao_ar_"+hash+"_"+x+";";
			}
		}else{
			curr += x+";";
		}
		// Check for After
		if(adviceTable.hasAdviceForType(3,jpName)){
			curr += "ao_af_"+hash+"_"+x+";";
		}
		// Finish Function
		if(r){
			// Returns
			curr += "return $temp; \n";
		}
		curr += " } \n\n";
		advFunctions += curr;
	}
	/**** DEBUGGING **/ //cout << "FINALS: " << advFunctions << endl << "================\n";
	
	// Inject Advice Functions in to PHP
	string phpcode = phpSource.toString();
	for(int i=0;i<funcList.countstnodes();i++){
	
		string x = funcList.getByID(i+1).str;
		string jpName = x.substr(0,x.find_first_of("(")); // Target Function Name
		/**** DEBUGGING **/ //cout << "|" << jpName << "|" << endl;
		string hash = MD5String(x.c_str());
		string func = "ao_fi_"+hash+"_"+jpName; // Replace Function
		
		sregex ws = sregex::compile("[\\s]*"); // Remove Whitespace
    		string format(""); // Empty String Format
    		// Find Function Calls
    		sregex token = sregex::compile("(function[\\s]*[ ]*|[\\s][ ]*|[ ]*)([a-zA-Z0-9_]*)([\\s]*)\\(([a-zA-Z0-9_\"$', .()]*)\\)");
    		// Iterate Through PHP Cpde
    		sregex_iterator cur( phpcode.begin(), phpcode.end(), token );
    		sregex_iterator end;
    		// Iterate
    		LListST matches;
    		for( ; cur != end; ++cur )
    		{
    		    // Get Current Match
        		smatch const &what = *cur;
        		/**** DEBUGGING **/ //cout << "==>: (" << what.position(2) << "," << what.length(2) << ") N-" << what[2] << " | P-" <<  what[4] << " | F-" <<  what[1] << '|';
        		// Remove Whitespace
        		string result2 = regex_replace(what[1].str(),ws,format);
        		// Make sure Not Function Definition & Correct Call
        		if(result2.compare("function")!=0 && what[2].str().compare(jpName)==0){
        			// Matched - Remove/Replace
        			/**** DEBUGGING **/ //cout << " MATCH - " << what[0] << '\n';
        			stdata tmp;
				tmp.str = what[0];
				matches.insert(tmp);
       			}
    		}
    		/**** DEBUGGING **/ //cout << "==DUMP==\n"; matches.dump(); cout << "========\n";
    		for(int k=0;k<matches.countstnodes();k++){
    			string o = matches.getByID(k+1).str;
    			trim(o);
    			/**** DEBUGGING **/ //cout << "before t | o = " << o << "\n";
    			aoString t(o);
    			t.replace(jpName,func);
    			/**** DEBUGGING **/ //cout << "after t replace \n";
    			aoString c(phpcode);
    			c.replace(o,t.toString());
    			/**** DEBUGGING **/ //cout << "after c replace \n";
    			phpcode = c.toString();
    		}
    		matches.reset();
    	}
	
	// Write new PHP
	phpSource.setString(phpcode);
	cout << "Writting Output File..." << endl;
	string advice = advPieces + "\n\n"+ advFunctions +"\n\n";
	phpSource.replace("?>"," ");
	string finalCode = phpSource.toString() + advice + "?>";
	writeOutFile(phpOut,finalCode);
	
	cout << "Weave Done" << endl;
	return COMPLETED;
}
