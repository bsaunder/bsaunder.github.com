/*

Aspect-Oriented PHP (aophp) is an Extension for PHP that allows the user Aspect-Oriented Programming Techniques
Copyright (C) 2006 Bryan Saunders, John Stamey

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

aophp v3.1, Copyright (C) 2006 Bryan Saunders, John Stamey
aophp comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome
to redistribute it under certain conditions.

*/


#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>
#include "aoString.h"
#include "LinkedList_ST.h"
using namespace std;

aoString::aoString(){
	code = "";
}

aoString::aoString(string c){
	code = c;
}

void aoString::setString(string c){
	code = c;
}

string aoString::toString(){
	return code;
}

int aoString::countOccurence(char t){
	int x = 0;
	int s = code.length();
	for(int i=0;i<s;i++){
		if(code.at(i) == t){
			x++;
		}
	}
	return x;
}

int aoString::length(){
	return code.length();
}

aoString aoString::subStrLeng(int s, int l){
	string temp = "";
	temp = code.substr(s,l);
	return temp;
}

aoString aoString::subStrSect(int s, int e){
	int d = e - s;
	string temp = "";
	temp = code.substr(s,d+1);
	return temp;
}

void aoString::remove(int s, int e){
	int d = e - s;
	code.erase(s,d+1);
}

int aoString::indexOf(string w, int s){
	int x = code.find(w,s);
	if(x == string::npos){
	  return -1;
	}
	return x;
}

int aoString::indexOf(char c, int s){
	int x = code.find(c,s);
	if(x == string::npos){
	  return -1;
	}
	return x;
}

int aoString::rindexOf(string w, int s){
        int x = code.rfind(w,s);
	if(x == string::npos){
	  return -1;
	}
	return x;
}

int aoString::rindexOf(char c, int s){
	int x = code.rfind(c,s);
	if(x == string::npos){
	  return -1;
	}
	return x;
}

void aoString::insert(int p,string w){
	code.insert(p,w);
}

void aoString::trimWhiteSpace(){
	// Trim Front Whitespace
	int l = code.length();
	char t;
	for(int s=0;s<l;s++){
		t = code.at(s);
		if(t != ' ' && t != '\t'){
			l = s;
			break;
		}
	}
	code.erase(0,l);

	// Trim Rear Whitespace
	l = code.length();
	int x = 0;
	for(int e=l-1;e>=0;e--){
		t = code.at(e);
		if(t != ' ' && t != '\t'){
			x = e;
			break;
		}
	}
	int d = l-x;
	code.erase(x+1,d);
}

// Remove all of the Comments from the Given PHP Code String
//
// *NOTE*: Could Be Done with Regular Expressions as Well.
//		Regular Expressions would Probably be Quicker/More Precise
//
void aoString::stripComments(){
	string input = code;
	string output = "";
	int status = 0;
	bool inString = false;
	// Strip All Comments
	// 0 - Not In Comment
	// 1 - Full Line Comment
	// 2 - Block Type Comment
	char t;
	for(int i=0;i<input.length();i++){
		t = input.at(i);
		if(t == '"'){
			inString = !inString;
		}
		if(inString && status == 0){
			output += t;
		}else{
			if(status == 0){
				if(t == '/'){
					if(input.at(i+1) == '/'){
						status = 1;
					}else if(input.at(i+1) == '*'){
						status = 2;
					}else{
						output += t;
					}
				}else{
					output += t;
				}
			}else if(status == 1){
				if(t == '\n'){
					status = 0;
				}
			}else if(status == 2){
				if(t == '*' && input.at(i+1) == '/'){
					status = 0;
					i++;
				}
			}
		}
	}
	code = output;
}

void aoString::inject(string search, string replace){
	int l = search.length();
	int r = replace.length() + l + 1;
	
	int x = findStringInject(0,search);
	int f = findStringInject(0,"function");
	int p = findStringInject(f,"{");
	
	while(x != -1){
		
			if(f < x && x < p){
				// Function Definition... Ignore!!
				p = findCodeEnd(p);
				x = findStringInject(p,search);
				f = findStringInject(p,"function");
				p = findStringInject(f,"{");
			}else{
				code.erase(x,l);
				code.insert(x,replace);
				x = findStringInject(x+r,search);
			}
		
	}
}

int aoString::findStringInject(int s, string substring){
  bool found = false;
  bool inString = false;
  
  //substring = substring + "(";

  //int l = code.length();
  int sl = substring.length();
  int r = -1;

  char c = substring.at(0);
  char z;
  char t;

  for(int i=s;i<code.length();i++){
    t = code.at(i);
    if(t == '\\'){
      i++;
      continue;
    }else if(t == '"'){
      inString = !inString;
    }else if(t == '\''){
      i+=2;
    }else{
      if(inString){
        continue;
      }else{
        if(t == c){
	  //Found, Lookahead
	  //cout << "CC: " << t << endl;
	  r = i;
	  found = true;
	  for(int k=0;k<sl;k++){
	    z = substring.at(k);
	    //cout << "IC: " << k << "-" << z << endl;
	    if(z == code.at(i+k)){
	      found = true;
	    }else{
	      found = false;
	      break;
	    }
	  }
	  if(found){
	    //cout << "FOUND" << endl;
	    return r;
	    //cout << "AFR" << endl;
	  }else{
	    r = -1;
	  }
	}
      }
    }
  }
return r;
}

void aoString::replace(string search, string replace){
	int l = search.length();
	int x = findString(0,search);
	int r = replace.length() + l + 1;
	//int q = code.length();
	while(x != -1 && x<code.length()){
		code.erase(x,l);
		code.insert(x,replace);
		//cout << "REP_LOOP 1: " << x << endl;
		x = findString(x+r,search);
		//cout << "REP_LOOP 2: " << x << endl;
	}
}

int aoString::findString(int s, string substring){
  bool found = false;
  bool inString = false;

  //int l = code.length();
  int sl = substring.length();
  int r = -1;

  char c = substring.at(0);
  char z;
  char t;

  for(int i=s;i<code.length();i++){
    t = code.at(i);
    if(t == '\\'){
      i++;
      continue;
    }else if(t == '"'){
      inString = !inString;
    }else if(t == '\''){
      i+=2;
    }else{
      if(inString){
        continue;
      }else{
        if(t == c){
	  //Found, Lookahead
	  //cout << "CC: " << t << endl;
	  r = i;
	  found = true;
	  for(int k=0;k<sl;k++){
	    z = substring.at(k);
	    //cout << "IC: " << k << "-" << z << endl;
	    if(z == code.at(i+k)){
	      found = true;
	    }else{
	      found = false;
	      break;
	    }
	  }
	  if(found){
	    //cout << "FOUND" << endl;
	    return r;
	    //cout << "AFR" << endl;
	  }else{
	    r = -1;
	  }
	}
      }
    }
  }
return r;
}

int aoString::countOccurence(int s, string substring){
  bool found = false;
  bool inString = false;

  int l = code.length();
  int sl = substring.length();
  int r = -1;
  
  int cnt = 0;

  char c = substring.at(0);
  char z;
  char t;

  for(int i=0;i<l;i++){
    t = code.at(i);
    if(t == '\\'){
      i++;
      continue;
    }else if(t == '"'){
      inString = !inString;
    }else if(t == '\''){
      i+=2;
    }else{
      if(inString){
        continue;
      }else{
        if(t == c){
	  //Found, Lookahead
	  r = i;
	  found = true;
	  for(int k=0;k<sl;k++){
	    z = substring.at(k);
	    if(z == code.at(i+k)){
	      found = true;
	    }else{
	      found = false;
	      break;
	    }
	  }
	  if(found){
	    cnt++;
	  }else{
	    r = -1;
	  }
	}
      }
    }
  }
return cnt;
}


int aoString::findCodeStart(int s){
	int l = code.length();
	bool inString = false;
	char t;
	for(int i=s;i<l;i++){
		t = code.at(i);
		switch(t){
		        case '\\':
                                i++;
                                continue;
                                break;
		        case '"':
				inString = !inString;
				break;
			case '{':
				if(!inString){
					return i;
				}//else Ignore It
				break;
			default:
				break;
		}
	}
	return string::npos; // Not Found
}

int aoString::findCodeEnd(int s){
	int l = code.length();
	bool inString = false;
	int cnt = 1;
	char t;
	for(int i=s+1;i<l;i++){
		t = code.at(i);
		switch(t){
			case '"':
				inString = !inString;
				break;
			case '{':
				if(!inString){
					cnt++;
				}//else Ignore It
				break;
			case '}':
				if(!inString){
					cnt--;
					if(cnt == 0){
						return i;
					}
				}//else Ignore It
				break;
			default:
				break;
		}
	}
	return string::npos; // Not Found
}

aoString aoString::grabCode(int s){
	this->stripComments();
	int x = this->findCodeStart(s);
	int y = this->findCodeEnd(x);
	return this->subStrSect(x+1,y-1);

}

LListST aoString::explode(char expVar){
	//cout << "START EXPLODE" << endl;
	LListST t;
	string x = code;
	//string temp = "";
	bool inString = false;
	bool ignore = false;
	int ignCnt = 0;
	stdata temp;
	temp.str = "";
	for(int i=0;i<x.length();i++){
		char c = x.at(i);
		if(ignore){
			ignCnt--;
			if(ignCnt == 0) ignore = false;
		}else{
			switch(c){
			case '"':
				inString = !inString;
				break;
			case '\'':
				ignore = true;
				ignCnt= 2;
				break;
			case '\\':
				ignore = true;
				ignCnt = 1;
				break;
			default:
				if(!inString){
					if(c == expVar){
						aoString y(temp.str);
						y.trimWhiteSpace();
						temp.str = y.toString();
						t.insert(temp);
						temp.str = "";
						continue;
					}
				}
				break;
			}
		}
		temp.str += c;
	}
	if(temp.str != ""){
		aoString y(temp.str);
		y.trimWhiteSpace();
		temp.str = y.toString();
		t.insert(temp);
	}
	//for(int i=0;i<temp.str.length();i++){
	//	char x = temp.str.at(i);
	//	int q = (int)x;
	//	cout << x << "|";
	//}
	//cout << "\n******|" << temp.str << "|*****" << endl;
	//cout << "END EXPLODE" << endl;
	return t;
}

LListST aoString::explode(char expVar, char expVar2){
	//cout << "START EXPLODE" << endl;
	LListST t;
	string x = code;
	//string temp = "";
	bool inString = false;
	bool ignore = false;
	int ignCnt = 0;
	stdata temp;
	temp.str = "";
	for(int i=0;i<x.length();i++){
		char c = x.at(i);
		if(ignore){
			ignCnt--;
			if(ignCnt == 0) ignore = false;
		}else{
			switch(c){
			case '"':
				inString = !inString;
				break;
			case '\'':
				ignore = true;
				ignCnt= 2;
				break;
			case '\\':
				ignore = true;
				ignCnt = 1;
				break;
			default:
				if(!inString){
					if(c == expVar && x.at(i+1) == expVar2){
						aoString y(temp.str);
						y.trimWhiteSpace();
						temp.str = y.toString();
						t.insert(temp);
						temp.str = "";
						i++;
						continue;
					}
				}
				break;
			}
		}
		temp.str += c;
	}
	if(temp.str != ""){
		aoString y(temp.str);
		y.trimWhiteSpace();
		temp.str = y.toString();
		t.insert(temp);
	}
	//for(int i=0;i<temp.str.length();i++){
	//	char x = temp.str.at(i);
	//	int q = (int)x;
	//	cout << x << "|";
	//}
	//cout << "\n******|" << temp.str << "|*****" << endl;
	//cout << "END EXPLODE" << endl;
	return t;
}

// String Trimmer
void aoString::trim()
{
	string str = code;
	string::size_type pos1 = str.find_first_not_of(" \t\r\n");
	string::size_type pos2 = str.find_last_not_of(" \t\r\n");
	str = str.substr(pos1 == string::npos ? 0 : pos1, 
		pos2 == string::npos ? str.length() - 1 : pos2 - pos1 + 1);

	code = str;
}

