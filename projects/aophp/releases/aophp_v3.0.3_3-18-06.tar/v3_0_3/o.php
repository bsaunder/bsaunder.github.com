<?
echo "//Comment";


function say($s){
	echo "Gonna $s";
	$p = 0;

	say($s);
}

function other_say($s){
	echo "Other Say";
}

function othersay($s){
	echo "Other Say";
}

function sayother($s){
	echo "Other Say";
}

function say_other($s){
	echo "Other Say";
}

$x1 = 0;
$x2 = 4;
$y = $x1+$x2;
ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($y);







ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say("CCU");

 

function ao_bf_6786e1d58be7e6bdb07a53555b63d6c1_say($s) { 
echo "BEFORE I SAY: $s <br><br>"; 
} 



function ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s) { 
ao_bf_6786e1d58be7e6bdb07a53555b63d6c1_say($s);say($s); } 



?>