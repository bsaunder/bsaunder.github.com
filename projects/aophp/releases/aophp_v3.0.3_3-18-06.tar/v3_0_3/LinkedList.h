
#ifndef LINKED_LIST
#define LINKED_LIST
#include <iostream>
#include <string>
using namespace std;

struct data{
	int id; // Required
	string name; // Required
	// Other Data
};

struct node{
	data info;
	node *next;
};

class LList{
	private:
		node *front;
		node *rear;
		int count;
	public:
		LList();
		LList(const LList &);
		LList & operator = (const LList &);
		void insert(data);
		int findByName(string);
		data getFirst();
		data getLast();
		data getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dump() const;
		int countNodes();
		void reset();
		~LList();
};

#endif

