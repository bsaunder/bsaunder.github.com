
#ifndef LINKED_LIST_AS
#define LINKED_LIST_AS
#include <iostream>
#include <string>
using namespace std;

struct asdata{
	int id; // Required
	string name; // Required
	string code;
};

struct asnode{
	asdata info;
	asnode *next;
};

class LListAS{
	private:
		asnode *front;
		asnode *rear;
		int count;
	public:
		LListAS();
		LListAS(const LListAS &);
		LListAS & operator = (const LListAS &);
		void insert(asdata);
		int findByName(string);
		asdata getFirst();
		asdata getLast();
		asdata getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dump() const;
		int countasnodes();
		void reset();
		~LListAS();
};

#endif

