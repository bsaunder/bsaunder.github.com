<?
// Comment 1
echo "//Comment";
aophp_init("file3.aophp");

function say($s){
	echo "Gonna $s";
	$p = 0;

	say($s);
}

// This works fine
function other_say($s){
	echo "Other Say";
}

// This works fine
function othersay($s){
	echo "Other Say";
}

// This works fine
function sayother($s){
	echo "Other Say";
}

// This works fine
function say_other($s){
	echo "Other Say";
}

$x1 = 0;
$x2 = 4;
$y = $x1+$x2;
say($y);

// This gets caught as the "say" function
//sayother("blah");

// This gets caught as the "say" function
//other_say("blah");

// This gets caught as the "say" function
//say_other("blah");

// This gets caught as the "say" function
//othersay("blah");

/* Comment 2
New Line */

say("CCU");

/// This gets caught as the "say" function
//other_say("blah");
?>
