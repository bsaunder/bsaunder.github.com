/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Tokenizer Class
Implemented as a Dynamic Queue

*/

#include <iostream>
#include <string>
#include "StringTok.h"
using namespace std;

StringTok::StringTok(aoString in, string d){
	front = NULL;
	rear = NULL;
	orig = in;
	delim = d;
}

StringTok::StringTok(string in, string d){
	front = NULL;
	rear = NULL;
	orig = in;
	delim = d;
}

StringTok::StringTok(const StringTok & original){
	token *temp; // Used to Create the Nodes
	token *current; // The Node were Currently on
	token *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new token;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new token;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

StringTok & StringTok::operator = (const StringTok & original){
	token *temp; // Used to Create the Nodes
	token *current; // The Node were Currently on
	token *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new token;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new token;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

void StringTok::tokenize(){
	string in = orig.toString();
	int curPos = -1;
	string tmp = "";
	/**** DEBUGGING **/ //cout << "STRTOK: " << in << endl;
	curPos = in.find(delim);
	/**** DEBUGGING **/ //cout << curPos << "\n";
	while(curPos > 0){
		tmp = in.substr(0,curPos);
		this->insertToken(tmp);
		in.erase(0,curPos+1);
		tmp = "";
		curPos = in.find(delim);
	}
	this->insertToken(in);
}

void StringTok::insertToken(aoString item){
	token *temp = new token;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

aoString StringTok::getRemaining() const{
	token *temp = new token;
	temp = front;
	aoString line;
	while(temp != NULL){
		line += temp->info;
		temp = temp->next;
		if(temp != NULL){
			line += delim;
		}
	}
	//aoString r;
	//r.setString(line);
	return line;
}

void StringTok::dumpTokens() const{
	token *temp = new token;
	temp = front;
	while(temp != NULL){
		cout << "--> "<< temp->info << endl;
		temp = temp->next;
	}
}

int StringTok::countTokens() const{
	token *temp = new token;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	return x;
}

aoString StringTok::getNext(){
	aoString item;
	token *temp = front;
	item = front->info;
	front = front->next;
	delete temp;
	return item;
}

aoString StringTok::getOrig(){
	return orig;
}

bool StringTok::isEmpty() const{
	return (front == NULL);
}

bool StringTok::hasNext() const{
	return !isEmpty();
}

void StringTok::reset(aoString text,string d){
	aoString item;
	while(!isEmpty()){
		item = getNext();
	}
	orig = text;
	delim = d;
}

void StringTok::reset(string text,string d){
	aoString item;
	while(!isEmpty()){
		item = getNext();
	}
	orig = text;
	delim = d;
}

StringTok::~StringTok(){
	aoString item;
	while(!isEmpty()){
		item = getNext();
	}
}
