<?
echo "//Comment";


function ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s){
	echo "Gonna $s";
	$p = 0;

	ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s);
}

function add($x,$y){
	return $x + $y;
}

function other_ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s){
	echo "Other Say";
}

function otherao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s){
	echo "Other Say";
}

function sayother($s){
	echo "Other Say";
}

function say_other($s){
	echo "Other Say";
}



$x1 = 0;
$x2 = 4;
$y = $x1+$x2;
ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($y);

sayother("blah");

other_say("blah");

say_other("blah");

othersay("blah");



ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say("CCU");

$z = ao_fi_0c52bab0471ce3d2cc8ed420655ea50f_add(2,2);
$q = ao_fi_0c52bab0471ce3d2cc8ed420655ea50f_add(3,5);
other_say("blah");
 

function ao_bf_6786e1d58be7e6bdb07a53555b63d6c1_say($s) { 
echo "BEFORE I SAY: $s <br><br>"; 
} 

function ao_ar_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y) { 
if($x == 2){
			return add($x,$y);
		}else{
			return add(4,5);
		}
		return 6; 
} 



function ao_fi_6786e1d58be7e6bdb07a53555b63d6c1_say($s) { 
ao_bf_6786e1d58be7e6bdb07a53555b63d6c1_say($s);say($s); } 

function ao_fi_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y) { 
$temp = ao_ar_0c52bab0471ce3d2cc8ed420655ea50f_add($x,$y);return $temp; 
 } 



?>