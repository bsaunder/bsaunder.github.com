/*

Developed & Released under the
	aoPHP v3.0 GNU Public License
Coded by Bryan Saunders

String Tokenizer Class
Implemented as a Dynamic Queue

*/

#ifndef STRINGTOK
#define STRINGTOK
#include <iostream>
#include <string>
#include "aoString.h"
using namespace std;

struct token{
	aoString info;
	token *next;
};

class StringTok{
	private:
		token *front;
		token *rear;
		aoString orig;
		string delim;
	public:
		StringTok(aoString,string);
		StringTok(string,string);
		StringTok(const StringTok &);
		StringTok & operator = (const StringTok &);
		void tokenize();
		void insertToken(aoString);
		aoString getNext();
		bool hasNext() const;
		bool isEmpty() const;
		aoString getRemaining() const;
		void dumpTokens() const;
		int countTokens() const;
		aoString getOrig();
		void reset(aoString,string);
		void reset(string,string);
		~StringTok();
};

#endif

