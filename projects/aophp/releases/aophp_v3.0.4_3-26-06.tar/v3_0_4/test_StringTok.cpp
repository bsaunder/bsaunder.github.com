#include <iostream>
#include <string>
#include "StringTok.h"
using namespace std;

int main(){
	aoString s1,s2,s3;
	s1 = "A,B,C,D";
	s3 = "1!2!3!4!5";
	StringTok st1(s1,",");
	st1.tokenize();
	cout << "Count: " << st1.countTokens() << endl;
	int c = st1.countTokens();
	for(int i=0;i<c-2;i++){
		s2 = st1.getNext();
		cout << s2 << endl;
	}
	cout << st1.getRemaining() << endl;

	st1.reset(s3,"!");
	st1.tokenize();
	cout << "Count: " << st1.countTokens() << endl;
	c = st1.countTokens();
	for(int k=0;k<c-2;k++){
		s2 = st1.getNext();
		cout << s2 << endl;
	}
	cout << st1.getRemaining() << endl;

	return 0;
}

