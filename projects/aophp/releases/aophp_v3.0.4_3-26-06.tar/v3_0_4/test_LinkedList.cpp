#include <iostream>
#include <string>
#include "LinkedList.h"
using namespace std;

int main(){

	LList l;

	data a,b,c,d,e;
	a.id = 1;
	a.name = "A";
	b.id = 3;
	b.name = "B";
	c.id = 5;
	c.name = "C";
	d.id = 7;
	d.name = "D";
	e.id = 9;
	e.name = "E";

	l.insert(a);
	l.insert(c);
	cout << "Dumping A/C" << endl;

	cout << "ID of C: " << l.findByName("C") << endl;

	l.insert(b);
	l.dump();
	cout << "Count: " << l.countNodes() << endl;

	cout << l.getFirst().name << endl;
	cout << l.getLast().name << endl;
	cout << "------" << endl;
	string h = l.getByID(3).name;
	cout << "------" << endl << h << endl;

	cout << l.hasNext() << endl;

	l.reset();
	cout << "--" << endl;
	l.dump();
	cout << "--" << endl;
	l.insert(d);
	l.insert(e);
	l.dump();



	return 0;
}

