#include <iostream>
#include <string>
#include "LinkedList_AS.h"
using namespace std;

LListAS::LListAS(){
	front = NULL;
	rear = NULL;
	count = 0;
}

LListAS::LListAS(const LListAS & original){
	asnode *temp; // Used to Create the asnodes
	asnode *current; // The asnode were Currently on
	asnode *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new asnode;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new asnode;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

LListAS & LListAS::operator = (const LListAS & original){
	asnode *temp; // Used to Create the asnodes
	asnode *current; // The asnode were Currently on
	asnode *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new asnode;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new asnode;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

LListAS::~LListAS(){
	reset();
}

void LListAS::reset(){
	while(!isEmpty()){
		asnode *temp = front;
		front = front->next;
		delete temp;
	}
}

asdata LListAS::getFirst(){
	return front->info;
}

asdata LListAS::getLast(){
	return rear->info;
}

asdata LListAS::getByID(int x){
	asnode *temp = new asnode;
	temp = front;
	while(temp != NULL){
	  //cout << temp->info.name << endl;
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void LListAS::insert(asdata item){
	asnode *temp = new asnode;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int LListAS::countasnodes(){
	asnode *temp = new asnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int LListAS::findByName(string name){
	asnode *temp = new asnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(name) == 0){
			return temp->info.id;
		}
		temp = temp->next;
	}
	count = x;
	return 0;
}

bool LListAS::isEmpty() const{
	return (front == NULL);
}

bool LListAS::hasNext() const{
	return !isEmpty();
}

void LListAS::dump() const{
	asnode *temp = new asnode;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.name << endl;
		temp = temp->next;
	}
}

