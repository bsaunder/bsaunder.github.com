#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>
#include "StringTok.h"
#include "LinkedList_PC.h"
#include "LinkedList_AD.h"
#include "LinkedList_AS.h"
#include "LinkedList_ST.h"

// Aspect Structure - Composed of Advice and Pointcuts
struct Aspect{
  aoString name;
  aoString code;
};

// File Writer
void writeOutFile(string oFile, string content){
  ofstream outFile;
  outFile.open(oFile.c_str(),ios::out);
  outFile << content;
  outFile.close();
}

// String Trimmer
void trim(string& str)
{
	string::size_type pos1 = str.find_first_not_of(" \t\r\n");
	string::size_type pos2 = str.find_last_not_of(" \t\r\n");
	str = str.substr(pos1 == string::npos ? 0 : pos1, 
		pos2 == string::npos ? str.length() - 1 : pos2 - pos1 + 1);
}

using namespace std;

/*** Setup Variables ***/
const int MAX_CHARS_LINE = 500;
const int ARG_CNT = 2;

/*** Status Codes ***/
const int COMPLETED = 0;
const int DECLINED = 1;
const int SRC_FILE_ERROR = 2;
const int INV_ASPECT_FILE = 3;
const int INV_ASPECT_ARGS = 4;
const int ASPECT_FILE_ERROR = 5;
const int WRONG_ARG_CNT = 99;
const int INVALID_PC_DEC = 6;

int main(int argc, char* argv[]){

	int INC_STATUS = 0; // Off by Default
	int INC_DEPTH = 1; // 1 Level by Default

	string phpIn,phpOut;
	aoString phpSource;

	// Command Line Arguments
	// Only 1-4 Passed at Command Line
	// 0 - Relative Path to Executable from Working Directory
	// 1 - PHP In File
	// 2 - PHP Out File
	// 3 - Include Status -> 0 On, 1 Off
	// 4 - Include Level -> 0 is Infinite

	// Check for Arguments
	if(argc <= ARG_CNT){
		cerr << "ERR: Wrong Argument Count\n";
		return WRONG_ARG_CNT;
	}

	// Parse Aguments
	string argtemp = "";
	cout << "Arg. Count: " << argc << endl << "Arguments: " << endl;
	for(int i=0;i<argc;i++){
		argtemp = argv[i];
		if(argtemp.compare("-s")==0){
			i++;
			//argtemp = argv[i];
			INC_STATUS = atoi(argv[i]);
		}else if(argtemp.compare("-d")==0){
			i++;
			//argtemp = argv[i];
			INC_DEPTH = atoi(argv[i]);
		}else{
			if(i==1){
				phpIn = argtemp;
			}else if(i==2){
				phpOut = argtemp;
			}
		}
	}
	cout << "In File: " << phpIn << endl;
	cout << "Out File: " << phpOut << endl;
	cout << "Inc. Status: " << INC_STATUS << endl;
	cout << "Inc. Depth: " << INC_DEPTH << endl;

	// Open PHP Source Input File
	ifstream inFile;
	inFile.open(phpIn.c_str(),ios::in);
	if(!inFile){
		cerr << "ERR: Could Not Source Open File\n";
		return SRC_FILE_ERROR;
	}else{
		cout << "Opened Source File\n";
	}

	// Parse PHP Source File to String
	string tmpStr;
	while(!inFile.eof()){
		getline(inFile,tmpStr);
		phpSource += tmpStr + "\n";
	}
	inFile.close();
	phpSource.stripComments();
	/**** DEBUGGING **/ //cout << endl << phpSource << endl;
	cout << "PHP Source Parsed\n";

	// Find aoPHP Files
	string *aopFileList;
	int aopFileCount = 0;
	int s = phpSource.indexOf("aophp_init",0);
	if(s == -1){
		// aoPHP Init Not Found. Write File & End
		cout << "No Weave Needed" << endl;
		writeOutFile(phpOut,phpSource.toString());
		return COMPLETED;
	}
	int s2 = phpSource.indexOf('(',s);
	int e = phpSource.indexOf(')',s2);
	aoString f = phpSource.subStrSect(s2+2,e-2);
	int fCnt = f.countOccurence(',')+1;
	/**** DEBUGGING **/ //cout << "File List(" << fCnt << "): " << f << endl;

	// Put Files into String Array
	string *inFileArray;
	inFileArray = new string[fCnt];
	StringTok t(f,",");
	t.tokenize();
	aoString tmpAostr;
	for(int i=0; i<fCnt; i++){
		tmpAostr = t.getNext();
		inFileArray[i] = tmpAostr.toString();
	}

	// Open and Read Files
	aoString aopSource;
	for(int i=0; i<fCnt; i++){
		ifstream inFile;
		int k = inFileArray[i].find(".aophp");
		if(k < 0){
			cout << "ERR: Invalid Aspect File Type Found: " << inFileArray[i] << "\n";
			continue;
		}
		inFile.open(inFileArray[i].c_str(),ios::in);
		if(!inFile){
			cerr << "ERR: Could Not Open Aspect File: " << inFileArray[i] << "\n";
			continue;
		}else{
			cout << "Opened Aspect File: " << inFileArray[i] << "\n";
			tmpStr = "";
			while(!inFile.eof()){
				getline(inFile,tmpStr);
				aopSource += tmpStr + "\n";
			}
			inFile.close();
		}
	}
	/**** DEBUGGING **/ //cout << endl << aopSource << endl;

	// Erase aoPHP Init Call from PHP Source
	e = phpSource.indexOf(';',e);
	phpSource.remove(s,e);
	/**** DEBUGGING **/ //cout << endl << phpSource << endl;
	
	// Create Aspect Linked List
	LListAS aspects; 
	asdata tempAsp;

	// Find Indivual Aspects & Store / Get Aspect Count
	s = 0;
	e = 0;
	int cd_s = 0; // Code Start
	int cd_e = 0; // Code End
	s = aopSource.indexOf("aspect",0);
	aoString curAspectCode;
	int aspCnt = 0;
	while(s != -1){
	  cd_s = aopSource.findCodeStart(s+6);
	  aoString aspName = aopSource.subStrSect(s+6,cd_s-1);
	  aspName.trimWhiteSpace();
	  /**** DEBUGGING **/ //cout << "Aspect Name: " << aspName << "\n";
	  cd_e = aopSource.findCodeEnd(cd_s);
	  s = aopSource.indexOf("aspect",cd_e);
	  curAspectCode = aopSource.subStrSect(cd_s,cd_e-1);
	  /**** DEBUGGING **/ //cout << curAspectCode << "\n" << cd_s << " - " << cd_e << "\n";
	  aspCnt++;
	  tempAsp.id = aspCnt;
	  tempAsp.name = aspName.toString();
	  tempAsp.code = curAspectCode.toString();
	  aspects.insert(tempAsp);
        }
	cout << aspects.countasnodes() << " Asepcts Found" << endl;
	
	/**** DEBUGGING **/
	//cout << "----- LIST DUMP -----\n";
	//aspects.dump();
	//cout << "---------------------\n";
	/**** DEBUGGING **/       

	// Breakdown Aspects
	int l = 0;
	s = 0;
	e = 0;
	cd_s = 0;
	cd_e = 0;
	aoString pcs, adv;
	aoString pcs_f, adv_f;
	int pcsCnt_f, advCnt_f;
	for(int i=0;i<aspects.countasnodes();i++){
	  tempAsp = aspects.getByID(i+1);
	  /**** DEBUGGING **/ //cout << tempAsp.name << "\n";
	  curAspectCode.setString(tempAsp.code);
	  // Get Pointcut Block
	  s = curAspectCode.findString(0,"vars:")+5;
	  e = curAspectCode.findString(s+1,"data:")-1;
	  pcs = curAspectCode.subStrSect(s,e);
	  //pcs.trimWhiteSpace();
	  /**** DEBUGGING **/ //cout << "PCS: " << pcs << endl;
	  l = curAspectCode.length();
	  s = e+5;
	  e = l;
	  //adv.trimWhiteSpace();
	  adv = curAspectCode.subStrSect(s+1,e);
	  /**** DEBUGGING **/ //cout << "ADV: " << adv << endl;

	  // Count Number of Pointcuts and Advice
	  int pcsCnt = pcs.countOccurence(0,";");
	  int advCnt = adv.countOccurence(0,"advice");
	  /**** DEBUGGING **/ //cout << "#PCS: " << pcsCnt << " | #ADV: " << advCnt << endl;

	  pcsCnt_f += pcsCnt;
	  advCnt_f += advCnt;
	  pcs_f += pcs;
	  adv_f += adv;

	}

	cout << pcsCnt_f << " Pointcuts Found" << endl;
	cout << advCnt_f << " Advice Found" << endl;

	/**** DEBUGGING **/ //cout << "ADV: " << adv_f << endl;
	/**** DEBUGGING **/ //cout << "PCS: " << pcs_f << endl;
	/**** DEBUGGING **/ //cout << "#PCS: " << pcsCnt_f << " | #ADV: " << advCnt_f << endl;

	// Parse Pointuts to LinkedList
	LListPC pclist;
	LListST stlist;
	pcs_f.trim();
	adv_f.trim();
	stlist = pcs_f.explode(';');
	/**** DEBUGGING **/ //cout << "PCS Dump:\n"; stlist.dump();
	pcdata tempPC;
	for(int i=0;i<stlist.countstnodes();i++){
		string x = stlist.getByID(i+1).str;
		aoString y(x);
		y.trim();
		LListST temp = y.explode('=');
		/**** DEBUGGING **/ //cout << "TEMP Dump:\n"; temp.dump();
		string pc_name = temp.getByID(1).str;
		string pc_def = temp.getByID(2).str;
		int s = pc_name.rfind(" ",pc_name.length());
		if(s == string::npos){
			cerr << "ERR: Invalid Poincut Decleration - " << pc_name << "\n";
			return INVALID_PC_DEC;
		}
		pc_name = pc_name.substr(s);
		trim(pc_name);
		trim(pc_def);
		tempPC.definition = pc_def;
		tempPC.name = pc_name;
		pclist.insert(tempPC);
		/**** DEBUGGING **/ //cout << "Pointcut:" << pc_name << " *|* " << pc_def << endl;
		/**** DEBUGGING **/ //y.setString(pc_def); LListST z = y.explode('|','|'); z.dump();
	}

	// adv_f - Final Advice
	// advCnt_f - Final Advice Count
	// pclist - LinkedList of Parsed Pointcuts

	// Parse Out Advice
	int q = 0;
	s = e = 0;
	LListPC advList;
	pcdata tempAdv;
	for(int i=0;i<advCnt_f;i++){
		s = adv_f.findCodeStart(q);
		e = adv_f.findCodeEnd(s);
		string bef_code = adv_f.subStrSect(q,s-1).toString();
		string code = adv_f.grabCode(s).toString();
		q = e+1;
		trim(bef_code);
		trim(code);
		tempAdv.name = bef_code;
		tempAdv.definition = code;
		advList.insert(tempAdv);
		/**** DEBUGGING **/ //cout << bef_code << " *|* " << code << "<==" << endl;
	}
	/**** DEBUGGING **/ //advList.dump();

	for(int i=0;i<advList.countpcnodes();i++){
		aoString cur;
		cur.setString(advList.getByID(i+1).name);
		string advCode = advList.getByID(i+1).definition;
		trim(advCode);
		
		LListST z = cur.explode(':');
		string leftSide = z.getByID(1).str;
		trim(leftSide);
		s = leftSide.find_first_of(" ");
		e = leftSide.find_first_of("(");
		q = leftSide.find_first_of(")");
		//q = leftSide.length();
		string advType = leftSide.substr(s,e-s);
		trim(advType);
		string advParams = leftSide.substr(e+1,q-e-1);
		int advParamCnt = 0;
		if(q == e+1){
			advParamCnt = 0;
		}else{
			aoString y(advParams);
			advParamCnt = y.countOccurence(',');
		}
		/**** DEBUGGING **/ //cout << advType << "|" << advParams << "|" << advParamCnt << endl;

		aoString rightSide;
		rightSide.setString(z.getByID(2).str);
		z = rightSide.explode('|','|');
		/**** DEBUGGING **/ cout << "I:" << i << "|" << rightSide << "|" << advCode; z.dump();
		for(int i=0;i<z.countstnodes();i++){
			string p = z.getByID(i+1).str;
			trim(p); 
			int o = pclist.findByName(p);
			/**** DEBUGGING **/ cout << "BEFORE: " << p << "=" << o << endl;
			if(o >= 1){
				p = pclist.getByID(o).definition;
			}
			/**** DEBUGGING **/ cout << "AFTER: " << p << endl;
			/**** DEBUGGING **/ //cout << advType << "|" << advParams << "|" << advParamCnt << "|" << p << endl;
		}
	}


	cout << "Weave Done" << endl;
	return COMPLETED;
}
