
#ifndef LINKED_LIST_ST
#define LINKED_LIST_ST
#include <iostream>
#include <string>
using namespace std;

struct stdata{
	int id; // Required
	string str; // Required
};

struct stnode{
	stdata info;
	stnode *next;
};

class LListST{
	private:
		stnode *front;
		stnode *rear;
		int count;
	public:
		LListST();
		LListST(const LListST &);
		LListST & operator = (const LListST &);
		void insert(stdata);
		//int findByName(string);
		stdata getFirst();
		stdata getLast();
		stdata getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dump() const;
		int countstnodes();
		void reset();
		~LListST();
};

#endif

