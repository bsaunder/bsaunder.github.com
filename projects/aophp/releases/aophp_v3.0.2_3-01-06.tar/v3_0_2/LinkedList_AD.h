
#ifndef LINKED_LIST_AD
#define LINKED_LIST_AD
#include <iostream>
#include <string>
using namespace std;

struct addata{
	int id; // Required
	string name; // Required
	int advType; // (1-before,2-around,3-after)
	string advParams;
	int advParamCnt;
	int jpType; // (1-exec,2-execr,3-get,4-set)
	string jpSig;
	string jpSigParams;
	int jpSigParamCnt;
	string jpArgs; //CSV - Name,"Value String"
	string code;
};

struct adnode{
	addata info;
	adnode *next;
};

class LListAD{
	private:
		adnode *front;
		adnode *rear;
		int count;
	public:
		LListAD();
		LListAD(const LListAD &);
		LListAD & operator = (const LListAD &);
		void insert(addata);
		int findByName(string);
		addata getFirst();
		addata getLast();
		addata getByID(int);
		bool hasNext() const;
		bool isEmpty() const;
		void dump() const;
		int countadnodes();
		void reset();
		~LListAD();
};

#endif

