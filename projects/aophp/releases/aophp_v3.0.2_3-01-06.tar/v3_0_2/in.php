<?
// Comment 1
aophp_init("file1.aophp,file2.aophp");
echo "//Comment";
$x1 = 0;
$x2 = 4;
$y = $x1+$x2;
/* Comment 2
New Line */
?>