#include <iostream>
#include <string>
#include "LinkedList_AD.h"
using namespace std;

LListAD::LListAD(){
	front = NULL;
	rear = NULL;
	count = 0;
}

LListAD::LListAD(const LListAD & original){
	adnode *temp; // Used to Create the adnodes
	adnode *current; // The adnode were Currently on
	adnode *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new adnode;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new adnode;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

LListAD & LListAD::operator = (const LListAD & original){
	adnode *temp; // Used to Create the adnodes
	adnode *current; // The adnode were Currently on
	adnode *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new adnode;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new adnode;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

LListAD::~LListAD(){
	reset();
}

void LListAD::reset(){
	while(!isEmpty()){
		adnode *temp = front;
		front = front->next;
		delete temp;
	}
}

addata LListAD::getFirst(){
	return front->info;
}

addata LListAD::getLast(){
	return rear->info;
}

addata LListAD::getByID(int x){
	adnode *temp = front;
	while(temp != NULL){
	  //cout << temp->info.name << endl;
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void LListAD::insert(addata item){
	adnode *temp = new adnode;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int LListAD::countadnodes(){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

int LListAD::findByName(string name){
	adnode *temp = new adnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(name) == 0){
			return temp->info.id;
		}
		temp = temp->next;
	}
	count = x;
	return 0;
}

bool LListAD::isEmpty() const{
	return (front == NULL);
}

bool LListAD::hasNext() const{
	return !isEmpty();
}

void LListAD::dump() const{
	adnode *temp = new adnode;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.name << endl;
		temp = temp->next;
	}
}

