
#include <string>
#include <iostream>
#include "LinkedList_ST.h"
using namespace std;
using std::ostream;
using std::istream;

class aoString{
	friend ostream& operator << (ostream& os, const aoString& s){
			return os << s.code;
	}
	
	private:
		string code;

	public:
		const bool operator == (const aoString & r){ return (code == r.code); }
		const aoString &operator = (const aoString & r){ code = r.code; return *this; }
		const aoString &operator = (const string & r){ code = r; return *this; }
		const aoString &operator += (const aoString & r){ code += r.code; return *this; }
		const aoString &operator += (const string & r){ code += r; return *this; }

		aoString();
		aoString(string);

		void setString(string);
		string toString();

		int countOccurence(char);
		int countOccurence(int,string);
		int findString(int,string);
		int length();
		aoString subStrLeng(int,int);
		aoString subStrSect(int,int); // Parameters are Inclusive
		int indexOf(string,int);
		int indexOf(char,int);
		int rindexOf(string,int);
		int rindexOf(char,int);
		void replace(string,string);
		void insert(int,string);
		void remove(int,int); // Parameters are Inclusive

		void trimWhiteSpace();
		void trim();
		int findCodeStart(int);
		int findCodeEnd(int);
		void stripComments();
		aoString grabCode(int);
		LListST explode(char);
		LListST explode(char,char);
};
