#include <iostream>
#include <string>
#include "LinkedList_ST.h"
using namespace std;

LListST::LListST(){
	front = NULL;
	rear = NULL;
	count = 0;
}

LListST::LListST(const LListST & original){
	stnode *temp; // Used to Create the stnodes
	stnode *current; // The stnode were Currently on
	stnode *last; // Pointer to the Last token in the copy list
	
	if(original.front == NULL)
	{
		front = NULL;
		rear = NULL;
	} else {
		current = original.front;
		front = new stnode;
		front->info = current->info;
		front->next = NULL;
		last = front;
		current = current->next;
		while(current != NULL){
			temp = new stnode;
			temp->info = current->info;
			temp->next = NULL;
			last->next = temp;
			last = temp;
			current = current->next;
		}
		rear = last;
	}
}

LListST & LListST::operator = (const LListST & original){
	stnode *temp; // Used to Create the stnodes
	stnode *current; // The stnode were Currently on
	stnode *last; // Pointer to the Last token in the copy list
	
	if(this != &original)
	{
		if(original.front == NULL)
		{
			front = NULL;
			rear = NULL;
		} else {
			current = original.front;
			front = new stnode;
			front->info = current->info;
			front->next = NULL;
			last = front;
			current = current->next;
			while(current != NULL){
				temp = new stnode;
				temp->info = current->info;
				temp->next = NULL;
				last->next = temp;
				last = temp;
				current = current->next;
			}
			rear = last;
		}
	}
	return *this;
}

LListST::~LListST(){
	reset();
}

void LListST::reset(){
	while(!isEmpty()){
		stnode *temp = front;
		front = front->next;
		delete temp;
	}
}

stdata LListST::getFirst(){
	return front->info;
}

stdata LListST::getLast(){
	return rear->info;
}

stdata LListST::getByID(int x){
	stnode *temp = front;
	while(temp != NULL){
	  //cout << temp->info.name << endl;
		if(temp->info.id == x){
			return temp->info;
		}else{
			temp = temp->next;
		}
	}
	return front->info;
}

void LListST::insert(stdata item){
	stnode *temp = new stnode;
	count++;
	item.id = count;
	temp->info = item;
	temp->next = NULL;
	if(isEmpty()){
		front = temp;
	} else {
		rear->next = temp;
	}
	rear = temp;
}

int LListST::countstnodes(){
	stnode *temp = new stnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		temp = temp->next;
	}
	count = x;
	return x;
}

/*int LListST::findByName(string name){
	stnode *temp = new stnode;
	temp = front;
	int x = 0;
	while(temp != NULL){
		x++;
		if(temp->info.name.compare(name) == 0){
			return temp->info.id;
		}
		temp = temp->next;
	}
	count = x;
	return x;
}*/

bool LListST::isEmpty() const{
	return (front == NULL);
}

bool LListST::hasNext() const{
	return !isEmpty();
}

void LListST::dump() const{
	stnode *temp = new stnode;
	temp = front;
	while(temp != NULL){
		cout << temp->info.id << " - " << temp->info.str << endl;
		temp = temp->next;
	}
}

